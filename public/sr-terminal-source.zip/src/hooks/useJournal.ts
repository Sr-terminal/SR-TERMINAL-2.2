// @ts-nocheck
import { useState, useEffect, useRef, useCallback } from "react"
import {
  isClosed,
  loadJournal,
  saveJournal,
  createRecord,
  updateRecordsOnTick,
  revalidateSetups,
  manualClose,
  moveToBreakEven,
  assessTradeRisk,
  computeStats,
  type JournalRecord,
  type JournalStats,
} from "../lib/journal"
import { safeStorage } from "../lib/storage"
import { sendTradeNotification, getNotificationPrefs, saveNotificationPrefs } from "../lib/notifications"
import { apiUrl } from "../lib/apiConfig"

async function notify(type: string, title: string, body: string) {
  try {
    await sendTradeNotification(type, title, body)
  } catch (err) {
    console.warn("Notification error:", err)
  }
}

export function useJournal() {
  const [records, setRecords] = useState<JournalRecord[]>(() => loadJournal())
  const prefsRef = useRef(getNotificationPrefs())

  const setAndSave = useCallback((newRecords: JournalRecord[]) => {
    setRecords(newRecords)
    saveJournal(newRecords)
  }, [])

  const maybeRecord = useCallback(
    (analysis: any, symbolId: string, symbolLabel: string, tf: string, livePrice: number) => {
      if (!analysis) return
      const currentRecords = loadJournal()
      const reval = revalidateSetups(currentRecords, symbolId, tf, analysis)
      const baseRecords = reval.changed ? reval.records : currentRecords

      if (!analysis?.plan?.valid) {
        if (reval.changed) setAndSave(baseRecords)
        return
      }
      const p = analysis.plan

      const result = createRecord(p, symbolId, symbolLabel, tf, livePrice, baseRecords)
      if (result) {
        setAndSave(result.records)
      } else if (reval.changed) {
        setAndSave(baseRecords)
      }
    },
    [setAndSave]
  )

  const tick = useCallback(
    (symbolId: string, livePrice: number) => {
      if (!isFinite(livePrice) || livePrice <= 0) return
      const currentRecords = loadJournal()
      const { records: updated, fired, notificationsToSend } = updateRecordsOnTick(currentRecords, symbolId, livePrice)

      if (notificationsToSend && notificationsToSend.length > 0) {
        setAndSave(updated)
        for (const item of notificationsToSend) {
          notify(item.type, item.title, item.body)
        }
      } else if (fired && fired.length > 0) {
        setAndSave(updated)
        for (const item of fired) {
          notify(item.status, item.title, item.body)
        }
      } else if (updated.some((r, i) => r !== currentRecords[i])) {
        setAndSave(updated)
      }
    },
    [setAndSave]
  )

  const closeManual = useCallback(
    (id: string, price: number) => {
      const currentRecords = loadJournal()
      setAndSave(currentRecords.map((r) => (r.id === id ? manualClose(r, price) : r)))
    },
    [setAndSave]
  )

  const moveToBE = useCallback(
    (id: string, price: number) => {
      const currentRecords = loadJournal()
      setAndSave(currentRecords.map((r) => (r.id === id ? moveToBreakEven(r, price) : r)))
      notify(
        "MOVE_BREAKEVEN",
        "SL MOVED TO BREAK-EVEN",
        "Position risk-free kar di gayi hai (Capital Protected)"
      )
    },
    [setAndSave]
  )

  const clear = useCallback(() => {
    setAndSave([])
  }, [setAndSave])

  useEffect(() => {
    const syncServerAndLocal = async () => {
      let current = loadJournal()
      let changed = current.length !== records.length

      try {
        const res = await fetch(apiUrl('/api/signals/active'))
        if (res.ok) {
          const data = await res.json()
          const serverTrades: JournalRecord[] = Array.isArray(data?.trades) ? data.trades : []
          if (serverTrades.length > 0) {
            const bySignalId = new Map<string, JournalRecord>()
            for (const item of current) {
              bySignalId.set(item.signalId || item.id, item)
            }
            for (const st of serverTrades) {
              const key = st.signalId || st.id
              if (!bySignalId.has(key)) {
                current = [st, ...current]
                bySignalId.set(key, st)
                changed = true
              } else {
                const existing = bySignalId.get(key)!
                if (existing.stage !== st.stage || existing.statusTs < st.statusTs) {
                  current = current.map((r) => ((r.signalId || r.id) === key ? st : r))
                  changed = true
                }
              }
            }
          }
        }
      } catch {
        // ignore network offline
      }

      if (changed) {
        saveJournal(current)
        setRecords(current)
      }
    }

    void syncServerAndLocal()
    const t = setInterval(() => {
      void syncServerAndLocal()
    }, 15000)
    return () => clearInterval(t)
  }, [records.length])

  return {
    records,
    stats: computeStats(records),
    maybeRecord,
    tick,
    closeManual,
    moveToBE,
    clear,
  }
}
