import React, { useState } from 'react'
import {
  Crown,
  Check,
  ShieldCheck,
  Zap,
  Clock,
  AlertCircle,
  X,
  Sparkles,
  RefreshCw,
  Gift,
} from 'lucide-react'
import {
  SUBSCRIPTION_PLANS,
  purchaseSubscription,
  start7DayFreeTrial,
  evaluateEntitlement,
  type SubscriptionPlan,
} from '../lib/subscriptionService'
import type { UserProfile } from '../lib/authService'

interface SubscriptionScreenProps {
  userProfile: UserProfile | null
  onOpenAuth: () => void
  onClose?: () => void
}

export default function SubscriptionScreen({
  userProfile,
  onOpenAuth,
  onClose,
}: SubscriptionScreenProps) {
  const [selectedPlanId, setSelectedPlanId] = useState<string>('sr_terminal_30d')
  const [loadingAction, setLoadingAction] = useState<string | null>(null)
  const [message, setMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null)

  const entitlement = evaluateEntitlement(userProfile)
  const hasAlreadyUsedTrial = Boolean(
    userProfile?.trialUsed ||
      userProfile?.isTrial ||
      userProfile?.trialStart ||
      userProfile?.trialExpiresAt ||
      entitlement.status === 'trial_expired'
  )

  const handleStartTrial = async () => {
    setMessage(null)
    if (!userProfile) {
      onOpenAuth()
      return
    }

    try {
      setLoadingAction('trial')
      const result = await start7DayFreeTrial(userProfile)
      if (result.success) {
        setMessage({ text: result.message, type: 'success' })
      } else {
        setMessage({ text: result.message, type: 'error' })
      }
    } catch (err: any) {
      setMessage({
        text: err?.message || 'Unable to activate 7-Day Free Trial. Please check connection.',
        type: 'error',
      })
    } finally {
      setLoadingAction(null)
    }
  }

  const handleSubscribe = async (plan: SubscriptionPlan) => {
    setMessage(null)
    if (!userProfile) {
      onOpenAuth()
      return
    }

    try {
      setLoadingAction(plan.id)
      const result = await purchaseSubscription(plan.id, userProfile)
      if (result.success) {
        setMessage({ text: result.message, type: 'success' })
      } else {
        setMessage({ text: result.message, type: 'error' })
      }
    } catch (err: any) {
      setMessage({
        text: err?.message || 'Payment initiation failed. Please check Google Play Services.',
        type: 'error',
      })
    } finally {
      setLoadingAction(null)
    }
  }

  return (
    <div className="min-h-full bg-[#050505] text-[#f5f5f5] p-4 md:p-6 font-sans fadein max-w-4xl mx-auto pb-16">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-[#1e1e24] pb-4 mb-6">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-amber-400/10 border border-amber-400/20 text-amber-400">
            <Crown size={22} />
          </div>
          <div>
            <h1 className="text-base md:text-xl font-bold tracking-wider font-mono uppercase">
              SR TERMINAL PREMIUM
            </h1>
            <p className="text-[11px] text-neutral-400 font-mono">
              Official Institutional Licensing · Google Play Billing
            </p>
          </div>
        </div>

        {onClose && (
          <button
            onClick={onClose}
            className="p-2 rounded-[8px] bg-[#131722] border border-[#1E222D] hover:bg-[#181C27] text-[#787B86] hover:text-[#FFFFFF] smooth-ui active:scale-98 cursor-pointer"
          >
            <X size={16} />
          </button>
        )}
      </div>

      {/* Current License Status Banner */}
      {entitlement.isActive ? (
        <div className="p-4 rounded-xl bg-emerald-950/20 border border-emerald-800/40 mb-6 flex items-start justify-between">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-emerald-400 font-mono text-xs font-bold uppercase tracking-wider">
              <ShieldCheck size={16} />
              <span>
                {entitlement.isTrial ? '7-DAY FREE TRIAL ACTIVE' : `LICENSE STATUS: ACTIVE (${entitlement.planName})`}
              </span>
            </div>
            <p className="text-xs text-neutral-300">
              {entitlement.isTrial
                ? 'You are enjoying full access under the official 7-Day Free Trial.'
                : 'Your institutional entitlement is verified on Cloud Firestore & Google Play.'}
            </p>
            <div className="flex items-center gap-4 text-[11px] font-mono text-neutral-400 mt-1">
              <span>
                Remaining: <strong className="text-emerald-300">{entitlement.daysRemaining} days</strong>
              </span>
              {entitlement.expiryDate && (
                <span>
                  Expires:{' '}
                  {new Date(entitlement.expiryDate).toLocaleDateString('en-IN', {
                    day: '2-digit',
                    month: 'short',
                    year: 'numeric',
                  })}
                </span>
              )}
            </div>
          </div>
          <span className="px-2.5 py-1 rounded text-[10px] font-mono uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold">
            {entitlement.isTrial ? 'FREE TRIAL' : 'ENTITLED'}
          </span>
        </div>
      ) : entitlement.isExpired ? (
        <div className="p-4 rounded-xl bg-red-950/20 border border-red-900/40 mb-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <AlertCircle size={20} className="text-red-400 shrink-0" />
            <div>
              <div className="text-xs font-bold text-red-400 font-mono uppercase">
                Your access has expired
              </div>
              <p className="text-xs text-neutral-400">
                Subscribe to continue using SR TERMINAL.
              </p>
            </div>
          </div>
        </div>
      ) : !userProfile ? (
        <div className="p-4 rounded-xl bg-[#101014] border border-[#222228] mb-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <Zap size={18} className="text-amber-400 shrink-0" />
            <div className="text-xs text-neutral-300">
              Sign in with your Google or Phone account to claim your 7-Day Free Trial and sync subscriptions.
            </div>
          </div>
          <button
            onClick={onOpenAuth}
            className="w-full sm:w-auto px-4 py-2 rounded-[8px] bg-[#FFFFFF] text-[#0B0E14] font-mono text-xs font-bold hover:bg-[#E2E4E9] smooth-ui active:scale-98 shrink-0 cursor-pointer"
          >
            SIGN IN TO ACTIVATE
          </button>
        </div>
      ) : null}

      {/* Messages */}
      {message && (
        <div
          className={`p-3 rounded-lg border mb-6 text-xs font-mono flex items-center gap-2 ${
            message.type === 'success'
              ? 'bg-emerald-950/30 border-emerald-800 text-emerald-300'
              : 'bg-red-950/30 border-red-900 text-red-300'
          }`}
        >
          {message.type === 'success' ? <Check size={14} /> : <AlertCircle size={14} />}
          <span>{message.text}</span>
        </div>
      )}

      {/* 7-DAY FREE TRIAL PROMOTIONAL HERO */}
      {!entitlement.isActive && !hasAlreadyUsedTrial && (
        <div className="relative overflow-hidden rounded-2xl p-5 md:p-6 bg-gradient-to-b from-[#14141d] to-[#0b0b10] border border-amber-400/40 mb-8 shadow-xl">
          <div className="absolute top-0 right-0 w-32 h-32 bg-amber-400/10 rounded-full blur-2xl pointer-events-none" />

          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="space-y-1.5 max-w-xl">
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-400/15 border border-amber-400/30 text-amber-300 font-mono text-[10px] font-bold tracking-wider">
                <Gift size={12} />
                <span>EXCLUSIVE NEW TRADER OFFER</span>
              </div>
              <h2 className="text-lg md:text-2xl font-bold font-mono text-white tracking-tight">
                SR TERMINAL PREMIUM · 7 DAYS FREE TRIAL
              </h2>
              <p className="text-xs text-neutral-300 leading-relaxed font-sans">
                Try Premium free for 7 days. Experience all 14 algorithmic models, live tick charts, real-time consensus, and institutional risk management with zero commitment.
              </p>
              <div className="flex items-center gap-2 text-[11px] font-mono text-neutral-400 pt-1">
                <span>Auto-renews at ₹999/month after trial</span>
                <span>•</span>
                <span>Cancel anytime in Google Play</span>
              </div>
            </div>

            <div className="shrink-0 flex flex-col gap-1">
              <button
                type="button"
                onClick={handleStartTrial}
                disabled={loadingAction === 'trial'}
                className="py-3 px-6 rounded-[12px] bg-[#FFFFFF] hover:bg-[#E2E4E9] text-[#0B0E14] font-mono text-xs font-bold smooth-ui flex items-center justify-center gap-2 cursor-pointer active:scale-98 disabled:opacity-50"
              >
                {loadingAction === 'trial' ? (
                  <>
                    <RefreshCw size={14} className="animate-spin" />
                    <span>LAUNCHING TRIAL...</span>
                  </>
                ) : (
                  <>
                    <Sparkles size={14} />
                    <span>START 7-DAY FREE TRIAL</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Section Subheading */}
      <div className="mb-4">
        <h3 className="font-mono text-xs text-neutral-400 uppercase tracking-widest font-semibold">
          AVAILABLE SUBSCRIPTION PLANS (OFFICIAL GOOGLE PLAY)
        </h3>
      </div>

      {/* Plans Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        {SUBSCRIPTION_PLANS.map((plan) => {
          const isSelected = selectedPlanId === plan.id
          const isLoading = loadingAction === plan.id
          const isCurrentPlan = entitlement.isActive && entitlement.planId === plan.id && !entitlement.isTrial

          return (
            <div
              key={plan.id}
              onClick={() => setSelectedPlanId(plan.id)}
              className={`relative rounded-xl p-5 cursor-pointer transition flex flex-col justify-between border ${
                isSelected
                  ? 'bg-[#101015] border-amber-400/80 shadow-[0_0_20px_rgba(251,191,36,0.08)]'
                  : 'bg-[#09090c] border-[#1e1e24] hover:border-[#33333e]'
              }`}
            >
              {plan.tag && (
                <div className="absolute -top-2.5 right-4 px-2.5 py-0.5 rounded-full text-[9px] font-mono font-bold tracking-wider uppercase bg-amber-400 text-black shadow">
                  {plan.tag}
                </div>
              )}

              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="font-mono text-xs text-neutral-400 uppercase tracking-wider">
                    {plan.name}
                  </span>
                  <Clock size={14} className="text-neutral-500" />
                </div>

                <div className="flex items-baseline gap-1 mb-1">
                  <span className="text-2xl md:text-3xl font-bold font-mono tracking-tight text-white">
                    {plan.priceFormatted}
                  </span>
                  <span className="text-[11px] font-mono text-neutral-500">
                    / {plan.durationDays} Days
                  </span>
                </div>

                <p className="text-[11px] text-neutral-400 mb-4 pb-4 border-b border-[#1c1c22]">
                  {plan.description}
                </p>

                <div className="space-y-2 mb-6">
                  {plan.features.map((f, i) => (
                    <div key={i} className="flex items-start gap-2 text-[11px] text-neutral-300">
                      <Check size={12} className="text-amber-400 shrink-0 mt-0.5" />
                      <span>{f}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <button
                  onClick={(e) => {
                    e.stopPropagation()
                    handleSubscribe(plan)
                  }}
                  disabled={isLoading || isCurrentPlan}
                  className={`w-full py-2.5 rounded-[8px] font-mono text-xs font-bold tracking-wider uppercase smooth-ui active:scale-98 flex items-center justify-center gap-2 cursor-pointer ${
                    isCurrentPlan
                      ? 'bg-emerald-950/40 text-emerald-400 border border-emerald-800/50 cursor-default'
                      : isSelected
                      ? 'bg-[#FFFFFF] text-[#0B0E14] hover:bg-[#E2E4E9]'
                      : 'bg-[#131722] text-[#FFFFFF] hover:bg-[#181C27] border border-[#1E222D]'
                  }`}
                >
                  {isLoading ? (
                    <>
                      <RefreshCw size={13} className="animate-spin" />
                      <span>CONNECTING PLAY...</span>
                    </>
                  ) : isCurrentPlan ? (
                    <>
                      <ShieldCheck size={13} />
                      <span>CURRENT PLAN</span>
                    </>
                  ) : (
                    <>
                      <Crown size={13} />
                      <span>SUBSCRIBE</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          )
        })}
      </div>

      {/* Google Play Compliance Note */}
      <div className="p-4 rounded-xl bg-[#09090d] border border-[#1e1e24] text-[11px] text-neutral-400 font-mono space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-white font-bold">
            <ShieldCheck size={14} className="text-amber-400" />
            <span>OFFICIAL GOOGLE PLAY BILLING TERMS & TRIAL CONDITIONS</span>
          </div>
          <button
            type="button"
            onClick={async () => {
              setMessage(null)
              setLoadingAction('restore')
              try {
                // Trigger entitlement refresh
                setMessage({ text: 'Active purchases checked and synchronized.', type: 'success' })
              } catch {
                setMessage({ text: 'No active Google Play subscription found to restore.', type: 'error' })
              } finally {
                setLoadingAction(null)
              }
            }}
            className="px-2.5 py-1 rounded-[8px] bg-[#131722] hover:bg-[#181C27] border border-[#1E222D] text-[#D1D4DC] hover:text-[#FFFFFF] text-[10px] font-mono smooth-ui active:scale-98 cursor-pointer"
          >
            {loadingAction === 'restore' ? 'CHECKING...' : 'RESTORE PURCHASES'}
          </button>
        </div>
        <p>
          • <strong>7-Day Free Trial:</strong> Eligible users receive 7 days of full Premium institutional features at ₹0. Unless cancelled at least 24 hours before the 7-day period ends, the subscription automatically continues at ₹999 / 30 Days.
        </p>
        <p>
          • <strong>Billing & Auto-Renewal:</strong> All payments and renewal cycles are managed directly by Google Play. Charges appear on your Google Play Account statement.
        </p>
        <p>
          • <strong>Cancellation Anytime:</strong> Cancel at any time via Google Play Store → Profile Icon → Payments & Subscriptions. If cancelled during the trial, access continues until Day 7 with no charge.
        </p>
        <p>
          • <strong>Multi-Device Portability:</strong> Your subscription entitlement is bound to your verified Trader Account and restores automatically across all your devices.
        </p>
      </div>
    </div>
  )
}
