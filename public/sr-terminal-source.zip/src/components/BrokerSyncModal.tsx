import React, { useState, useEffect } from 'react'
import { SlidersHorizontal, RefreshCw, Check, X, ArrowUpDown } from 'lucide-react'
import {
  getBrokerOffset,
  setBrokerOffset,
  resetBrokerOffset,
  syncToBrokerPrice,
  syncBenchmarks,
} from '../lib/brokerCalibration'
import { fmtPrice, type SymbolDef } from '../lib/market'

interface BrokerSyncModalProps {
  isOpen: boolean
  onClose: () => void
  symbol: SymbolDef
  livePrice: number
}

export default function BrokerSyncModal({
  isOpen,
  onClose,
  symbol,
  livePrice,
}: BrokerSyncModalProps) {
  const [brokerInput, setBrokerInput] = useState('')
  const [currentOffset, setCurrentOffset] = useState(0)
  const [syncSuccess, setSyncSuccess] = useState(false)
  const [isRefreshing, setIsRefreshing] = useState(false)

  useEffect(() => {
    if (isOpen) {
      const off = getBrokerOffset(symbol.id)
      setCurrentOffset(off)
      setBrokerInput(livePrice > 0 ? livePrice.toFixed(symbol.digits) : '')
      setSyncSuccess(false)
    }
  }, [isOpen, symbol.id, livePrice, symbol.digits])

  if (!isOpen) return null

  const handleApplySync = (e: React.FormEvent) => {
    e.preventDefault()
    const target = parseFloat(brokerInput)
    if (!isFinite(target) || target <= 0) return
    syncToBrokerPrice(symbol.id, livePrice, target)
    setCurrentOffset(getBrokerOffset(symbol.id))
    setSyncSuccess(true)
    setTimeout(() => {
      setSyncSuccess(false)
      onClose()
    }, 800)
  }

  const handleReset = () => {
    resetBrokerOffset(symbol.id)
    setCurrentOffset(0)
    setBrokerInput(livePrice.toFixed(symbol.digits))
    setSyncSuccess(true)
    setTimeout(() => {
      setSyncSuccess(false)
      onClose()
    }, 800)
  }

  const handleRefreshFeed = async () => {
    setIsRefreshing(true)
    await syncBenchmarks()
    setCurrentOffset(getBrokerOffset(symbol.id))
    setIsRefreshing(false)
  }

  const handleNudge = (delta: number) => {
    const newOffset = currentOffset + delta
    setBrokerOffset(symbol.id, newOffset)
    setCurrentOffset(newOffset)
    setBrokerInput((livePrice + delta).toFixed(symbol.digits))
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 fadein"
      onClick={onClose}
    >
      <div
        className="card w-full max-w-md p-4 space-y-4"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b border-[#1E222D] pb-3">
          <div className="flex items-center gap-2">
            <SlidersHorizontal size={16} className="text-[#FFFFFF]" />
            <h3 className="text-[14px] font-semibold text-[#FFFFFF]">
              Broker Price Calibrator · {symbol.label}
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-[8px] text-[#787B86] hover:text-[#FFFFFF] active:scale-98 cursor-pointer"
          >
            <X size={16} />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-3 text-[11.5px] tabular-nums">
          <div className="p-3 rounded-[10px] bg-[#0B0E14] border border-[#1E222D]">
            <span className="label block">Terminal Price</span>
            <span className="text-[16px] font-bold text-[#FFFFFF] mt-1 block">
              {fmtPrice(livePrice, symbol.digits)}
            </span>
            <span className="text-[10px] text-[#787B86]">Live chart quote</span>
          </div>

          <div className="p-3 rounded-[10px] bg-[#0B0E14] border border-[#1E222D]">
            <span className="label block">Active Offset</span>
            <span
              className="text-[16px] font-bold mt-1 block"
              style={{ color: currentOffset === 0 ? '#787B86' : currentOffset > 0 ? '#089981' : '#F23645' }}
            >
              {currentOffset > 0 ? `+${currentOffset.toFixed(symbol.digits)}` : currentOffset.toFixed(symbol.digits)}
            </span>
            <span className="text-[10px] text-[#787B86]">
              {currentOffset === 0 ? 'Auto Spot Benchmark' : 'Custom Broker Offset'}
            </span>
          </div>
        </div>

        <form onSubmit={handleApplySync} className="space-y-3">
          <div>
            <label className="block text-[11.5px] text-[#FFFFFF] mb-1.5 font-medium">
              Enter Current Broker Price (Exness / OANDA):
            </label>
            <input
              type="number"
              step="any"
              value={brokerInput}
              onChange={(e) => setBrokerInput(e.target.value)}
              placeholder={`e.g. ${fmtPrice(livePrice, symbol.digits)}`}
              className="w-full bg-[#0B0E14] border border-[#1E222D] rounded-[8px] px-3 py-2.5 text-[14px] text-[#FFFFFF] focus:outline-none focus:border-[#FFFFFF] tabular-nums"
            />
            <p className="text-[11px] text-[#787B86] mt-1.5 leading-normal">
              All candles, wicks, Entry, SL, and TP levels will calibrate immediately to match your broker rate.
            </p>
          </div>

          <div className="flex items-center gap-1.5 pt-1 flex-wrap tabular-nums">
            <span className="text-[11px] text-[#787B86]">Quick adjust:</span>
            {symbol.kind === 'FX' ? (
              <>
                <button type="button" onClick={() => handleNudge(-0.0002)} className="chip active:scale-98">-2 pips</button>
                <button type="button" onClick={() => handleNudge(-0.0001)} className="chip active:scale-98">-1 pip</button>
                <button type="button" onClick={() => handleNudge(0.0001)} className="chip active:scale-98">+1 pip</button>
                <button type="button" onClick={() => handleNudge(0.0002)} className="chip active:scale-98">+2 pips</button>
              </>
            ) : (
              <>
                <button type="button" onClick={() => handleNudge(-0.5)} className="chip active:scale-98">-$0.50</button>
                <button type="button" onClick={() => handleNudge(-0.1)} className="chip active:scale-98">-$0.10</button>
                <button type="button" onClick={() => handleNudge(0.1)} className="chip active:scale-98">+$0.10</button>
                <button type="button" onClick={() => handleNudge(0.5)} className="chip active:scale-98">+$0.50</button>
              </>
            )}
          </div>

          <div className="flex items-center gap-2.5 pt-2">
            <button
              type="submit"
              className="flex-1 bg-[#FFFFFF] text-[#0B0E14] font-semibold text-[12px] py-2.5 rounded-[8px] flex items-center justify-center gap-1.5 cursor-pointer select-none active:scale-98"
            >
              {syncSuccess ? (
                <>
                  <Check size={14} /> Synced
                </>
              ) : (
                <>
                  <ArrowUpDown size={14} /> Sync to Broker
                </>
              )}
            </button>

            <button
              type="button"
              onClick={handleReset}
              className="px-3.5 py-2.5 rounded-[8px] bg-[#0B0E14] border border-[#1E222D] text-[12px] font-medium text-[#787B86] hover:text-[#FFFFFF] cursor-pointer select-none active:scale-98"
              title="Reset offset to default interbank spot rate"
            >
              Reset
            </button>
          </div>
        </form>

        <div className="pt-2.5 border-t border-[#1E222D] flex items-center justify-between text-[11px] text-[#787B86]">
          <span>OANDA / Exness interbank spot calibrated</span>
          <button
            type="button"
            onClick={handleRefreshFeed}
            disabled={isRefreshing}
            className="flex items-center gap-1 text-[#787B86] hover:text-[#FFFFFF] cursor-pointer active:scale-98"
          >
            <RefreshCw size={11} />
            {isRefreshing ? 'Syncing…' : 'Refresh Benchmark'}
          </button>
        </div>
      </div>
    </div>
  )
}
