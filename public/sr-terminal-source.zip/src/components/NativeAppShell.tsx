import { Suspense, lazy, useEffect, useState } from 'react'
import { Capacitor } from '@capacitor/core'
import { Home as HomeIcon, CandlestickChart, LayoutGrid, MoreHorizontal, ShieldOff, Crown, Sparkles, LogOut, Download, NotebookPen } from 'lucide-react'
import Home from './Home'
import Terminal from './Terminal'
import TerminalLockedScreen from './TerminalLockedScreen'
import { startDeviceControl, subscribeDevice, checkUpdate, type DeviceState, type UpdateManifest } from '../lib/deviceControl'
import { safeStorage } from '../lib/storage'
import { evaluateEntitlement } from '../lib/subscriptionService'
import { signOutUser, type UserProfile } from '../lib/authService'
import { isUserAdmin } from '../lib/adminService'
import { sendTradeNotification, requestNotificationPermission } from '../lib/notifications'
import { apiUrl } from '../lib/apiConfig'
import { downloadAdminArtifact } from '../lib/adminDownload'

const Matrix = lazy(() => import('./Matrix'))
const JournalScreen = lazy(() => import('./JournalScreen'))
const More = lazy(() => import('./More'))
const SubscriptionScreen = lazy(() => import('./SubscriptionScreen'))
const AiTradingAgent = lazy(() => import('./AiTradingAgent'))
const AiDeveloperAgent = lazy(() => import('./AiDeveloperAgent'))

export type Route = 'home' | 'terminal' | 'journal' | 'ai-agent' | 'matrix' | 'more' | 'dev-agent'

const ROUTE_KEY = 'sr.apk.route'

const NAV: Array<{ id: Route; label: string; Icon: typeof HomeIcon }> = [
  { id: 'home', label: 'Home', Icon: HomeIcon },
  { id: 'terminal', label: 'Terminal', Icon: CandlestickChart },
  { id: 'journal', label: 'Journal', Icon: NotebookPen },
  { id: 'ai-agent', label: 'AI Agent', Icon: Sparkles },
  { id: 'matrix', label: 'Matrix', Icon: LayoutGrid },
  { id: 'more', label: 'More', Icon: MoreHorizontal },
]

interface NativeAppShellProps {
  userProfile?: UserProfile | null
  onSignOut?: () => void
}

function ScreenSkeleton() {
  return (
    <div className="p-4 space-y-3 max-w-xl mx-auto fadein">
      <div className="h-14 shimmer" />
      <div className="h-52 shimmer" />
      <div className="grid grid-cols-2 gap-3">
        <div className="h-24 shimmer" />
        <div className="h-24 shimmer" />
      </div>
    </div>
  )
}

export default function NativeAppShell({ userProfile, onSignOut }: NativeAppShellProps) {
  const [route, setRoute] = useState<Route>(() => {
    const saved = safeStorage.getItem(ROUTE_KEY)
    return (['home', 'terminal', 'ai-agent', 'matrix', 'journal', 'more'] as string[]).includes(saved ?? '') ? (saved as Route) : 'home'
  })
  const [device, setDevice] = useState<DeviceState | null>(null)
  const [update, setUpdate] = useState<UpdateManifest | null>(null)
  const [showSubscription, setShowSubscription] = useState(false)
  const [downloadStatus, setDownloadStatus] = useState<string | null>(null)

  const entitlement = evaluateEntitlement(userProfile)
  const isAdmin = isUserAdmin(userProfile ?? null)

  const go = (r: Route) => {
    setRoute(r)
    try { safeStorage.setItem(ROUTE_KEY, r) } catch { /* noop */ }
  }

  useEffect(() => {
    startDeviceControl()
    const unsub = subscribeDevice(setDevice)
    void checkUpdate().then(setUpdate)
    void requestNotificationPermission()
    return unsub
  }, [])

  // Persistent Background Signal Stream (SSE) & Notification Dispatcher
  useEffect(() => {
    let evtSource: EventSource | null = null
    let reconnectTimeout: any = null

    const connectSSE = () => {
      try {
        evtSource = new EventSource(apiUrl('/api/signals/stream'))
        evtSource.onmessage = (e) => {
          try {
            const data = JSON.parse(e.data)
            if (data && data.title && data.body && data.type !== 'CONNECTED') {
              void sendTradeNotification(data.type, data.title, data.body)
            }
          } catch {}
        }
        evtSource.onerror = () => {
          evtSource?.close()
          reconnectTimeout = setTimeout(connectSSE, 6000)
        }
      } catch {
        reconnectTimeout = setTimeout(connectSSE, 6000)
      }
    }

    connectSSE()

    return () => {
      evtSource?.close()
      if (reconnectTimeout) clearTimeout(reconnectTimeout)
    }
  }, [])

  // Android hardware back button
  useEffect(() => {
    if (!Capacitor.isNativePlatform()) return
    let App: typeof import('@capacitor/app') | null = null
    import('@capacitor/app').then(m => {
      App = m
      m.App.addListener('backButton', () => {
        const cur = safeStorage.getItem(ROUTE_KEY) ?? 'home'
        if (cur !== 'home' && cur !== 'more') go('more')
        else if (cur === 'more') go('home')
        else m.App.exitApp()
      })
    })
    return () => {
      void App?.App.removeAllListeners?.()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  if (device?.status === 'blocked') {
    return (
      <div className="h-full flex flex-col items-center justify-center px-8 text-center bg-[#0B0E14]">
        <ShieldOff size={36} className="text-[#F23645] mb-4" />
        <h1 className="display text-lg font-bold mb-2 text-[#FFFFFF]">Device Restricted</h1>
        <p className="text-[#787B86] text-sm">This device has been restricted by the administrator. Contact: Suraj Ray.</p>
        <p className="mono text-[10px] text-[#787B86] mt-4 tabular-nums">ID {device.deviceId}</p>
      </div>
    )
  }

  return (
    <div className="h-full flex flex-col safe-top bg-[#0B0E14] text-[#FFFFFF]">
      {update && (
        <button
          onClick={() => window.open(update.url, '_blank')}
          className="w-full py-2 text-[11px] font-semibold tracking-wide bg-[#FFFFFF] text-[#0B0E14] active:scale-98"
        >
          Update {update.versionName} Available — Tap to Download
        </button>
      )}

      {/* User Session & Entitlement Bar */}
      <div className="flex items-center justify-between px-4 py-2 bg-[#0B0E14] border-b border-[#1E222D] text-[11px] shrink-0 tabular-nums">
        <div className="flex items-center gap-2 text-[#787B86] min-w-0">
          <Crown size={12} className={entitlement.isActive ? 'text-[#089981] shrink-0' : entitlement.isExpired ? 'text-[#F23645] shrink-0' : 'text-[#787B86] shrink-0'} />
          <span className={entitlement.isExpired ? 'text-[#F23645] font-semibold' : 'text-[#FFFFFF] font-semibold'}>
            {entitlement.isActive ? `${entitlement.planName}` : entitlement.isExpired ? 'Access Expired' : 'Free Tier'}
          </span>
          {userProfile?.email && (
            <span className="text-[#787B86] truncate max-w-[160px]">· {userProfile.email}</span>
          )}
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          {isAdmin && (
            <>
              <button
                type="button"
                onClick={() => void downloadAdminArtifact('apk', setDownloadStatus)}
                disabled={Boolean(downloadStatus)}
                className="px-2 py-1 rounded-[8px] bg-[#00E676]/15 border border-[#00E676]/40 hover:bg-[#00E676]/25 text-[#00E676] text-[10px] font-bold flex items-center gap-1 cursor-pointer active:scale-98 disabled:opacity-50"
                title="Direct Admin APK Download (v2.8.9.19)"
              >
                <Download size={11} />
                <span>{downloadStatus && downloadStatus.includes('apk') ? 'Downloading…' : 'APK'}</span>
              </button>
              <button
                type="button"
                onClick={() => void downloadAdminArtifact('zip', setDownloadStatus)}
                disabled={Boolean(downloadStatus)}
                className="px-2 py-1 rounded-[8px] bg-[#131722] border border-[#1E222D] hover:border-[#2A2E39] text-[#FFFFFF] text-[10px] font-semibold flex items-center gap-1 cursor-pointer active:scale-98 disabled:opacity-50"
                title="Direct Admin Source ZIP Download"
              >
                <Download size={11} />
                <span>{downloadStatus && downloadStatus.includes('ZIP') ? 'Preparing…' : 'ZIP'}</span>
              </button>
            </>
          )}
          {!entitlement.isActive && (
            <button
              type="button"
              onClick={() => setShowSubscription(true)}
              className="px-2.5 py-1 rounded-[8px] bg-[#FFFFFF] text-[#0B0E14] text-[10px] font-semibold cursor-pointer active:scale-98"
            >
              {userProfile?.trialUsed ? 'Upgrade' : '7D Trial'}
            </button>
          )}
          <button
            type="button"
            onClick={async () => {
              await signOutUser()
              onSignOut?.()
            }}
            className="text-[#787B86] hover:text-[#FFFFFF] bg-[#131722] border border-[#1E222D] hover:border-[#2A2E39] px-2.5 py-1 rounded-[8px] flex items-center gap-1 text-[10px] font-medium cursor-pointer active:scale-98"
            title="Log out of current account"
          >
            <LogOut size={11} />
            <span>Sign Out</span>
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto scroll-touch">
        {route === 'home' && <Home go={go} />}
        {route === 'terminal' && (
          entitlement.isActive ? (
            <Terminal />
          ) : (
            <TerminalLockedScreen
              userProfile={userProfile ?? null}
              onViewPlans={() => setShowSubscription(true)}
              onSubscribeNow={() => setShowSubscription(true)}
              onOpenAuth={() => onSignOut?.()}
            />
          )
        )}
        <Suspense fallback={<ScreenSkeleton />}>
          {route === 'matrix' && (
            entitlement.isActive ? (
              <Matrix
                onOpenCell={(symId, tf) => {
                  try {
                    safeStorage.setItem('sr.symbol', symId)
                    safeStorage.setItem('sr.tf', tf)
                  } catch { /* noop */ }
                  go('terminal')
                }}
              />
            ) : (
              <TerminalLockedScreen
                userProfile={userProfile ?? null}
                onViewPlans={() => setShowSubscription(true)}
                onSubscribeNow={() => setShowSubscription(true)}
                onOpenAuth={() => onSignOut?.()}
              />
            )
          )}
          {route === 'ai-agent' && (
            entitlement.isActive ? (
              <AiTradingAgent />
            ) : (
              <TerminalLockedScreen
                userProfile={userProfile ?? null}
                onViewPlans={() => setShowSubscription(true)}
                onSubscribeNow={() => setShowSubscription(true)}
                onOpenAuth={() => onSignOut?.()}
              />
            )
          )}
          {route === 'dev-agent' && (
            <AiDeveloperAgent userProfile={userProfile} onBack={() => go('more')} />
          )}
          {route === 'journal' && (
            <JournalScreen
              userProfile={userProfile}
              onOpenSubscription={() => setShowSubscription(true)}
            />
          )}
          {route === 'more' && <More go={go} onOpenDevAgent={() => go('dev-agent')} onSignOut={onSignOut} />}
        </Suspense>
      </div>

      {showSubscription && (
        <div className="fixed inset-0 z-50 bg-[#0B0E14] overflow-y-auto scroll-touch fadein">
          <Suspense fallback={<ScreenSkeleton />}>
            <SubscriptionScreen
              userProfile={userProfile ?? null}
              onClose={() => setShowSubscription(false)}
              onOpenAuth={() => {
                setShowSubscription(false)
                onSignOut?.()
              }}
            />
          </Suspense>
        </div>
      )}

      <nav className="safe-bottom border-t border-[#1E222D] bg-[#0B0E14] shrink-0">
        <div className="grid grid-cols-6 px-1.5 py-1.5 gap-1 max-w-xl mx-auto">
          {NAV.map(({ id, label, Icon }) => {
            const active = route === id
            return (
              <button
                key={id}
                onClick={() => go(id)}
                className={`flex flex-col items-center justify-center gap-1 min-h-[44px] py-1 rounded-[10px] active:scale-98 cursor-pointer whitespace-nowrap ${
                  active ? 'text-[#FFFFFF] bg-[#131722] border border-[#1E222D]' : 'text-[#787B86] hover:text-[#FFFFFF] border border-transparent'
                }`}
              >
                <Icon size={16} strokeWidth={active ? 2.2 : 1.75} />
                <span className={`text-[9.5px] tracking-tight truncate ${active ? 'font-semibold text-[#FFFFFF]' : 'font-medium text-[#787B86]'}`}>{label}</span>
              </button>
            )
          })}
        </div>
      </nav>
    </div>
  )
}

