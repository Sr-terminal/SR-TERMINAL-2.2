import { useState } from 'react'
import {
  Lock,
  Crown,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  TrendingUp,
  ArrowRight,
  Layers,
  RotateCcw,
} from 'lucide-react'
import type { UserProfile } from '../lib/authService'
import {
  evaluateEntitlement,
  start7DayFreeTrial,
  purchaseSubscription,
  SUBSCRIPTION_PLANS,
} from '../lib/subscriptionService'

interface TerminalLockedScreenProps {
  userProfile: UserProfile | null
  onViewPlans: () => void
  onSubscribeNow: () => void
  onOpenAuth?: () => void
  onTrialActivated?: () => void
}

export default function TerminalLockedScreen({
  userProfile,
  onViewPlans,
  onOpenAuth,
  onTrialActivated,
}: TerminalLockedScreenProps) {
  const [activatingTrial, setActivatingTrial] = useState(false)
  const [errorMsg, setErrorMsg] = useState<string | null>(null)
  const [successMsg, setSuccessMsg] = useState<string | null>(null)

  const entitlement = evaluateEntitlement(userProfile)
  const hasUsedTrial = Boolean(
    userProfile?.trialUsed ||
      userProfile?.isTrial ||
      userProfile?.trialStart ||
      entitlement.status === 'trial_expired'
  )
  const isExpired = entitlement.isExpired || hasUsedTrial

  const handleStartTrial = async () => {
    setErrorMsg(null)
    setSuccessMsg(null)

    if (!userProfile) {
      onOpenAuth?.()
      return
    }

    try {
      setActivatingTrial(true)
      const res = await start7DayFreeTrial(userProfile)
      if (res.success) {
        setSuccessMsg(res.message)
        onTrialActivated?.()
      } else {
        setErrorMsg(res.message)
      }
    } catch (err: any) {
      setErrorMsg(err?.message || 'Failed to activate 7-Day Free Trial. Please check connection.')
    } finally {
      setActivatingTrial(false)
    }
  }

  const handleQuickSubscribe = async () => {
    if (!userProfile) {
      onOpenAuth?.()
      return
    }
    const defaultPlan = SUBSCRIPTION_PLANS[0]
    try {
      const res = await purchaseSubscription(defaultPlan.id, userProfile)
      if (res.success) {
        setSuccessMsg(res.message)
        onTrialActivated?.()
      } else {
        onViewPlans()
      }
    } catch {
      onViewPlans()
    }
  }

  return (
    <div className="min-h-full flex flex-col items-center justify-center p-4 bg-[#0B0E14] text-[#FFFFFF] font-sans fadein">
      <div className="w-full max-w-lg bg-[#131722] border border-[#1E222D] rounded-[12px] p-6 sm:p-7 relative">
        {/* Lock / Premium Icon */}
        <div className="flex flex-col items-center text-center">
          <div className="relative mb-4">
            <div className="w-14 h-14 rounded-[12px] bg-[#0B0E14] border border-[#1E222D] flex items-center justify-center text-[#FFFFFF]">
              <Lock size={24} strokeWidth={2} />
            </div>
            <div className="absolute -bottom-1 -right-1 p-1 rounded-[6px] bg-[#FFFFFF] text-[#0B0E14]">
              <Crown size={12} strokeWidth={2.5} />
            </div>
          </div>

          {isExpired ? (
            <>
              <div className="text-[11px] font-semibold text-[#F23645] mb-1">
                Access Expired
              </div>
              <h1 className="text-lg sm:text-xl font-bold tracking-tight text-[#FFFFFF]">
                Your access has expired
              </h1>
              <p className="text-xs text-[#787B86] mt-1 max-w-md">
                Subscribe to continue using SR Terminal institutional tools.
              </p>
            </>
          ) : (
            <>
              <div className="text-[11px] font-semibold text-[#089981] mb-1">
                Institutional Workspace
              </div>
              <h1 className="text-lg sm:text-xl font-bold tracking-tight text-[#FFFFFF]">
                Activate SR Terminal Access
              </h1>
              <p className="text-xs text-[#787B86] mt-1 max-w-md">
                Start your 7-Day Free Trial to unlock all institutional trading models, real-time charts, and backtesting engines.
              </p>
            </>
          )}
        </div>

        {/* Notification Feedback */}
        {errorMsg && (
          <div className="mt-4 p-3 rounded-[12px] bg-[#F23645]/10 border border-[#F23645]/30 text-[#F23645] text-xs flex items-center gap-2">
            <AlertCircle size={15} className="shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}
        {successMsg && (
          <div className="mt-4 p-3 rounded-[12px] bg-[#089981]/10 border border-[#089981]/30 text-[#089981] text-xs flex items-center gap-2">
            <CheckCircle2 size={15} className="shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* Locked Institutional Features List */}
        <div className="mt-5 p-4 rounded-[12px] bg-[#0B0E14] border border-[#1E222D] space-y-2.5">
          <div className="text-[10px] uppercase tracking-wider text-[#787B86] font-semibold mb-1">
            Institutional Features Included
          </div>
          <div className="grid grid-cols-1 gap-2 text-xs text-[#D1D4DC]">
            <div className="flex items-center gap-2">
              <ShieldCheck size={14} className="text-[#089981] shrink-0" />
              <span>14 Book-Derived ICT Algorithm Models</span>
            </div>
            <div className="flex items-center gap-2">
              <TrendingUp size={14} className="text-[#089981] shrink-0" />
              <span>Full-Screen Live Tick Chart & Broker Sync</span>
            </div>
            <div className="flex items-center gap-2">
              <RotateCcw size={14} className="text-[#089981] shrink-0" />
              <span>Historical Chart Replay & Zero-Lookahead Backtest</span>
            </div>
            <div className="flex items-center gap-2">
              <Layers size={14} className="text-[#089981] shrink-0" />
              <span>Multi-Concept Alignment & Manual Trade Logging</span>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="mt-5 flex flex-col gap-2.5">
          {!hasUsedTrial && !isExpired && (
            <button
              type="button"
              onClick={handleStartTrial}
              disabled={activatingTrial}
              className="w-full py-3 px-4 rounded-[12px] bg-[#FFFFFF] hover:bg-[#E2E4E9] text-[#0B0E14] text-xs font-bold smooth-ui flex items-center justify-center gap-2 cursor-pointer active:scale-98 disabled:opacity-50"
            >
              <Sparkles size={14} />
              <span>{activatingTrial ? 'Activating 7-Day Trial...' : 'Start Your 7-Day Free Trial'}</span>
            </button>
          )}

          {isExpired && (
            <button
              type="button"
              onClick={handleQuickSubscribe}
              className="w-full py-3 px-4 rounded-[12px] bg-[#FFFFFF] hover:bg-[#E2E4E9] text-[#0B0E14] text-xs font-bold smooth-ui flex items-center justify-center gap-2 cursor-pointer active:scale-98"
            >
              <Crown size={14} />
              <span>Subscribe Now</span>
            </button>
          )}

          <button
            type="button"
            onClick={onViewPlans}
            className="w-full py-3 px-4 rounded-[12px] bg-[#0B0E14] hover:bg-[#181C27] border border-[#1E222D] text-[#FFFFFF] text-xs font-semibold smooth-ui flex items-center justify-center gap-2 cursor-pointer active:scale-98"
          >
            <span>View Plans</span>
            <ArrowRight size={13} />
          </button>
        </div>

        <div className="mt-4 text-center text-[11px] text-[#787B86]">
          <span>Official Google Play Licensing · Cancel Anytime</span>
          {hasUsedTrial && (
            <div className="text-[#787B86] mt-0.5">
              One account = one 7-day trial only
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
