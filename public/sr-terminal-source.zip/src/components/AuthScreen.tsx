import { useState, useEffect, useRef, type FormEvent, type KeyboardEvent } from 'react'
import {
  AlertCircle,
  RefreshCw,
  Mail,
  Lock,
  Eye,
  EyeOff,
  User as UserIcon,
  ArrowRight,
  ArrowLeft,
  RotateCcw,
  CheckCircle2,
  Shield,
  ShieldCheck,
} from 'lucide-react'
import {
  signInWithGoogle,
  sendPasswordReset,
  isAndroidNativeApp,
  type UserProfile,
} from '../lib/authService'
import {
  sendEmailOtp,
  verifyEmailOtp,
  checkIfUserExists,
  completeEmailOtpLogin,
  getRemainingOtpCooldown,
} from '../lib/emailOtpService'

interface AuthScreenProps {
  onSuccess: (profile: UserProfile) => void
  onOpenPrivacyPolicy?: () => void
}

type AuthStep = 'email' | 'otp' | 'create_account' | 'login'

export default function AuthScreen({ onSuccess, onOpenPrivacyPolicy }: AuthScreenProps) {
  const [step, setStep] = useState<AuthStep>('email')

  // Form inputs
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [fullName, setFullName] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)

  // Status & notifications
  const [loading, setLoading] = useState(false)
  const [googleLoading, setGoogleLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [infoMessage, setInfoMessage] = useState<string | null>(null)

  // 6-digit OTP manual input state
  const [otp, setOtp] = useState<string[]>(['', '', '', '', '', ''])
  const [instantOtpCode, setInstantOtpCode] = useState<string | null>(null)
  const [cooldown, setCooldown] = useState(0)
  const otpInputsRef = useRef<(HTMLInputElement | null)[]>([])

  // Verified session cache from server
  const verifiedSessionRef = useRef<{
    sessionToken?: string
    profile?: UserProfile
    isAdmin?: boolean
    accountExists?: boolean
  } | null>(null)

  // Resend cooldown countdown timer
  useEffect(() => {
    if (cooldown <= 0) return
    const interval = setInterval(() => {
      setCooldown((prev) => {
        if (prev <= 1) {
          clearInterval(interval)
          return 0
        }
        return prev - 1
      })
    }, 1000)
    return () => clearInterval(interval)
  }, [cooldown])

  // Focus the first digit input when transitioning to OTP verification step
  useEffect(() => {
    if (step === 'otp') {
      const timer = setTimeout(() => {
        otpInputsRef.current[0]?.focus()
      }, 120)
      return () => clearTimeout(timer)
    }
  }, [step])

  // =========================================================================
  // 1. DISPATCH OTP TO ENTERED EMAIL ADDRESS
  // =========================================================================
  const handleSendOtpSubmit = async (e: FormEvent) => {
    e.preventDefault()
    setError(null)
    setInfoMessage(null)

    const rawInputEmail = email.trim()
    if (!rawInputEmail) {
      setError('Please enter your email address before requesting a verification code.')
      return
    }

    const cleanEmail = rawInputEmail.toLowerCase()
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(cleanEmail)) {
      setError('Please enter a valid email address.')
      return
    }

    setLoading(true)
    try {
      const res = await sendEmailOtp(cleanEmail, 'verify')
      if (res.relayCode && res.relayCode.length === 6) {
        setInstantOtpCode(res.relayCode)
        setOtp(res.relayCode.split(''))
      } else {
        setInstantOtpCode(null)
        setOtp(['', '', '', '', '', ''])
      }
      verifiedSessionRef.current = null
      setCooldown(60)
      setInfoMessage(
        res.message || `A 6-digit verification code has been dispatched to ${cleanEmail}. Check your email Inbox.`
      )
      setStep('otp')
    } catch (err: any) {
      console.warn('[SR-Auth] Email OTP dispatch error:', err)
      const rawMsg = err?.message || ''
      setError(rawMsg || 'Failed to send verification code. Please check your email and try again.')
    } finally {
      setLoading(false)
    }
  }

  // =========================================================================
  // 2. RESEND OTP CODE WITH COOLDOWN
  // =========================================================================
  const handleResendOtp = async () => {
    if (cooldown > 0 || loading) return
    setError(null)

    const rawInputEmail = email.trim()
    if (!rawInputEmail) {
      setError('Please enter your email address before requesting a verification code.')
      return
    }

    const cleanEmail = rawInputEmail.toLowerCase()
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(cleanEmail)) {
      setError('Please enter a valid email address.')
      return
    }

    const remaining = getRemainingOtpCooldown(cleanEmail)
    if (remaining > 0) {
      setCooldown(remaining)
      return
    }

    setLoading(true)
    try {
      const res = await sendEmailOtp(cleanEmail, 'verify')
      setCooldown(60)
      if (res.relayCode && res.relayCode.length === 6) {
        setInstantOtpCode(res.relayCode)
        setOtp(res.relayCode.split(''))
      } else {
        setInstantOtpCode(null)
        setOtp(['', '', '', '', '', ''])
      }
      otpInputsRef.current[0]?.focus()
      setInfoMessage(res.message || `A new verification code has been dispatched to ${cleanEmail}.`)
    } catch (err: any) {
      setError(err?.message || 'Failed to resend code. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  // =========================================================================
  // 3. MANUAL OTP INPUT HANDLERS
  // =========================================================================
  const handleOtpChange = (index: number, value: string) => {
    const sanitized = value.replace(/\D/g, '')

    // Support manual paste of 6 digits from clipboard
    if (sanitized.length > 1) {
      const digits = sanitized.slice(0, 6).split('')
      const nextOtp = [...otp]
      digits.forEach((digit, i) => {
        if (index + i < 6) nextOtp[index + i] = digit
      })
      setOtp(nextOtp)
      const nextFocus = Math.min(index + digits.length, 5)
      otpInputsRef.current[nextFocus]?.focus()
      return
    }

    const singleDigit = sanitized.slice(-1)
    const nextOtp = [...otp]
    nextOtp[index] = singleDigit
    setOtp(nextOtp)

    if (singleDigit && index < 5) {
      otpInputsRef.current[index + 1]?.focus()
    }
  }

  const handleOtpKeyDown = (index: number, e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace') {
      if (!otp[index] && index > 0) {
        otpInputsRef.current[index - 1]?.focus()
      }
    } else if (e.key === 'Enter') {
      const fullCode = otp.join('')
      if (fullCode.length === 6) {
        void handleVerifyOtpSubmit()
      }
    }
  }

  // =========================================================================
  // 4. SERVER-SIDE OTP VERIFICATION & ROUTING (EXISTING VS NEW ACCOUNT)
  // =========================================================================
  const handleVerifyOtpSubmit = async (e?: FormEvent) => {
    if (e) e.preventDefault()
    setError(null)
    setInfoMessage(null)

    const code = otp.join('')
    if (code.length !== 6) {
      setError('Please enter the complete 6-digit verification code.')
      return
    }

    const cleanEmail = email.trim().toLowerCase()
    setLoading(true)

    try {
      // 1. Verify OTP on server
      const verifyRes = await verifyEmailOtp(cleanEmail, code)
      if (!verifyRes.success) {
        setError(verifyRes.error || 'Incorrect verification code. Please check and try again.')
        setLoading(false)
        return
      }

      // Store verified session token
      verifiedSessionRef.current = {
        sessionToken: verifyRes.sessionToken,
        profile: verifyRes.profile,
        isAdmin: verifyRes.isAdmin,
        accountExists: verifyRes.accountExists,
      }

      // 2. Check whether user account already exists (server flag + multi-layer lookup)
      const userStatus = await checkIfUserExists(cleanEmail)
      const isExistingAccount = Boolean(verifyRes.accountExists || userStatus.exists)

      if (isExistingAccount) {
        // Existing user → proceed to Password verification step (never block with "Account already exists")
        setPassword('')
        setStep('login')
        setInfoMessage('OTP verified. Enter your account password to sign in to the dashboard.')
      } else {
        // New user → proceed to Create Account step
        setPassword('')
        setConfirmPassword('')
        setStep('create_account')
        setInfoMessage('OTP verified. Complete your trader profile to create your account.')
      }
    } catch (err: any) {
      console.warn('[SR-Auth] Verify OTP error:', err)
      setError(err?.message || 'Verification failed. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  // =========================================================================
  // 5. NEW USER: COMPLETE ACCOUNT REGISTRATION (After OTP Verification)
  // =========================================================================
  const handleCompleteRegistrationSubmit = async (e: FormEvent) => {
    e.preventDefault()
    setError(null)

    const cleanName = fullName.trim()
    if (!cleanName) {
      setError('Please enter your full name.')
      return
    }

    if (!password || password.length < 6) {
      setError('Password must be at least 6 characters long.')
      return
    }

    if (password !== confirmPassword) {
      setError('Passwords do not match. Please re-check.')
      return
    }

    setLoading(true)
    try {
      const cleanEmail = email.trim().toLowerCase()
      const profile = await completeEmailOtpLogin({
        email: cleanEmail,
        name: cleanName,
        password,
        isRegister: true,
        verifiedProfile: verifiedSessionRef.current?.profile,
      })
      onSuccess(profile)
    } catch (err: any) {
      console.warn('[SR-Auth] Registration completion error:', err)
      setError(err?.message || 'Failed to complete registration. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  // =========================================================================
  // 6. EXISTING USER: VALIDATE PASSWORD & LOG IN STRAIGHT TO DASHBOARD
  // =========================================================================
  const handleCompleteLoginSubmit = async (e: FormEvent) => {
    e.preventDefault()
    setError(null)

    const cleanEmail = email.trim().toLowerCase()
    if (!password || password.length < 6) {
      setError('Please enter your password (minimum 6 characters).')
      return
    }

    setLoading(true)
    try {
      // Both OTP and Password are validated; save session/token and authenticate straight into dashboard
      const profile = await completeEmailOtpLogin({
        email: cleanEmail,
        password,
        isRegister: false,
        verifiedProfile: verifiedSessionRef.current?.profile,
      })
      onSuccess(profile)
    } catch (err: any) {
      console.warn('[SR-Auth] Login completion error:', err)
      setError(err?.message || 'Login failed. Please verify your password and try again.')
    } finally {
      setLoading(false)
    }
  }

  // Password reset handler
  const handleForgotPassword = async () => {
    const cleanEmail = email.trim().toLowerCase()
    if (!cleanEmail) {
      setError('Please enter your email address first.')
      return
    }
    setLoading(true)
    try {
      await sendPasswordReset(cleanEmail)
      setInfoMessage(`Password reset link sent to ${cleanEmail}. Check your email Inbox.`)
    } catch (err: any) {
      setError(err?.message || 'Failed to send password reset email.')
    } finally {
      setLoading(false)
    }
  }

  // =========================================================================
  // 7. GOOGLE SIGN IN OPTION
  // =========================================================================
  const handleGoogleSignIn = async () => {
    setError(null)
    setInfoMessage(null)

    const cleanEmail = email.trim().toLowerCase()
    const isNative = isAndroidNativeApp()

    const fallbackToOtpDispatch = async () => {
      if (cleanEmail && cleanEmail.includes('@')) {
        setGoogleLoading(true)
        try {
          const res = await sendEmailOtp(cleanEmail, 'verify')
          if (res.relayCode && res.relayCode.length === 6) {
            setInstantOtpCode(res.relayCode)
            setOtp(res.relayCode.split(''))
          } else {
            setInstantOtpCode(null)
            setOtp(['', '', '', '', '', ''])
          }
          setStep('otp')
          setInfoMessage(res.message || `Verification code sent to ${cleanEmail}.`)
          setCooldown(60)
        } catch (err: any) {
          setError(err?.message || 'Could not send verification code. Please try again.')
        } finally {
          setGoogleLoading(false)
        }
      } else {
        setInfoMessage('Enter your Google email address below and tap SEND OTP for instant verification.')
        const inputEl = document.getElementById('auth-email-input') as HTMLInputElement | null
        inputEl?.focus()
      }
    }

    if (isNative) {
      await fallbackToOtpDispatch()
      return
    }

    setGoogleLoading(true)
    try {
      const profile = await signInWithGoogle()
      onSuccess(profile)
    } catch (err: any) {
      console.warn('[SR-Auth] Google Sign-In notice:', err)
      setGoogleLoading(false)
      await fallbackToOtpDispatch()
    } finally {
      setGoogleLoading(false)
    }
  }

  return (
    <div
      id="sr-terminal-auth"
      className="min-h-screen w-screen flex flex-col items-center justify-center bg-[#0B0E14] text-[#FFFFFF] p-4 select-none font-sans"
    >
      <main className="w-full max-w-[400px] my-auto">
        <div className="rounded-[12px] border border-[#1E222D] bg-[#131722] p-6 sm:p-7">
          {/* SR Terminal Brand Logo */}
          <div className="flex justify-center mb-4">
            <div className="w-13 h-13 rounded-[12px] bg-[#0B0E14] border border-[#1E222D] p-1.5 flex items-center justify-center">
              <img
                src="/sr-logo.png"
                alt="SR Terminal"
                className="w-full h-full object-contain rounded-[8px]"
                onError={(e) => {
                  const target = e.currentTarget
                  target.style.display = 'none'
                  if (target.parentElement) {
                    target.parentElement.innerHTML =
                      '<span class="font-mono font-bold text-base text-white tracking-widest">SR</span>'
                  }
                }}
              />
            </div>
          </div>

          {/* Dynamic Header */}
          <div className="text-center mb-5">
            <h1 className="text-base font-bold tracking-[0.12em] text-[#FFFFFF]">
              SR TERMINAL
            </h1>
            <p className="text-xs text-[#787B86] mt-1">
              {step === 'email' && 'Institutional Trading Workspace'}
              {step === 'otp' && 'Step 1 of 2 · Verify 6-Digit Email OTP'}
              {step === 'login' && 'Step 2 of 2 · Enter Password to Sign In'}
              {step === 'create_account' && 'Step 2 of 2 · Complete New Account Setup'}
            </p>
          </div>

          {/* Error Notice */}
          {error && (
            <div
              id="auth-error"
              className="mb-4 p-3 rounded-[12px] bg-[#F23645]/10 border border-[#F23645]/30 text-[#F23645] text-xs text-left flex items-start gap-2.5 fadein"
            >
              <AlertCircle size={15} className="shrink-0 mt-0.5 text-[#F23645]" />
              <p className="font-medium text-[11.5px] leading-snug flex-1">{error}</p>
            </div>
          )}

          {/* Info Notice */}
          {infoMessage && (
            <div
              id="auth-info"
              className="mb-4 p-3 rounded-[12px] bg-[#089981]/10 border border-[#089981]/30 text-[#D1D4DC] text-xs text-left flex items-start gap-2.5 fadein"
            >
              <CheckCircle2 size={15} className="shrink-0 mt-0.5 text-[#089981]" />
              <p className="font-medium text-[11.5px] leading-snug flex-1">{infoMessage}</p>
            </div>
          )}

          {/* ================================================================= */}
          {/* STEP 1: USER ENTERS EMAIL ADDRESS                                */}
          {/* ================================================================= */}
          {step === 'email' && (
            <div className="space-y-4">
              {/* Google Sign-In */}
              <button
                id="btn-google-auth"
                type="button"
                disabled={googleLoading || loading}
                onClick={handleGoogleSignIn}
                className="w-full h-11 px-4 rounded-[12px] bg-[#0B0E14] hover:bg-[#191E2B] border border-[#1E222D] text-[#FFFFFF] font-medium text-xs transition-all flex items-center justify-center gap-3 cursor-pointer disabled:opacity-60 select-none active:scale-98"
              >
                {googleLoading ? (
                  <>
                    <RefreshCw size={14} className="animate-spin text-[#FFFFFF]" />
                    <span className="font-mono text-xs">CONNECTING GOOGLE...</span>
                  </>
                ) : (
                  <>
                    <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                      <path
                        fill="#4285F4"
                        d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.8-2.4 3.66v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.15z"
                      />
                      <path
                        fill="#34A853"
                        d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.94H1.27v3.15C3.25 21.36 7.34 24 12 24z"
                      />
                      <path
                        fill="#FBBC05"
                        d="M5.28 14.26c-.25-.72-.38-1.49-.38-2.26s.13-1.54.38-2.26V6.59H1.27C.46 8.2 0 10.05 0 12s.46 3.8 1.27 5.41l4.01-3.15z"
                      />
                      <path
                        fill="#EA4335"
                        d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.34 0 3.25 2.64 1.27 6.59l4.01 3.15c.95-2.84 3.6-4.99 6.72-4.99z"
                      />
                    </svg>
                    <span className="text-xs font-semibold tracking-wider">
                      SIGN IN WITH GOOGLE
                    </span>
                  </>
                )}
              </button>

              <div className="relative my-2">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-[#1E222D]" />
                </div>
                <div className="relative flex justify-center text-[10px] uppercase font-mono">
                  <span className="bg-[#131722] px-2.5 text-[#787B86]">OR EMAIL OTP + PASSWORD</span>
                </div>
              </div>

              {/* Email Input Form */}
              <form onSubmit={handleSendOtpSubmit} className="space-y-3.5">
                <div>
                  <label
                    htmlFor="auth-email-input"
                    className="block text-xs font-medium text-[#D1D4DC] mb-1.5"
                  >
                    Email address
                  </label>
                  <div className="relative">
                    <Mail
                      size={15}
                      className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#787B86] pointer-events-none"
                    />
                    <input
                      id="auth-email-input"
                      type="email"
                      required
                      autoFocus
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="Enter your email address"
                      className="w-full h-11 pl-10 pr-3.5 rounded-[12px] bg-[#0B0E14] border border-[#1E222D] text-sm text-[#FFFFFF] placeholder-[#787B86] focus:outline-none focus:border-[#FFFFFF] transition-all font-sans"
                    />
                  </div>
                  <p className="text-[11px] text-[#787B86] mt-1.5">
                    A 6-digit verification code will be sent directly to your email address.
                  </p>
                </div>

                <button
                  id="btn-send-otp"
                  type="submit"
                  disabled={loading || !email.trim()}
                  className="w-full h-11 rounded-[12px] bg-[#FFFFFF] hover:bg-[#E2E4E9] active:scale-98 text-[#0B0E14] font-semibold text-xs tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed mt-2"
                >
                  {loading ? (
                    <>
                      <RefreshCw size={14} className="animate-spin text-[#0B0E14]" />
                      <span>DISPATCHING 6-DIGIT CODE...</span>
                    </>
                  ) : (
                    <>
                      <span>SEND OTP</span>
                      <ArrowRight size={14} />
                    </>
                  )}
                </button>
              </form>
            </div>
          )}

          {/* ================================================================= */}
          {/* STEP 2: VERIFY 6-DIGIT OTP FIRST                                 */}
          {/* ================================================================= */}
          {step === 'otp' && (
            <form onSubmit={handleVerifyOtpSubmit} className="space-y-4">
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-10 h-10 rounded-[12px] bg-[#089981]/10 border border-[#089981]/30 text-[#089981] mb-2.5">
                  <Shield size={18} />
                </div>
                <h2 className="text-sm font-semibold text-[#FFFFFF]">
                  Enter the 6-digit OTP sent to your email
                </h2>
                <p className="text-xs font-mono font-medium text-[#089981] mt-1 break-all">
                  {email.trim().toLowerCase()}
                </p>
                <p className="text-[11px] text-[#787B86] mt-0.5">
                  Check your Inbox · Valid for 10 minutes
                </p>
              </div>

              {instantOtpCode && (
                <div className="p-2.5 rounded-[10px] bg-[#00E676]/10 border border-[#00E676]/30 flex items-center justify-between gap-2">
                  <div className="text-left">
                    <div className="text-[10px] font-mono uppercase tracking-wider text-[#00E676]">
                      Instant Verification Code Ready
                    </div>
                    <div className="text-sm font-mono font-bold tracking-[0.2em] text-[#FFFFFF]">
                      {instantOtpCode}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setOtp(instantOtpCode.split(''))}
                    className="px-2.5 py-1.5 rounded-[8px] bg-[#00E676] text-[#0B0E14] font-mono font-bold text-[10px] uppercase tracking-wider cursor-pointer active:scale-95 transition-all"
                  >
                    Auto-Fill
                  </button>
                </div>
              )}

              {/* 6 Clean Input Boxes for Manual OTP Entry */}
              <div className="flex justify-between gap-1.5 sm:gap-2 pt-1">
                {otp.map((digit, index) => (
                  <input
                    key={index}
                    ref={(el) => (otpInputsRef.current[index] = el)}
                    type="text"
                    inputMode="numeric"
                    pattern="[0-9]*"
                    maxLength={6}
                    autoComplete="off"
                    value={digit}
                    onChange={(e) => handleOtpChange(index, e.target.value)}
                    onKeyDown={(e) => handleOtpKeyDown(index, e)}
                    className="w-11 h-13 sm:w-12 sm:h-14 text-center font-mono font-bold text-xl sm:text-2xl tabular-nums rounded-[12px] bg-[#0B0E14] border border-[#1E222D] text-[#FFFFFF] focus:outline-none focus:border-[#FFFFFF] transition-all"
                  />
                ))}
              </div>

              {/* Manual Verification Button */}
              <button
                id="btn-verify-otp"
                type="submit"
                disabled={loading || otp.join('').length !== 6}
                className="w-full h-11 rounded-[12px] bg-[#FFFFFF] hover:bg-[#E2E4E9] active:scale-98 text-[#0B0E14] font-semibold text-xs tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed mt-2"
              >
                {loading ? (
                  <>
                    <RefreshCw size={14} className="animate-spin text-[#0B0E14]" />
                    <span>VERIFYING CODE...</span>
                  </>
                ) : (
                  <>
                    <span>VERIFY OTP & CONTINUE</span>
                    <ArrowRight size={14} />
                  </>
                )}
              </button>

              {/* Resend OTP & Change Email Options */}
              <div className="pt-2 flex flex-col gap-2.5 text-center text-xs">
                <div className="flex items-center justify-center gap-1.5 text-[#787B86]">
                  <span>Didn&apos;t receive the code?</span>
                  <button
                    type="button"
                    disabled={cooldown > 0 || loading}
                    onClick={handleResendOtp}
                    className="text-[#FFFFFF] hover:text-[#D1D4DC] disabled:text-[#787B86] disabled:cursor-not-allowed font-medium transition-colors cursor-pointer flex items-center gap-1 tabular-nums"
                  >
                    <RotateCcw size={11} />
                    <span>{cooldown > 0 ? `Resend in ${cooldown}s` : 'Resend code'}</span>
                  </button>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    setStep('email')
                    setError(null)
                    setInfoMessage(null)
                  }}
                  className="text-[#787B86] hover:text-[#FFFFFF] transition-colors text-[11.5px] flex items-center justify-center gap-1 cursor-pointer mx-auto"
                >
                  <ArrowLeft size={11} />
                  <span>Change email address</span>
                </button>
              </div>
            </form>
          )}

          {/* ================================================================= */}
          {/* STEP 3A: NEW USER → CREATE ACCOUNT PROCESS                       */}
          {/* ================================================================= */}
          {step === 'create_account' && (
            <form onSubmit={handleCompleteRegistrationSubmit} className="space-y-3.5">
              <div className="p-2.5 rounded-[12px] bg-[#089981]/10 border border-[#089981]/30 flex items-center justify-between text-[#089981] text-xs">
                <div className="flex items-center gap-2 truncate">
                  <ShieldCheck size={16} className="shrink-0 text-[#089981]" />
                  <span className="font-mono text-[11px] truncate">
                    OTP Verified: <strong className="text-[#FFFFFF]">{email.trim().toLowerCase()}</strong>
                  </span>
                </div>
              </div>

              {/* Full Name */}
              <div>
                <label
                  htmlFor="signup-name"
                  className="block text-xs font-medium text-[#D1D4DC] mb-1"
                >
                  Full name
                </label>
                <div className="relative">
                  <UserIcon
                    size={15}
                    className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#787B86] pointer-events-none"
                  />
                  <input
                    id="signup-name"
                    type="text"
                    required
                    autoFocus
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="Enter your full name"
                    className="w-full h-11 pl-10 pr-3.5 rounded-[12px] bg-[#0B0E14] border border-[#1E222D] text-sm text-[#FFFFFF] placeholder-[#787B86] focus:outline-none focus:border-[#FFFFFF] transition-all font-sans"
                  />
                </div>
              </div>

              {/* Password */}
              <div>
                <label
                  htmlFor="signup-password"
                  className="block text-xs font-medium text-[#D1D4DC] mb-1"
                >
                  Create password (min 6 characters)
                </label>
                <div className="relative">
                  <Lock
                    size={15}
                    className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#787B86] pointer-events-none"
                  />
                  <input
                    id="signup-password"
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Create your account password"
                    className="w-full h-11 pl-10 pr-10 rounded-[12px] bg-[#0B0E14] border border-[#1E222D] text-sm text-[#FFFFFF] placeholder-[#787B86] focus:outline-none focus:border-[#FFFFFF] transition-all font-sans"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-[#787B86] hover:text-[#FFFFFF] cursor-pointer p-1"
                  >
                    {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
                  </button>
                </div>
              </div>

              {/* Confirm Password */}
              <div>
                <label
                  htmlFor="signup-confirm-password"
                  className="block text-xs font-medium text-[#D1D4DC] mb-1"
                >
                  Confirm password
                </label>
                <div className="relative">
                  <Lock
                    size={15}
                    className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#787B86] pointer-events-none"
                  />
                  <input
                    id="signup-confirm-password"
                    type={showConfirmPassword ? 'text' : 'password'}
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Confirm your password"
                    className="w-full h-11 pl-10 pr-10 rounded-[12px] bg-[#0B0E14] border border-[#1E222D] text-sm text-[#FFFFFF] placeholder-[#787B86] focus:outline-none focus:border-[#FFFFFF] transition-all font-sans"
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-[#787B86] hover:text-[#FFFFFF] cursor-pointer p-1"
                  >
                    {showConfirmPassword ? <EyeOff size={15} /> : <Eye size={15} />}
                  </button>
                </div>
              </div>

              <button
                id="btn-create-account"
                type="submit"
                disabled={loading || !fullName.trim() || !password || !confirmPassword}
                className="w-full h-11 rounded-[12px] bg-[#FFFFFF] hover:bg-[#E2E4E9] active:scale-98 text-[#0B0E14] font-bold text-xs tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed mt-2"
              >
                {loading ? (
                  <>
                    <RefreshCw size={14} className="animate-spin text-[#0B0E14]" />
                    <span>CREATING ACCOUNT...</span>
                  </>
                ) : (
                  <>
                    <span>CREATE ACCOUNT & ENTER</span>
                    <ArrowRight size={14} />
                  </>
                )}
              </button>

              <div className="pt-2 text-center">
                <button
                  type="button"
                  onClick={() => {
                    setError(null)
                    setInfoMessage('OTP verified. Enter your existing account password to sign in.')
                    setStep('login')
                  }}
                  className="text-xs text-[#787B86] hover:text-[#FFFFFF] transition-colors cursor-pointer"
                >
                  Already have an account? <span className="text-[#FFFFFF] underline">Sign in with password</span>
                </button>
              </div>
            </form>
          )}

          {/* ================================================================= */}
          {/* STEP 3B: EXISTING USER → ENTER PASSWORD & SIGN IN TO DASHBOARD    */}
          {/* ================================================================= */}
          {step === 'login' && (
            <form onSubmit={handleCompleteLoginSubmit} className="space-y-3.5">
              <div className="p-2.5 rounded-[12px] bg-[#089981]/10 border border-[#089981]/30 flex items-center justify-between text-[#089981] text-xs">
                <div className="flex items-center gap-2 truncate">
                  <ShieldCheck size={16} className="shrink-0 text-[#089981]" />
                  <span className="font-mono text-[11px] truncate">
                    OTP Verified: <strong className="text-[#FFFFFF]">{email.trim().toLowerCase()}</strong>
                  </span>
                </div>
              </div>

              {/* Password */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label
                    htmlFor="login-password"
                    className="block text-xs font-medium text-[#D1D4DC]"
                  >
                    Password
                  </label>
                  <button
                    type="button"
                    onClick={handleForgotPassword}
                    className="text-[11px] text-[#787B86] hover:text-[#FFFFFF] underline cursor-pointer"
                  >
                    Forgot password?
                  </button>
                </div>
                <div className="relative">
                  <Lock
                    size={15}
                    className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#787B86] pointer-events-none"
                  />
                  <input
                    id="login-password"
                    type={showPassword ? 'text' : 'password'}
                    required
                    autoFocus
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter your account password"
                    className="w-full h-11 pl-10 pr-10 rounded-[12px] bg-[#0B0E14] border border-[#1E222D] text-sm text-[#FFFFFF] placeholder-[#787B86] focus:outline-none focus:border-[#FFFFFF] transition-all font-sans"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-[#787B86] hover:text-[#FFFFFF] cursor-pointer p-1"
                  >
                    {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
                  </button>
                </div>
              </div>

              <button
                id="btn-login-submit"
                type="submit"
                disabled={loading || !password}
                className="w-full h-11 rounded-[12px] bg-[#FFFFFF] hover:bg-[#E2E4E9] active:scale-98 text-[#0B0E14] font-semibold text-xs tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed mt-1"
              >
                {loading ? (
                  <>
                    <RefreshCw size={14} className="animate-spin text-[#0B0E14]" />
                    <span>AUTHENTICATING...</span>
                  </>
                ) : (
                  <>
                    <span>SIGN IN TO DASHBOARD</span>
                    <ArrowRight size={14} />
                  </>
                )}
              </button>

              <div className="pt-2 flex flex-col gap-2 text-center">
                <button
                  type="button"
                  onClick={() => {
                    setError(null)
                    setInfoMessage('OTP verified. Complete your trader profile to create your account.')
                    setStep('create_account')
                  }}
                  className="text-xs text-[#787B86] hover:text-[#FFFFFF] transition-colors cursor-pointer"
                >
                  New to SR Terminal? <span className="text-[#FFFFFF] underline">Create a new account</span>
                </button>
              </div>
            </form>
          )}

          {/* Privacy Policy Link */}
          {onOpenPrivacyPolicy && (
            <div className="mt-5 pt-3 border-t border-[#1E222D] text-center">
              <button
                type="button"
                onClick={onOpenPrivacyPolicy}
                className="text-[10px] text-[#787B86] hover:text-[#FFFFFF] font-mono transition-colors cursor-pointer"
              >
                Privacy Policy & Institutional Security
              </button>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
