import { Shield, ArrowLeft, ExternalLink, Mail, Lock } from 'lucide-react'

interface PrivacyPolicyScreenProps {
  onBack?: () => void
}

export default function PrivacyPolicyScreen({ onBack }: PrivacyPolicyScreenProps) {
  return (
    <div className="min-h-full bg-[#0B0E14] text-[#FFFFFF] p-4 font-sans fadein max-w-3xl mx-auto pb-16">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-[#1E222D] pb-4 mb-5">
        <div className="flex items-center gap-3">
          {onBack && (
            <button
              type="button"
              onClick={onBack}
              className="p-2 rounded-[8px] bg-[#131722] border border-[#1E222D] hover:border-[#2A2E39] text-[#FFFFFF] smooth-ui active:scale-98 cursor-pointer"
              aria-label="Back"
            >
              <ArrowLeft size={16} />
            </button>
          )}
          <div>
            <div className="flex items-center gap-2">
              <Shield size={18} className="text-[#089981]" />
              <h1 className="text-base md:text-lg font-bold tracking-tight">SR Terminal Privacy Policy</h1>
            </div>
            <p className="text-[11px] text-[#787B86] mt-0.5">
              Official Institutional Privacy & Data Protection Agreement · Effective September 15, 2026
            </p>
          </div>
        </div>

        <a
          href="/privacy"
          target="_blank"
          rel="noreferrer"
          className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-[8px] bg-[#131722] border border-[#1E222D] text-[11px] text-[#787B86] hover:text-[#FFFFFF] smooth-ui active:scale-98"
        >
          <span>Web View</span>
          <ExternalLink size={12} />
        </a>
      </div>

      {/* Summary Box */}
      <div className="p-4 rounded-[12px] bg-[#131722] border border-[#1E222D] mb-5 space-y-2 text-xs text-[#D1D4DC]">
        <div className="flex items-center gap-2 text-[#089981] font-semibold text-[11px] tracking-wider uppercase">
          <Lock size={14} />
          <span>Zero Sensitive Access Guarantee</span>
        </div>
        <p className="leading-relaxed text-[#787B86]">
          SR Terminal does <strong className="text-[#FFFFFF]">NOT</strong> request or access your private phone contacts, SMS, call history, photo galleries, camera, microphone, or background GPS location. All authentication is handled directly by Google Identity and Firebase Authentication.
        </p>
      </div>

      {/* Policy Sections */}
      <div className="space-y-4 text-[#D1D4DC] text-xs leading-relaxed">
        <section className="p-4 rounded-[12px] bg-[#131722] border border-[#1E222D] space-y-1.5">
          <h2 className="text-sm font-semibold text-[#FFFFFF]">01. What SR Terminal Is</h2>
          <p className="text-[#787B86]">
            SR Terminal is an institutional ICT algorithmic market analysis workspace and educational decision support system. It provides traders with algorithmic models (including Fair Value Gaps, Liquidity Sweeps, Order Blocks, and Market Structure Shifts), a strict consensus engine, and backtesting capabilities.
          </p>
        </section>

        <section className="p-4 rounded-[12px] bg-[#131722] border border-[#1E222D] space-y-1.5">
          <h2 className="text-sm font-semibold text-[#FFFFFF]">02. Information We Collect</h2>
          <p className="text-[#787B86]">
            We adhere strictly to data minimization principles. We only collect information required to authenticate user sessions, maintain subscription entitlement, prevent fraud, and deliver push alerts.
          </p>
        </section>

        <section className="p-4 rounded-[12px] bg-[#131722] border border-[#1E222D] space-y-1.5">
          <h2 className="text-sm font-semibold text-[#FFFFFF]">03. Authentication & Account Information</h2>
          <p className="text-[#787B86]">
            When you sign in via Google Sign-In or Email OTP verification, your profile document in Cloud Firestore stores your UID, name, email, account status, subscription tier, and login timestamps.
          </p>
        </section>

        <section className="p-4 rounded-[12px] bg-[#131722] border border-[#1E222D] space-y-1.5">
          <h2 className="text-sm font-semibold text-[#FFFFFF]">04. Subscription & Google Play Billing</h2>
          <p className="text-[#787B86]">
            All digital subscriptions on Android are processed through Google Play Billing. SR Terminal never collects, stores, or handles credit card numbers, debit card details, UPI PINs, or bank account information.
          </p>
        </section>

        <section className="p-4 rounded-[12px] bg-[#131722] border border-[#1E222D] space-y-1.5">
          <h2 className="text-sm font-semibold text-[#FFFFFF]">05. Account & Data Deletion Process</h2>
          <p className="text-[#787B86]">
            You have the right to delete your SR Terminal account and all associated personal data at any time under Account → Delete Account & Data, or by emailing us directly. Requests are processed within 7 business days.
          </p>
        </section>

        <section className="p-4 rounded-[12px] bg-[#131722] border border-[#1E222D] space-y-2">
          <h2 className="text-sm font-semibold text-[#FFFFFF]">06. Contact Information</h2>
          <div className="p-3 rounded-[8px] bg-[#0B0E14] border border-[#1E222D] text-[11px] text-[#787B86] space-y-1">
            <div><strong className="text-[#FFFFFF]">Application:</strong> SR Terminal (Institutional ICT Workspace)</div>
            <div><strong className="text-[#FFFFFF]">Developer / Controller:</strong> Suraj Ray</div>
            <div className="flex items-center gap-1.5 text-[#089981]">
              <Mail size={13} />
              <span>surajrayxyz09@gmail.com</span>
            </div>
          </div>
        </section>
      </div>
    </div>
  )
}
