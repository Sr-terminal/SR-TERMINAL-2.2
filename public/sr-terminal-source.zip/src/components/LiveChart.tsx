import { memo, useEffect, useMemo, useRef } from 'react'
import {
  createChart,
  CandlestickSeries,
  LineStyle,
  ColorType,
  CrosshairMode,
  type IChartApi,
  type ISeriesApi,
  type UTCTimestamp,
} from 'lightweight-charts'
import type { Candle } from '../lib/market'
import type { Analysis } from '../lib/ict'
import { getActiveApexKillzoneWindow } from '../lib/clock'
import { run2000PossibilitySimulation } from '../lib/aiServices'

export interface ChartToggles {
  plan: boolean
  levels: boolean
  zones: boolean
  key: boolean
}

export const ICT_CHART_ZONE_COLORS = {
  BULLISH_GREEN: '#00C853',
  BEARISH_RED: '#FF1744',
  APEX_BULLISH_EMERALD: '#00E676',
  APEX_BULLISH_FILL: 'rgba(0, 230, 118, 0.25)',
  APEX_BEARISH_CRIMSON: '#FF1744',
  APEX_BEARISH_FILL: 'rgba(255, 23, 68, 0.25)',
  APEX_LIQUIDITY_GOLD: '#FFD740',
  APEX_UNICORN_PURPLE: '#D500F9',
  APEX_UNICORN_FILL: 'rgba(213, 0, 249, 0.25)',
} as const

export const MONOCHROME_CHART_THEME = {
  backgroundColor: '#000000',
  gridColor: 'rgba(0, 0, 0, 0)',
  crosshairColor: '#CCCCCC',
  priceLineColor: '#CCCCCC',
  priceLabelBg: '#E0E0E0',
  priceLabelText: '#000000',
  axisTextColor: '#EAEAEA',
  upColor: '#FFFFFF',
  downColor: '#000000',
  borderUpColor: '#B2B5BE',
  borderDownColor: '#B2B5BE',
  wickUpColor: '#B2B5BE',
  wickDownColor: '#B2B5BE',
  colorBarsBasedOnPreviousClose: false,
  precision: 'default',
  timezone: 'Asia/Kolkata',
  timezoneLabel: '(UTC+5:30) Kolkata',
  ictBullishGreen: '#00C853',
  ictBearishRed: '#FF1744',
  apexBullishEmerald: '#00E676',
  apexBearishCrimson: '#FF1744',
  apexLiquidityGold: '#FFD740',
  apexUnicornPurple: '#D500F9',
} as const

const VISIBLE_BARS = 90

const LiveChart = memo(function LiveChart({
  candles,
  analysis,
  toggles,
  height,
  showApexPulse = true,
  fullScreen = false,
}: {
  candles: Candle[]
  analysis: Analysis | null
  toggles: ChartToggles
  height?: number
  showApexPulse?: boolean
  fullScreen?: boolean
}) {
  const box = useRef<HTMLDivElement>(null)
  const chart = useRef<IChartApi | null>(null)
  const series = useRef<ISeriesApi<'Candlestick'> | null>(null)
  const currentPriceLineRef = useRef<unknown>(null)
  const lines = useRef<unknown[]>([])
  const lastLen = useRef(0)
  const lastSig = useRef('')
  const lastBarTime = useRef<number>(0)

  const chartH =
    height ??
    (fullScreen
      ? typeof window !== 'undefined'
        ? Math.max(320, window.innerHeight - 140)
        : 560
      : typeof window !== 'undefined' && window.innerWidth < 420
      ? 350
      : 420)

  // Compute live ICT APEX-PULSE HUD telemetry (Killzone Window & >=78% Confluence Score)
  const hudData = useMemo(() => {
    const kz = getActiveApexKillzoneWindow(new Date())
    if (!analysis?.ok || candles.length === 0) {
      return {
        killzone: kz,
        confluenceScorePct: 0,
        passesGate: false,
        sweptLiquidity: 'Awaiting Sweep',
        pdArray: 'Scanning PD Arrays',
      }
    }
    const sim = run2000PossibilitySimulation(
      candles,
      analysis,
      'XAUUSD',
      analysis.interval || '15m'
    )
    const sweptLiquidity =
      analysis.plan?.sweptLiquidityType && analysis.plan.sweptLiquidityType !== 'NONE'
        ? analysis.plan.sweptLiquidityType
        : analysis.phase?.sweptLiquidityType && analysis.phase.sweptLiquidityType !== 'NONE'
        ? analysis.phase.sweptLiquidityType
        : analysis.phase?.sweep
        ? analysis.phase.sweep.dir === 'bull'
          ? 'SSL Swept'
          : 'BSL Swept'
        : 'BSL / SSL Pool'
    const pdArray =
      analysis.plan?.primaryPdArray && analysis.plan.primaryPdArray !== 'NONE'
        ? analysis.plan.primaryPdArray
        : analysis.phase?.primaryPdArray && analysis.phase.primaryPdArray !== 'NONE'
        ? analysis.phase.primaryPdArray
        : (analysis.levels?.unicornZones?.length ?? 0) > 0
        ? 'Unicorn (Breaker+FVG)'
        : (analysis.levels?.fvgZones?.length ?? 0) > 0
        ? 'FVG / OB Array'
        : 'OTE Dealing Range'
    return {
      killzone: kz,
      confluenceScorePct: sim.winProbabilityPct,
      passesGate: sim.passesThreshold,
      sweptLiquidity,
      pdArray,
    }
  }, [candles, analysis])

  useEffect(() => {
    if (!box.current) return
    const istTimeFmt = new Intl.DateTimeFormat('en-IN', {
      timeZone: MONOCHROME_CHART_THEME.timezone,
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
    })
    const istDateTimeFmt = new Intl.DateTimeFormat('en-IN', {
      timeZone: MONOCHROME_CHART_THEME.timezone,
      day: '2-digit',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
    })

    const c = createChart(box.current, {
      width: box.current.clientWidth,
      height: chartH,
      localization: {
        timeFormatter: (timestamp: number) => {
          try {
            return `${istDateTimeFmt.format(new Date(timestamp * 1000))} (UTC+5:30)`
          } catch {
            return String(timestamp)
          }
        },
      },
      layout: {
        background: { type: ColorType.Solid, color: '#000000' },
        textColor: '#EAEAEA',
        fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif',
        fontSize: 10,
      },
      grid: {
        vertLines: { color: 'rgba(0, 0, 0, 0)', visible: false },
        horzLines: { color: 'rgba(0, 0, 0, 0)', visible: false },
      },
      rightPriceScale: {
        borderColor: '#1E222D',
        textColor: '#EAEAEA',
        scaleMargins: { top: 0.08, bottom: 0.08 },
      },
      timeScale: {
        borderColor: '#1E222D',
        timeVisible: true,
        secondsVisible: false,
        rightOffset: 3,
        barSpacing: 6,
        minBarSpacing: 1,
        tickMarkFormatter: (time: number) => {
          try {
            return istTimeFmt.format(new Date(time * 1000))
          } catch {
            return ''
          }
        },
      },
      crosshair: {
        mode: CrosshairMode.Normal,
        vertLine: {
          color: '#CCCCCC',
          width: 1,
          style: LineStyle.Dotted,
          labelBackgroundColor: '#E0E0E0',
        },
        horzLine: {
          color: '#CCCCCC',
          width: 1,
          style: LineStyle.Dotted,
          labelBackgroundColor: '#E0E0E0',
        },
      },
    })

    // Monochrome Black-and-White Institutional Candlestick Theme
    // colorBarsBasedOnPreviousClose: false (standard Open vs Close evaluation)
    const s = c.addSeries(CandlestickSeries, {
      upColor: '#FFFFFF',
      downColor: '#000000',
      borderVisible: true,
      borderUpColor: '#B2B5BE',
      borderDownColor: '#B2B5BE',
      wickVisible: true,
      wickUpColor: '#B2B5BE',
      wickDownColor: '#B2B5BE',
      priceLineVisible: false, // We draw a dedicated thin dotted #CCCCCC price line with #E0E0E0 / #000000 Y-axis badge
      lastValueVisible: false,
      priceFormat: {
        type: 'price',
      },
    })

    chart.current = c
    series.current = s

    const ro = new ResizeObserver(() => {
      if (box.current) {
        const w = box.current.clientWidth
        const h = box.current.clientHeight || chartH
        c.applyOptions({ width: w, height: h })
      }
    })
    ro.observe(box.current)

    return () => {
      ro.disconnect()
      c.remove()
      chart.current = null
      series.current = null
      currentPriceLineRef.current = null
      lastLen.current = 0
      lastSig.current = ''
      lastBarTime.current = 0
    }
  }, [chartH])

  useEffect(() => {
    const s = series.current
    if (!s || candles.length === 0) return
    const data = candles
      .map(k => ({
        time: Math.floor(k.t / 1000) as UTCTimestamp,
        open: k.o,
        high: k.h,
        low: k.l,
        close: k.c,
      }))
      .sort((a, b) => (a.time as number) - (b.time as number))
      .filter((v, i, arr) => i === 0 || v.time !== arr[i - 1].time)
    const n = data.length
    if (n === 0) return

    const stepSec = n > 1 ? (data[1].time as number) - (data[0].time as number) : 0
    const sig = `${data[0].time}_${stepSec}_${data[0].open.toFixed(4)}`
    const lastBar = data[n - 1]
    const ts = chart.current?.timeScale()

    if (lastLen.current === 0 || sig !== lastSig.current) {
      s.setData(data)
      if (ts) {
        ts.setVisibleLogicalRange({ from: Math.max(0, n - VISIBLE_BARS), to: n + 3 })
      }
    } else if (n === lastLen.current && (lastBar.time as number) === lastBarTime.current) {
      try {
        s.update(lastBar)
      } catch {
        s.setData(data)
      }
    } else if (n >= lastLen.current) {
      s.setData(data)
      if (ts) {
        const range = ts.getVisibleLogicalRange()
        if (range && range.to >= lastLen.current - 2) {
          const shift = Math.max(1, n - lastLen.current)
          ts.setVisibleLogicalRange({ from: range.from + shift, to: range.to + shift })
        }
      }
    } else {
      s.setData(data)
      if (ts) {
        ts.setVisibleLogicalRange({ from: Math.max(0, n - VISIBLE_BARS), to: n + 3 })
      }
    }

    // Update thin dotted #CCCCCC Current Price Line with #E0E0E0 Y-axis badge and #000000 black text
    if (currentPriceLineRef.current) {
      try {
        s.removePriceLine(currentPriceLineRef.current as never)
      } catch {}
      currentPriceLineRef.current = null
    }
    try {
      currentPriceLineRef.current = s.createPriceLine({
        price: lastBar.close,
        color: '#CCCCCC',
        lineWidth: 1,
        lineStyle: LineStyle.Dotted,
        axisLabelVisible: true,
        axisLabelColor: '#E0E0E0',
        axisLabelTextColor: '#000000',
        title: '',
      })
    } catch {}

    lastLen.current = n
    lastSig.current = sig
    lastBarTime.current = lastBar.time as number
  }, [candles])

  useEffect(() => {
    const s = series.current
    if (!s) return
    for (const l of lines.current) {
      try {
        s.removePriceLine(l as never)
      } catch {
        /* already gone */
      }
    }
    lines.current = []
    if (!analysis?.ok) return
    const add = (price: number, title: string, color: string, style: LineStyle, width: 1 | 2 = 1) => {
      if (!isFinite(price) || price <= 0) return
      try {
        lines.current.push(
          s.createPriceLine({ price, color, lineWidth: width, lineStyle: style, axisLabelVisible: true, title })
        )
      } catch {
        /* bad price */
      }
    }
    const L = analysis.levels
    if (toggles.levels) {
      add(L.eq, 'EQ (50%)', '#B2B5BE', LineStyle.Dashed, 1)
      // Swept Liquidity / BSL-SSL Pools -> Gold/Amber Dashed Line (#FFD740)
      L.sweptPools?.forEach((sp: { kind: string; price: number }) =>
        add(sp.price, `SWEPT ${sp.kind}`, ICT_CHART_ZONE_COLORS.APEX_LIQUIDITY_GOLD, LineStyle.Dashed, 1)
      )
      // Target Liquidity (BSL) -> Gold/Amber Dashed Line (#FFD740) & GREEN (#00C853)
      L.bsl.forEach((p: number, i: number) =>
        add(
          p,
          i === 0 ? 'BSL POOL (EQH)' : 'BSL',
          i === 0 ? ICT_CHART_ZONE_COLORS.BULLISH_GREEN : ICT_CHART_ZONE_COLORS.APEX_LIQUIDITY_GOLD,
          LineStyle.Dashed,
          i === 0 ? 2 : 1
        )
      )
      // Sell-Side Liquidity (SSL) -> RED (#FF1744) & Gold/Amber Dashed Line (#FFD740)
      L.ssl.forEach((p: number, i: number) =>
        add(
          p,
          i === 0 ? 'SSL POOL (EQL)' : 'SSL',
          i === 0 ? ICT_CHART_ZONE_COLORS.BEARISH_RED : ICT_CHART_ZONE_COLORS.APEX_LIQUIDITY_GOLD,
          LineStyle.Dashed,
          i === 0 ? 2 : 1
        )
      )
      // Premium & Discount OTE Arrays
      if (isFinite(L.rangeHigh) && isFinite(L.eq) && L.rangeHigh > L.eq) {
        add((L.rangeHigh + L.eq) / 2, 'PREMIUM ARRAY', ICT_CHART_ZONE_COLORS.BEARISH_RED, LineStyle.Dotted, 1)
      }
      if (isFinite(L.rangeLow) && isFinite(L.eq) && L.eq > L.rangeLow) {
        add((L.rangeLow + L.eq) / 2, 'DISCOUNT ARRAY', ICT_CHART_ZONE_COLORS.BULLISH_GREEN, LineStyle.Dotted, 1)
      }
      if (L.pdh) add(L.pdh, 'PDH (BSL)', ICT_CHART_ZONE_COLORS.APEX_LIQUIDITY_GOLD, LineStyle.Dashed, 1)
      if (L.pdl) add(L.pdl, 'PDL (SSL)', ICT_CHART_ZONE_COLORS.APEX_LIQUIDITY_GOLD, LineStyle.Dashed, 1)
      if (L.asiaH) add(L.asiaH, 'ASIA HIGH', ICT_CHART_ZONE_COLORS.APEX_LIQUIDITY_GOLD, LineStyle.Dotted, 1)
      if (L.asiaL) add(L.asiaL, 'ASIA LOW', ICT_CHART_ZONE_COLORS.APEX_LIQUIDITY_GOLD, LineStyle.Dotted, 1)
    }
    if (toggles.key) {
      if (L.sth) add(L.sth, 'BSL SWING', ICT_CHART_ZONE_COLORS.BULLISH_GREEN, LineStyle.Dotted, 1)
      if (L.stl) add(L.stl, 'SSL SWING', ICT_CHART_ZONE_COLORS.BEARISH_RED, LineStyle.Dotted, 1)
    }
    if (toggles.zones) {
      // Bullish FVG (BISI) -> Neon Emerald Green (#00E676 / #00C853), Bearish FVG (SIBI) -> Crimson Red (#FF1744)
      L.fvgZones?.forEach((z: { dir: string; top: number; bottom: number }) => {
        const isBull = z.dir === 'bull'
        add(
          (z.top + z.bottom) / 2,
          isBull ? 'FVG (BISI)' : 'FVG (SIBI)',
          isBull ? ICT_CHART_ZONE_COLORS.APEX_BULLISH_EMERALD : ICT_CHART_ZONE_COLORS.APEX_BEARISH_CRIMSON,
          LineStyle.LargeDashed,
          1
        )
      })
      // Inversion FVG (IFVG) — gated by showApexPulse
      if (showApexPulse) {
        L.ifvgZones?.forEach((z: { dir: string; top: number; bottom: number }) => {
          const isBull = z.dir === 'bull'
          add(
            (z.top + z.bottom) / 2,
            isBull ? '+IFVG' : '-IFVG',
            isBull ? ICT_CHART_ZONE_COLORS.APEX_BULLISH_EMERALD : ICT_CHART_ZONE_COLORS.APEX_BEARISH_CRIMSON,
            LineStyle.Dotted,
            1
          )
        })
      }
      // Bullish Order Block (+OB) -> Neon Emerald Green (#00E676 / #00C853), Bearish Order Block (-OB) -> Crimson Red (#FF1744)
      L.obZones?.forEach((z: { dir: { toString(): string } | string; top: number; bottom: number }) => {
        const isBull = z.dir === 'bull'
        add(
          (z.top + z.bottom) / 2,
          isBull ? '+OB' : '-OB',
          isBull ? ICT_CHART_ZONE_COLORS.APEX_BULLISH_EMERALD : ICT_CHART_ZONE_COLORS.APEX_BEARISH_CRIMSON,
          LineStyle.Dashed,
          1
        )
      })
      // Breaker Block / Unicorn Overlap -> Electric Purple (#D500F9) — gated by showApexPulse
      if (showApexPulse) {
        L.unicornZones?.forEach((z: { dir: string; top: number; bottom: number }) => {
          add(
            (z.top + z.bottom) / 2,
            z.dir === 'bull' ? 'UNICORN (+BB+FVG)' : 'UNICORN (-BB+FVG)',
            ICT_CHART_ZONE_COLORS.APEX_UNICORN_PURPLE,
            LineStyle.Solid,
            2
          )
        })
        L.breakerZones?.forEach((z: { dir: string; top: number; bottom: number }) => {
          add(
            (z.top + z.bottom) / 2,
            z.dir === 'bull' ? '+BREAKER' : '-BREAKER',
            ICT_CHART_ZONE_COLORS.APEX_UNICORN_PURPLE,
            LineStyle.Dashed,
            1
          )
        })
      }
    }
    if (toggles.plan) {
      const p = analysis.plan
      if (p && (p.valid || p.entry > 0)) {
        const isLong = p.direction === 'LONG' || p.direction === 'BUY'
        // Buy/Long Execution Level -> GREEN (#00C853), Sell/Short Execution Level -> RED (#FF1744)
        add(
          p.entry,
          isLong ? 'LONG ENTRY' : 'SHORT ENTRY',
          isLong ? ICT_CHART_ZONE_COLORS.BULLISH_GREEN : ICT_CHART_ZONE_COLORS.BEARISH_RED,
          LineStyle.Solid,
          2
        )
        // Stop Loss / Invalidation Level -> RED (#FF1744)
        add(p.stop, 'SL (INVALIDATION)', ICT_CHART_ZONE_COLORS.BEARISH_RED, LineStyle.Dashed, 2)
        // Target Liquidity (Take Profit: 1:2 RR, 1:3.5 RR, 1:5+ RR) -> GREEN (#00C853)
        add(p.tp1, 'TP1 (1:2 RR -> BE)', ICT_CHART_ZONE_COLORS.BULLISH_GREEN, LineStyle.Dashed, 2)
        add(p.tp2, 'TP2 (1:3.5 RR)', ICT_CHART_ZONE_COLORS.BULLISH_GREEN, LineStyle.Dotted, 2)
        add(p.tp3, 'TP3 (1:5+ RR)', ICT_CHART_ZONE_COLORS.BULLISH_GREEN, LineStyle.Dotted, 2)
      }
    }
  }, [analysis, toggles, showApexPulse])

  return (
    <div className={`relative w-full bg-[#000000] ${fullScreen ? 'h-full flex-1 flex flex-col' : 'rounded-[8px]'}`}>
      {/* ICT APEX-PULSE MAIN CHART HUD (Killzone Window + >=78% Confluence Score + Dynamic Zone Legend) */}
      {showApexPulse && (
        <div className="pointer-events-none absolute top-2 left-2 right-16 z-10 flex flex-wrap items-center justify-between gap-1.5">
          <div className="flex flex-wrap items-center gap-1.5">
            <span
              className="inline-flex items-center gap-1 rounded-[4px] border px-2 py-0.5 text-[10px] font-bold tracking-wider uppercase"
              style={{
                backgroundColor: hudData.killzone.isSilverBulletActive ? 'rgba(0, 230, 118, 0.25)' : 'rgba(18, 22, 31, 0.85)',
                borderColor: hudData.killzone.isSilverBulletActive ? '#00E676' : '#262B38',
                color: hudData.killzone.isSilverBulletActive ? '#00E676' : '#B2B5BE',
              }}
            >
              <span
                className="h-1.5 w-1.5 rounded-full"
                style={{ backgroundColor: hudData.killzone.isSilverBulletActive ? '#00E676' : '#FFD740' }}
              />
              {hudData.killzone.shortLabel} · {hudData.killzone.estRange}
            </span>
            {hudData.confluenceScorePct > 0 && (
              <span
                className="inline-flex items-center gap-1 rounded-[4px] border px-2 py-0.5 font-mono text-[10px] font-bold"
                style={{
                  backgroundColor: hudData.passesGate ? 'rgba(0, 230, 118, 0.25)' : 'rgba(255, 23, 68, 0.25)',
                  borderColor: hudData.passesGate ? '#00E676' : '#FF1744',
                  color: hudData.passesGate ? '#00E676' : '#FF1744',
                }}
              >
                APEX CONFLUENCE: {hudData.confluenceScorePct}% {hudData.passesGate ? '(≥78% A+)' : '(<78%)'}
              </span>
            )}
          </div>
          <div className="hidden sm:flex items-center gap-1.5">
            <span
              className="rounded-[3px] px-1.5 py-0.5 text-[9px] font-semibold"
              style={{ backgroundColor: 'rgba(0, 230, 118, 0.25)', color: '#00E676', border: '1px solid #00E676' }}
            >
              +FVG/+OB
            </span>
            <span
              className="rounded-[3px] px-1.5 py-0.5 text-[9px] font-semibold"
              style={{ backgroundColor: 'rgba(255, 23, 68, 0.25)', color: '#FF1744', border: '1px solid #FF1744' }}
            >
              -FVG/-OB
            </span>
            <span
              className="rounded-[3px] px-1.5 py-0.5 text-[9px] font-semibold"
              style={{ backgroundColor: 'rgba(255, 215, 64, 0.18)', color: '#FFD740', border: '1px dashed #FFD740' }}
            >
              BSL/SSL
            </span>
            <span
              className="rounded-[3px] px-1.5 py-0.5 text-[9px] font-semibold"
              style={{ backgroundColor: 'rgba(213, 0, 249, 0.25)', color: '#D500F9', border: '1px solid #D500F9' }}
            >
              UNICORN
            </span>
          </div>
        </div>
      )}

      <div
        ref={box}
        className={`w-full bg-[#000000] ${fullScreen ? 'h-full flex-1' : 'rounded-[8px]'}`}
        style={{ overflow: 'hidden', backgroundColor: '#000000' }}
      />
    </div>
  )
})

export default LiveChart
