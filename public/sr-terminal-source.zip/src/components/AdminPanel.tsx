import React, { useState, useEffect } from 'react'
import {
  Shield,
  Users,
  Search,
  Settings,
  FileText,
  X,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  UserCheck,
  UserX,
  Crown,
  Trash2,
  Lock,
  ArrowLeft,
  Sliders,
  Smartphone,
  Laptop,
  Activity,
  Zap,
  Calendar,
} from 'lucide-react'
import {
  getAdminMetrics,
  searchUsers,
  setAccountStatus,
  grantSubscription,
  revokeSubscription,
  updateSubscriptionExpiry,
  deleteUser,
  saveRemoteConfig,
  fetchAuditLogs,
  subscribeAllUsers,
  getUserEntitlementCategory,
  type AdminMetrics,
  type AdminAuditLog,
  type UserEntitlementCategory,
} from '../lib/adminService'
import { fetchRemoteConfig, type RemoteConfig } from '../lib/remoteConfigService'
import type { UserProfile } from '../lib/authService'
import { apiUrl } from '../lib/apiConfig'

export function extractDeviceInfo(u: UserProfile) {
  const info = u.deviceInfo || ({} as any)
  const ua = info.userAgent || ''
  const isAndroid = info.platform === 'android' || /android/i.test(ua)
  let model = info.deviceModel || (isAndroid ? 'Android Device' : 'Desktop Browser')

  if (ua) {
    if (ua.includes('RMX3867')) model = 'Realme Narzo 70 Pro / P1 5G (RMX3867)'
    else if (ua.includes('RMX')) {
      const m = ua.match(/RMX\d+/i)
      if (m) model = `Realme (${m[0]})`
    } else if (ua.includes('SM-')) {
      const m = ua.match(/SM-[A-Z0-9]+/i)
      if (m) model = `Samsung Galaxy (${m[0]})`
    } else if (ua.includes('Pixel')) {
      const m = ua.match(/Pixel\s*\d+[a-z]?/i)
      if (m) model = `Google ${m[0]}`
    } else if (ua.includes('CPH')) {
      const m = ua.match(/CPH\d+/i)
      if (m) model = `Oppo (${m[0]})`
    }
  }

  let os = info.osVersion || (isAndroid ? 'Android' : 'Desktop OS')
  if (ua && (!os || os === 'Unknown')) {
    const am = ua.match(/Android\s+([0-9\.]+)/i)
    if (am) os = `Android ${am[1]}`
  }

  return {
    isAndroid,
    model,
    os,
    appVersion: u.appVersion || info.appVersion || '2.8.9.19',
    platformText: isAndroid ? 'Android Native App' : 'Web Browser',
    resolution: info.screenResolution || '1080x2400 (Mobile)',
    rawUa: ua,
  }
}

interface AdminPanelProps {
  adminProfile: UserProfile
  onClose: () => void
}

export default function AdminPanel({ adminProfile, onClose }: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState<'metrics' | 'users' | 'config' | 'logs'>('metrics')
  const [loading, setLoading] = useState(false)
  const [statusMsg, setStatusMsg] = useState<{ text: string; type: 'success' | 'error' } | null>(null)

  // Metrics
  const [metrics, setMetrics] = useState<AdminMetrics | null>(null)

  // Users Search & Management
  const [searchQuery, setSearchQuery] = useState('')
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL')
  const [usersList, setUsersList] = useState<UserProfile[]>([])
  const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null)
  const [statusActionReason, setStatusActionReason] = useState('')
  const [grantPlanId, setGrantPlanId] = useState('sr_terminal_30d')
  const [grantDays, setGrantDays] = useState(30)
  const [exactExpiryDate, setExactExpiryDate] = useState('')
  const [showDeleteModal, setShowDeleteModal] = useState(false)
  const [deleteConfirmText, setDeleteConfirmText] = useState('')

  // Remote Config
  const [remoteConfig, setRemoteConfig] = useState<RemoteConfig | null>(null)

  // Audit Logs
  const [auditLogs, setAuditLogs] = useState<AdminAuditLog[]>([])

  // Live Backend & Engine Diagnostics
  const [sysDiag, setSysDiag] = useState<any>(null)

  const loadAllData = async () => {
    setLoading(true)
    setStatusMsg(null)
    try {
      const [c, l, dRes] = await Promise.all([
        fetchRemoteConfig(),
        fetchAuditLogs(50),
        fetch(apiUrl('/api/diagnostics')).then(r => r.ok ? r.json() : null).catch(() => null),
      ])
      setRemoteConfig(c)
      setAuditLogs(l)
      if (dRes) setSysDiag(dRes)
    } catch (err: any) {
      setStatusMsg({ text: err?.message || 'Failed to refresh admin data', type: 'error' })
    } finally {
      setLoading(false)
    }
  }

  // 1. Live Firestore Collection Listener
  // Automatically keeps users list, metrics, and active selection updated in real-time
  useEffect(() => {
    const unsubscribeUsers = subscribeAllUsers((liveUsers, liveMetrics) => {
      setMetrics(liveMetrics)
      setUsersList((prev) => {
        if (!searchQuery.trim()) {
          return liveUsers
        }
        const q = searchQuery.trim().toLowerCase()
        return liveUsers.filter((u) => {
          return (
            (u.uid || '').toLowerCase().includes(q) ||
            (u.email || '').toLowerCase().includes(q) ||
            (u.phone || '').toLowerCase().includes(q) ||
            (u.name || '').toLowerCase().includes(q)
          )
        })
      })

      // Keep currently selected user updated in real time with latest Firestore doc
      setSelectedUser((currentSelected) => {
        if (!currentSelected) return null
        const found = liveUsers.find((u) => u.uid === currentSelected.uid)
        return found || null
      })
    })

    // 2. Fetch remote config, audit logs & server diagnostics
    fetchRemoteConfig().then(setRemoteConfig).catch(() => {})
    fetchAuditLogs(50).then(setAuditLogs).catch(() => {})
    fetch(apiUrl('/api/diagnostics')).then(r => r.ok ? r.json() : null).then(d => { if (d) setSysDiag(d) }).catch(() => {})

    return () => {
      unsubscribeUsers()
    }
  }, [searchQuery])

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      const results = await searchUsers(searchQuery)
      setUsersList(results)
    } catch (err: any) {
      setStatusMsg({ text: 'Search query failed', type: 'error' })
    } finally {
      setLoading(false)
    }
  }

  const handleUpdateUserStatus = async (status: 'active' | 'blocked' | 'suspended') => {
    if (!selectedUser) return
    setLoading(true)
    try {
      await setAccountStatus(adminProfile, selectedUser.uid, status, statusActionReason)
      setStatusMsg({ text: `User status changed to ${status.toUpperCase()} in Firestore (Live Sync)`, type: 'success' })
      setSelectedUser((prev) => (prev ? { ...prev, accountStatus: status } : null))
      setStatusActionReason('')
    } catch (err: any) {
      setStatusMsg({ text: err?.message || 'Status update failed', type: 'error' })
    } finally {
      setLoading(false)
    }
  }

  const handleGrantSubscription = async (overrideDays?: number, overridePlan?: string) => {
    if (!selectedUser) return
    setLoading(true)
    const days = overrideDays ?? grantDays
    const plan = overridePlan ?? grantPlanId
    try {
      await grantSubscription(adminProfile, selectedUser.uid, plan, days, 'Administrative Grant')
      setStatusMsg({ text: `Granted ${days} days of ${plan} in Firestore (Live Sync)`, type: 'success' })
    } catch (err: any) {
      setStatusMsg({ text: err?.message || 'Subscription grant failed', type: 'error' })
    } finally {
      setLoading(false)
    }
  }

  const handleUpdateExactExpiry = async () => {
    if (!selectedUser || !exactExpiryDate) return
    setLoading(true)
    try {
      const isoDate = new Date(exactExpiryDate).toISOString()
      await updateSubscriptionExpiry(adminProfile, selectedUser.uid, isoDate, 'Admin manual expiry update')
      setStatusMsg({ text: `Updated expiry date to ${new Date(isoDate).toLocaleDateString()} (Live Sync)`, type: 'success' })
      setExactExpiryDate('')
    } catch (err: any) {
      setStatusMsg({ text: err?.message || 'Expiry update failed', type: 'error' })
    } finally {
      setLoading(false)
    }
  }

  const handleRevokeSubscription = async () => {
    if (!selectedUser) return
    setLoading(true)
    try {
      await revokeSubscription(adminProfile, selectedUser.uid, 'Administrative Reset to Free Tier')
      setStatusMsg({ text: `Revoked subscription & reset ${selectedUser.uid} to Free Tier (Live Sync)`, type: 'success' })
    } catch (err: any) {
      setStatusMsg({ text: err?.message || 'Revocation failed', type: 'error' })
    } finally {
      setLoading(false)
    }
  }

  const handleDeleteUserAccount = async () => {
    if (!selectedUser || deleteConfirmText !== 'DELETE') return
    setLoading(true)
    try {
      await deleteUser(adminProfile, selectedUser.uid, 'Administrative deletion')
      setStatusMsg({ text: `User ${selectedUser.uid} removed permanently`, type: 'success' })
      setShowDeleteModal(false)
      setSelectedUser(null)
      setDeleteConfirmText('')
      const u = await searchUsers(searchQuery)
      setUsersList(u)
      const m = await getAdminMetrics()
      setMetrics(m)
    } catch (err: any) {
      setStatusMsg({ text: err?.message || 'Deletion failed', type: 'error' })
    } finally {
      setLoading(false)
    }
  }

  const handleSaveConfig = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!remoteConfig) return
    setLoading(true)
    try {
      await saveRemoteConfig(adminProfile, remoteConfig)
      setStatusMsg({ text: 'Remote Configuration saved and published live', type: 'success' })
      const l = await fetchAuditLogs(50)
      setAuditLogs(l)
    } catch (err: any) {
      setStatusMsg({ text: err?.message || 'Failed to save configuration', type: 'error' })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 bg-[#050508] text-white flex flex-col font-sans overflow-hidden fadein">
      {/* Top Header */}
      <div className="flex items-center justify-between px-4 py-3 glass-bar border-b border-[#181820] shrink-0">
        <div className="flex items-center gap-3">
          <div className="p-1.5 rounded-lg bg-amber-400 text-black font-bold">
            <Shield size={16} />
          </div>
          <div>
            <div className="flex items-baseline gap-2">
              <h1 className="display text-sm md:text-base font-bold tracking-tight text-white uppercase">
                SR TERMINAL ADMIN CONSOLE
              </h1>
              <span className="mono text-[10px] font-semibold tracking-widest text-amber-400 uppercase">
                ENTERPRISE RBAC
              </span>
            </div>
            <div className="text-[10px] mono text-neutral-400">
              Administrator: {adminProfile.email || adminProfile.uid}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={loadAllData}
            disabled={loading}
            className="p-2 rounded-lg bg-[#111118] hover:bg-[#1a1a24] border border-[#22222e] text-neutral-300 transition cursor-pointer"
            title="Refresh"
          >
            <RefreshCw size={14} className={loading ? 'animate-spin text-amber-400' : ''} />
          </button>
          <button
            onClick={onClose}
            className="p-2 rounded-lg bg-[#111118] hover:bg-[#1a1a24] border border-[#22222e] text-neutral-400 hover:text-white transition cursor-pointer"
          >
            <X size={16} />
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-[#181820] bg-[#07070b] px-4 gap-2 shrink-0 overflow-x-auto">
        <button
          onClick={() => setActiveTab('metrics')}
          className={`py-2.5 px-3 mono text-xs font-bold border-b-2 transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
            activeTab === 'metrics'
              ? 'border-amber-400 text-amber-400'
              : 'border-transparent text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <Users size={13} />
          <span>METRICS & HEALTH</span>
        </button>
        <button
          onClick={() => setActiveTab('users')}
          className={`py-2.5 px-3 mono text-xs font-bold border-b-2 transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
            activeTab === 'users'
              ? 'border-amber-400 text-amber-400'
              : 'border-transparent text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <Search size={13} />
          <span>USER MANAGEMENT</span>
        </button>
        <button
          onClick={() => setActiveTab('config')}
          className={`py-2.5 px-3 mono text-xs font-bold border-b-2 transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
            activeTab === 'config'
              ? 'border-amber-400 text-amber-400'
              : 'border-transparent text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <Sliders size={13} />
          <span>REMOTE CONFIG</span>
        </button>
        <button
          onClick={() => setActiveTab('logs')}
          className={`py-2.5 px-3 mono text-xs font-bold border-b-2 transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
            activeTab === 'logs'
              ? 'border-amber-400 text-amber-400'
              : 'border-transparent text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <FileText size={13} />
          <span>AUDIT LOGS</span>
        </button>
      </div>

      {/* Status Alert */}
      {statusMsg && (
        <div
          className={`px-4 py-2 text-xs mono flex items-center justify-between shrink-0 ${
            statusMsg.type === 'success'
              ? 'bg-emerald-950/40 border-b border-emerald-900/60 text-emerald-300'
              : 'bg-red-950/40 border-b border-red-900/60 text-red-300'
          }`}
        >
          <div className="flex items-center gap-2">
            {statusMsg.type === 'success' ? <CheckCircle2 size={13} /> : <AlertTriangle size={13} />}
            <span>{statusMsg.text}</span>
          </div>
          <button onClick={() => setStatusMsg(null)} className="text-neutral-400 hover:text-white cursor-pointer">
            <X size={13} />
          </button>
        </div>
      )}

      {/* Main Body */}
      <div className="flex-1 overflow-y-auto p-4 md:p-6">
        {activeTab === 'metrics' && (
          <div className="space-y-5 max-w-5xl mx-auto">
            {/* System & Engine Health Telemetry Strip */}
            <div className="p-3.5 rounded-xl bg-[#0a0a0f] border border-[#181822] flex flex-wrap items-center justify-between gap-3 mono text-xs">
              <div className="flex items-center gap-2">
                <span className="status-dot" />
                <span className="text-neutral-200 font-semibold">
                  SYSTEM HEALTH: {sysDiag?.backgroundEngine?.isRunning ? 'OPERATIONAL (24/7 ENGINE)' : 'ONLINE'}
                </span>
              </div>
              <div className="flex flex-wrap items-center gap-4 text-[11px] text-neutral-400 tabular-nums">
                <span>Active Setups: <strong className="text-white">{sysDiag?.backgroundEngine?.activeTradesCount ?? 0}</strong></span>
                <span>Monitored Pairs: <strong className="text-white">5</strong></span>
                <span>Uptime: <strong className="text-emerald-400">{sysDiag?.uptimeSeconds ? `${Math.floor(sysDiag.uptimeSeconds / 60)}m` : 'Active'}</strong></span>
                <span>Firestore RBAC: <strong className="text-amber-400">ENFORCED</strong></span>
              </div>
            </div>

            {/* Stat Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2.5 tabular-nums">
              <div className="p-3 rounded-xl bg-[#0a0a0e] border border-[#181820]">
                <div className="text-[9px] mono text-neutral-400 uppercase tracking-wider">TOTAL USERS</div>
                <div className="text-xl font-bold mono text-white mt-1">
                  {metrics?.totalUsers ?? '—'}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-[#0a0a0e] border border-[#181820]">
                <div className="text-[9px] mono text-emerald-400 uppercase tracking-wider">ACTIVE USERS</div>
                <div className="text-xl font-bold mono text-emerald-400 mt-1">
                  {metrics?.activeUsers ?? '—'}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-[#0a0a0e] border border-[#181820]">
                <div className="text-[9px] mono text-sky-400 uppercase tracking-wider">FREE USERS</div>
                <div className="text-xl font-bold mono text-sky-400 mt-1">
                  {metrics?.freeUsers ?? '—'}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-[#0a0a0e] border border-[#181820]">
                <div className="text-[9px] mono text-amber-400 uppercase tracking-wider">TRIAL USERS</div>
                <div className="text-xl font-bold mono text-amber-400 mt-1">
                  {metrics?.activeTrials ?? '—'}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-[#0a0a0e] border border-[#181820]">
                <div className="text-[9px] mono text-emerald-300 uppercase tracking-wider">PAID USERS</div>
                <div className="text-xl font-bold mono text-emerald-300 mt-1">
                  {metrics?.activeSubscriptions ?? '—'}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-[#0a0a0e] border border-[#181820]">
                <div className="text-[9px] mono text-neutral-400 uppercase tracking-wider">EXPIRED USERS</div>
                <div className="text-xl font-bold mono text-neutral-400 mt-1">
                  {(metrics?.expiredSubscriptions ?? 0) + (metrics?.expiredTrials ?? 0)}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-[#0a0a0e] border border-[#181820]">
                <div className="text-[9px] mono text-red-400 uppercase tracking-wider">BLOCKED USERS</div>
                <div className="text-xl font-bold mono text-red-400 mt-1">
                  {metrics?.blockedUsers ?? '—'}
                </div>
              </div>
            </div>

            {/* Recent Signups & Logins */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 rounded-xl bg-[#0b0b10] border border-[#1e1e28]">
                <h3 className="text-xs font-mono font-bold text-neutral-300 uppercase mb-3 flex items-center gap-2">
                  <Users size={14} className="text-amber-400" />
                  <span>RECENT USER REGISTRATIONS</span>
                </h3>
                <div className="space-y-2">
                  {metrics?.recentRegistrations.slice(0, 6).map((u) => (
                    <div
                      key={u.uid}
                      onClick={() => {
                        setSelectedUser(u)
                        setActiveTab('users')
                      }}
                      className="p-2 rounded bg-[#101017] border border-[#1c1c24] flex items-center justify-between text-xs cursor-pointer hover:border-amber-400/50 transition"
                    >
                      <div>
                        <div className="font-medium text-white">{u.name || 'Unnamed'}</div>
                        <div className="text-[10px] font-mono text-neutral-400">{u.email || u.phone || u.uid}</div>
                      </div>
                      <div className="text-right">
                        <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-[#1c1c28] text-neutral-300">
                          {u.accountStatus}
                        </span>
                      </div>
                    </div>
                  ))}
                  {(!metrics?.recentRegistrations || metrics.recentRegistrations.length === 0) && (
                    <div className="text-xs text-neutral-500 font-mono py-4 text-center">No users registered yet</div>
                  )}
                </div>
              </div>

              <div className="p-4 rounded-xl bg-[#0b0b10] border border-[#1e1e28]">
                <h3 className="text-xs font-mono font-bold text-neutral-300 uppercase mb-3 flex items-center gap-2">
                  <UserCheck size={14} className="text-emerald-400" />
                  <span>RECENT TRADING ACTIVITY</span>
                </h3>
                <div className="space-y-2">
                  {metrics?.recentLogins.slice(0, 6).map((u) => (
                    <div
                      key={u.uid}
                      onClick={() => {
                        setSelectedUser(u)
                        setActiveTab('users')
                      }}
                      className="p-2 rounded bg-[#101017] border border-[#1c1c24] flex items-center justify-between text-xs cursor-pointer hover:border-amber-400/50 transition"
                    >
                      <div>
                        <div className="font-medium text-white">{u.name || 'Trader'}</div>
                        <div className="text-[10px] font-mono text-neutral-400">
                          Last seen: {new Date(u.lastLoginAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </div>
                      </div>
                      <span className="text-[10px] font-mono text-amber-400">
                        {u.subscriptionStatus === 'active' ? 'PRO' : 'FREE'}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'users' && (
          <div className="space-y-4 max-w-5xl mx-auto">
            {/* Search Bar & Refresh */}
            <div className="flex gap-2">
              <form onSubmit={handleSearch} className="flex-1 flex gap-2">
                <div className="relative flex-1">
                  <Search size={15} className="absolute left-3 top-3 text-neutral-500" />
                  <input
                    type="text"
                    placeholder="Search by UID, Email, Phone, Name, or Device (e.g. Realme, Android)..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 rounded-lg bg-[#0e0e14] border border-[#22222e] text-xs text-white font-mono focus:outline-none focus:border-amber-400"
                  />
                </div>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-amber-400 text-black font-mono text-xs font-bold hover:bg-amber-300 transition cursor-pointer"
                >
                  SEARCH
                </button>
              </form>
              <button
                type="button"
                onClick={loadAllData}
                title="Refresh users and live device status"
                className="px-3 py-2 rounded-lg bg-[#14141e] hover:bg-[#1f1f2e] border border-[#2a2a3c] text-neutral-300 hover:text-white font-mono text-xs font-semibold transition flex items-center gap-1.5 cursor-pointer"
              >
                <RefreshCw size={13} className={loading ? 'animate-spin text-amber-400' : 'text-neutral-400'} />
                <span className="hidden sm:inline">REFRESH</span>
              </button>
            </div>

            {/* Category Filter Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-[11px] font-mono scrollbar-none">
              {[
                { id: 'ALL', label: `All Users (${usersList.length})` },
                { id: 'ANDROID', label: '📱 Android Phones' },
                { id: 'Active Trial', label: 'Active Trial' },
                { id: 'Active Paid Subscription', label: 'Active Paid' },
                { id: 'Blocked', label: 'Blocked' },
                { id: 'Free / None', label: 'Free' },
              ].map((filter) => {
                const isSelected = categoryFilter === filter.id
                return (
                  <button
                    key={filter.id}
                    onClick={() => setCategoryFilter(filter.id)}
                    className={`px-3 py-1 rounded-full whitespace-nowrap transition border cursor-pointer ${
                      isSelected
                        ? 'bg-amber-400 text-black border-amber-400 font-bold'
                        : 'bg-[#0f0f16] text-neutral-400 hover:text-white border-[#242432]'
                    }`}
                  >
                    {filter.label}
                  </button>
                )
              })}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Users List */}
              <div className="md:col-span-1 space-y-2 max-h-[620px] overflow-y-auto pr-1">
                {(() => {
                  const filtered = usersList.filter((u) => {
                    if (categoryFilter === 'ALL') return true
                    if (categoryFilter === 'ANDROID') {
                      const d = extractDeviceInfo(u)
                      return d.isAndroid
                    }
                    return getUserEntitlementCategory(u) === categoryFilter
                  })

                  return (
                    <>
                      <div className="text-[11px] font-mono text-neutral-400 px-1 flex justify-between">
                        <span>REGISTERED USERS & DEVICES ({filtered.length})</span>
                      </div>
                      {filtered.map((u) => {
                        const cat = getUserEntitlementCategory(u)
                        const isTrial = cat.includes('Trial')
                        const isPaid = cat.includes('Paid')
                        const dev = extractDeviceInfo(u)

                        return (
                          <div
                            key={u.uid}
                            onClick={() => setSelectedUser(u)}
                            className={`p-3 rounded-lg border cursor-pointer transition ${
                              selectedUser?.uid === u.uid
                                ? 'bg-[#14141f] border-amber-400 shadow-md shadow-amber-400/10'
                                : 'bg-[#0a0a0e] border-[#1c1c24] hover:border-[#2f2f3e]'
                            }`}
                          >
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-bold text-white truncate max-w-[140px]">
                                {u.name || 'Trader'}
                              </span>
                              <span
                                className={`text-[9px] font-mono px-1.5 py-0.5 rounded uppercase font-semibold ${
                                  cat === 'Active Trial'
                                    ? 'bg-amber-400/20 text-amber-300 border border-amber-400/30'
                                    : cat === 'Active Paid Subscription'
                                    ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-700/50'
                                    : cat === 'Blocked'
                                    ? 'bg-red-950/80 text-red-300 border border-red-800/50'
                                    : 'bg-[#1a1a24] text-neutral-400'
                                }`}
                              >
                                {cat}
                              </span>
                            </div>
                            <div className="text-[10px] font-mono text-neutral-400 truncate mt-1">
                              {u.email || u.phone || u.uid}
                            </div>
                            
                            {/* Device & Hardware Info Badge */}
                            <div className="mt-1.5 flex items-center gap-1.5 text-[10px] font-mono text-amber-300/80 bg-black/40 px-2 py-0.5 rounded border border-[#1f1f2b]">
                              {dev.isAndroid ? <Smartphone size={11} className="text-amber-400" /> : <Laptop size={11} className="text-neutral-400" />}
                              <span className="truncate">{dev.model} · {dev.os}</span>
                            </div>

                            <div className="flex items-center justify-between mt-2 pt-2 border-t border-[#181820] text-[9px] font-mono text-neutral-500">
                              <span className={u.accountStatus === 'active' ? 'text-emerald-400 font-bold' : 'text-red-400 font-bold'}>
                                {u.accountStatus.toUpperCase()}
                              </span>
                              <span className={isPaid ? 'text-emerald-400' : isTrial ? 'text-amber-400' : ''}>
                                {isTrial ? '7-DAY TRIAL' : u.subscriptionPlan || 'FREE'}
                              </span>
                            </div>
                          </div>
                        )
                      })}
                      {filtered.length === 0 && (
                        <div className="p-6 text-center text-neutral-500 font-mono text-xs bg-[#0b0b10] rounded-xl border border-[#1a1a24]">
                          No users matching this filter.
                        </div>
                      )}
                    </>
                  )
                })()}
              </div>

              {/* User Details & Action Panel */}
              <div className="md:col-span-2">
                {selectedUser ? (
                  (() => {
                    const dev = extractDeviceInfo(selectedUser)
                    return (
                      <div className="p-4 md:p-5 rounded-xl bg-[#0b0b10] border border-[#1e1e28] space-y-5">
                        {/* Header */}
                        <div className="flex items-start justify-between border-b border-[#1a1a24] pb-3">
                          <div>
                            <h2 className="text-sm font-bold text-white flex items-center gap-2">
                              <span>{selectedUser.name || 'User Profile'}</span>
                              {dev.isAndroid && (
                                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-400/10 border border-amber-400/30 text-amber-300 flex items-center gap-1 font-normal">
                                  <Smartphone size={10} /> Android Device
                                </span>
                              )}
                            </h2>
                            <div className="text-xs font-mono text-neutral-400 mt-0.5">
                              {selectedUser.email || selectedUser.phone || 'No Contact'}
                            </div>
                          </div>
                          <div className="flex flex-wrap gap-1.5 justify-end">
                            <span className="px-2 py-0.5 rounded text-[10px] font-mono uppercase bg-neutral-800 text-neutral-300">
                              {selectedUser.role}
                            </span>
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-mono uppercase font-bold ${
                                selectedUser.accountStatus === 'active'
                                  ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                                  : 'bg-red-950 text-red-400 border border-red-800'
                              }`}
                            >
                              {selectedUser.accountStatus}
                            </span>
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-mono uppercase font-bold ${
                                getUserEntitlementCategory(selectedUser) === 'Active Trial'
                                  ? 'bg-amber-400/20 text-amber-300 border border-amber-400/40'
                                  : getUserEntitlementCategory(selectedUser) === 'Active Paid Subscription'
                                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                                  : 'bg-[#1b1b26] text-neutral-400'
                              }`}
                            >
                              {getUserEntitlementCategory(selectedUser)}
                            </span>
                          </div>
                        </div>

                        {/* Connected Device & Hardware Telemetry */}
                        <div className="p-3.5 rounded-xl bg-[#0f0f18] border border-amber-400/25 space-y-2.5">
                          <div className="text-xs font-mono font-bold text-amber-400 uppercase flex items-center gap-1.5">
                            <Smartphone size={14} className="text-amber-400" />
                            <span>CONNECTED PHONE / DEVICE HARDWARE</span>
                          </div>
                          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-xs font-mono">
                            <div className="p-2 rounded bg-black/50 border border-[#212130]">
                              <span className="text-neutral-500 text-[10px] block">DEVICE MODEL</span>
                              <div className="text-amber-200 font-semibold truncate mt-0.5">{dev.model}</div>
                            </div>
                            <div className="p-2 rounded bg-black/50 border border-[#212130]">
                              <span className="text-neutral-500 text-[10px] block">OPERATING SYSTEM</span>
                              <div className="text-white font-semibold truncate mt-0.5">{dev.os}</div>
                            </div>
                            <div className="p-2 rounded bg-black/50 border border-[#212130]">
                              <span className="text-neutral-500 text-[10px] block">TERMINAL BUILD</span>
                              <div className="text-white font-semibold truncate mt-0.5">v{dev.appVersion}</div>
                            </div>
                            <div className="p-2 rounded bg-black/50 border border-[#212130]">
                              <span className="text-neutral-500 text-[10px] block">PLATFORM</span>
                              <div className="text-neutral-300 truncate mt-0.5">{dev.platformText}</div>
                            </div>
                            <div className="p-2 rounded bg-black/50 border border-[#212130]">
                              <span className="text-neutral-500 text-[10px] block">SCREEN RESOLUTION</span>
                              <div className="text-neutral-300 truncate mt-0.5">{dev.resolution}</div>
                            </div>
                            <div className="p-2 rounded bg-black/50 border border-[#212130]">
                              <span className="text-neutral-500 text-[10px] block">LAST ACTIVE SEEN</span>
                              <div className="text-emerald-400 font-semibold truncate mt-0.5">
                                {selectedUser.lastLoginAt ? new Date(selectedUser.lastLoginAt).toLocaleString() : 'Just now'}
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Metadata Grid */}
                        <div className="grid grid-cols-2 gap-3 text-xs font-mono">
                          <div className="p-2.5 rounded bg-[#101016] border border-[#1c1c24]">
                            <span className="text-neutral-500 text-[10px]">DATABASE UID</span>
                            <div className="text-neutral-300 truncate mt-0.5">{selectedUser.uid}</div>
                          </div>
                          <div className="p-2.5 rounded bg-[#101016] border border-[#1c1c24]">
                            <span className="text-neutral-500 text-[10px]">SUBSCRIPTION TIER</span>
                            <div className="text-amber-400 mt-0.5 font-bold">
                              {selectedUser.subscriptionPlan || 'none'} ({selectedUser.subscriptionStatus})
                            </div>
                          </div>
                          <div className="p-2.5 rounded bg-[#101016] border border-[#1c1c24]">
                            <span className="text-neutral-500 text-[10px]">REGISTRATION DATE</span>
                            <div className="text-neutral-300 mt-0.5">
                              {selectedUser.createdAt ? new Date(selectedUser.createdAt).toLocaleDateString() : '—'}
                            </div>
                          </div>
                          <div className="p-2.5 rounded bg-[#101016] border border-[#1c1c24]">
                            <span className="text-neutral-500 text-[10px]">SUBSCRIPTION / TRIAL EXPIRY</span>
                            <div className="text-neutral-300 mt-0.5">
                              {selectedUser.subscriptionExpiry || selectedUser.trialExpiry
                                ? new Date(selectedUser.subscriptionExpiry || selectedUser.trialExpiry!).toLocaleDateString()
                                : 'No Active Expiry'}
                            </div>
                          </div>
                        </div>

                        {/* Action 1: Status Toggle */}
                        <div className="p-3.5 rounded-lg bg-[#111118] border border-[#1e1e28] space-y-3">
                          <div className="text-xs font-mono font-bold text-neutral-300 uppercase flex items-center justify-between">
                            <span className="flex items-center gap-1.5">
                              <Lock size={13} className="text-amber-400" />
                              <span>MANUAL ACCOUNT & DEVICE ACCESS CONTROL</span>
                            </span>
                            <span className="text-[10px] text-neutral-500 font-normal">Changes apply live on phone</span>
                          </div>
                          <input
                            type="text"
                            placeholder="Optional action reason (e.g. Manual activation, Suspicious activity)..."
                            value={statusActionReason}
                            onChange={(e) => setStatusActionReason(e.target.value)}
                            className="w-full px-2.5 py-1.5 rounded bg-black border border-[#242430] text-xs text-white font-mono"
                          />
                          <div className="flex gap-2">
                            <button
                              onClick={() => handleUpdateUserStatus('active')}
                              disabled={selectedUser.accountStatus === 'active'}
                              className="flex-1 py-2 rounded bg-emerald-600 hover:bg-emerald-500 disabled:opacity-30 text-white font-mono text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shadow"
                            >
                              <UserCheck size={13} />
                              <span>ACTIVATE DEVICE</span>
                            </button>
                            <button
                              onClick={() => handleUpdateUserStatus('blocked')}
                              disabled={selectedUser.accountStatus === 'blocked'}
                              className="flex-1 py-2 rounded bg-red-600 hover:bg-red-500 disabled:opacity-30 text-white font-mono text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shadow"
                            >
                              <UserX size={13} />
                              <span>BLOCK / LOCKOUT</span>
                            </button>
                            <button
                              onClick={() => handleUpdateUserStatus('suspended')}
                              disabled={selectedUser.accountStatus === 'suspended'}
                              className="flex-1 py-2 rounded bg-amber-600 hover:bg-amber-500 disabled:opacity-30 text-white font-mono text-xs font-bold transition cursor-pointer"
                            >
                              SUSPEND
                            </button>
                          </div>
                        </div>

                        {/* Action 2: Grant / Adjust Subscription */}
                        <div className="p-3.5 rounded-lg bg-[#111118] border border-[#1e1e28] space-y-3">
                          <div className="text-xs font-mono font-bold text-neutral-300 uppercase flex items-center justify-between">
                            <span className="flex items-center gap-1.5">
                              <Crown size={13} className="text-amber-400" />
                              <span>MANUAL SUBSCRIPTION & ENTITLEMENT CONTROL</span>
                            </span>
                          </div>

                          {/* Quick 1-Click Grants */}
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                            <button
                              type="button"
                              onClick={() => handleGrantSubscription(7, 'sr_terminal_7d_trial')}
                              className="py-2 px-2 rounded bg-amber-400/20 hover:bg-amber-400/30 border border-amber-400/50 text-amber-300 font-mono text-[11px] font-bold transition text-center flex items-center justify-center gap-1 cursor-pointer"
                            >
                              <Crown size={12} />
                              <span>GRANT 7-DAY TRIAL</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => handleGrantSubscription(30, 'sr_terminal_30d')}
                              className="py-2 px-2 rounded bg-[#181824] hover:bg-[#222234] border border-[#2b2b3d] text-white font-mono text-[11px] font-semibold transition text-center cursor-pointer"
                            >
                              +30 Days (1 Mo)
                            </button>
                            <button
                              type="button"
                              onClick={() => handleGrantSubscription(60, 'sr_terminal_2m')}
                              className="py-2 px-2 rounded bg-[#181824] hover:bg-[#222234] border border-[#2b2b3d] text-white font-mono text-[11px] font-semibold transition text-center cursor-pointer"
                            >
                              +2 Months (60d)
                            </button>
                            <button
                              type="button"
                              onClick={() => handleGrantSubscription(365, 'sr_terminal_1y')}
                              className="py-2 px-2 rounded bg-[#181824] hover:bg-[#222234] border border-[#2b2b3d] text-white font-mono text-[11px] font-semibold transition text-center cursor-pointer"
                            >
                              +1 Year (365d)
                            </button>
                          </div>

                          {/* Custom Days Input */}
                          <div className="grid grid-cols-2 gap-2 pt-1">
                            <select
                              value={grantPlanId}
                              onChange={(e) => setGrantPlanId(e.target.value)}
                              className="px-2.5 py-1.5 rounded bg-black border border-[#242430] text-xs text-white font-mono"
                            >
                              <option value="sr_terminal_7d_trial">7 Days Trial</option>
                              <option value="sr_terminal_30d">30 Days Plan</option>
                              <option value="sr_terminal_2m">2 Months Plan</option>
                              <option value="sr_terminal_1y">1 Year Plan</option>
                              <option value="sr_terminal_lifetime">Lifetime VIP</option>
                              <option value="custom_admin_grant">Custom Plan</option>
                            </select>
                            <input
                              type="number"
                              value={grantDays}
                              onChange={(e) => setGrantDays(parseInt(e.target.value) || 1)}
                              placeholder="Duration days..."
                              className="px-2.5 py-1.5 rounded bg-black border border-[#242430] text-xs text-white font-mono"
                            />
                          </div>

                          <div className="flex gap-2">
                            <button
                              type="button"
                              onClick={() => handleGrantSubscription()}
                              className="flex-1 py-1.5 rounded bg-amber-400 hover:bg-amber-300 text-black font-mono text-xs font-bold transition flex items-center justify-center gap-1 cursor-pointer"
                            >
                              <Crown size={12} />
                              <span>APPLY CUSTOM DAYS</span>
                            </button>
                            <button
                              type="button"
                              onClick={handleRevokeSubscription}
                              className="py-1.5 px-3 rounded bg-red-950/60 hover:bg-red-900/80 border border-red-800 text-red-300 font-mono text-xs font-bold transition flex items-center justify-center gap-1 cursor-pointer"
                            >
                              <UserX size={12} />
                              <span>REVOKE TO FREE</span>
                            </button>
                          </div>

                          {/* Exact Expiry Date Adjustment */}
                          <div className="pt-2 border-t border-[#1c1c24] space-y-2">
                            <div className="text-[11px] font-mono text-neutral-400 flex items-center justify-between">
                              <span className="flex items-center gap-1">
                                <Calendar size={12} className="text-amber-400" />
                                <span>SET SPECIFIC EXPIRY DATE</span>
                              </span>
                              <span className="text-[10px] text-neutral-400 font-mono">
                                Current: {selectedUser.subscriptionExpiry || selectedUser.trialExpiry ? new Date(selectedUser.subscriptionExpiry || selectedUser.trialExpiry!).toLocaleDateString() : 'None'}
                              </span>
                            </div>
                            <div className="flex gap-2">
                              <input
                                type="date"
                                value={exactExpiryDate}
                                onChange={(e) => setExactExpiryDate(e.target.value)}
                                className="flex-1 px-2.5 py-1.5 rounded bg-black border border-[#242430] text-xs text-white font-mono"
                              />
                              <button
                                type="button"
                                onClick={handleUpdateExactExpiry}
                                disabled={!exactExpiryDate}
                                className="py-1.5 px-3 rounded bg-[#202030] hover:bg-[#2c2c40] disabled:opacity-30 border border-[#303048] text-white font-mono text-xs font-semibold transition cursor-pointer"
                              >
                                UPDATE EXPIRY
                              </button>
                            </div>
                          </div>
                        </div>

                        {/* Action 3: Permanent Deletion */}
                        <div className="pt-2 border-t border-[#1a1a24] flex justify-end">
                          <button
                            onClick={() => setShowDeleteModal(true)}
                            className="px-3 py-1.5 rounded bg-red-950/40 hover:bg-red-900/60 border border-red-900/60 text-red-300 font-mono text-xs transition flex items-center gap-1.5 cursor-pointer"
                          >
                            <Trash2 size={13} />
                            <span>DELETE USER & DEVICE RECORD</span>
                          </button>
                        </div>
                      </div>
                    )
                  })()
                ) : (
                  <div className="p-8 rounded-xl bg-[#0a0a0e] border border-[#1e1e28] text-center text-neutral-500 font-mono text-xs">
                    Select a user from the left column or search above to view details and execute admin actions.
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'config' && (
          <div className="max-w-2xl mx-auto">
            {remoteConfig && (
              <form onSubmit={handleSaveConfig} className="p-5 rounded-xl bg-[#0b0b10] border border-[#1e1e28] space-y-4">
                <div className="flex items-center justify-between border-b border-[#1c1c26] pb-3">
                  <h3 className="text-xs font-mono font-bold text-white uppercase flex items-center gap-2">
                    <Sliders size={14} className="text-amber-400" />
                    <span>SYSTEM & REMOTE CONFIGURATION</span>
                  </h3>
                  <span className="text-[10px] font-mono text-neutral-400">FIRESTORE BACKED</span>
                </div>

                {/* Maintenance Mode Toggle */}
                <div className="flex items-center justify-between p-3 rounded-lg bg-[#111118] border border-[#20202c]">
                  <div>
                    <div className="text-xs font-bold text-white font-mono">MAINTENANCE MODE</div>
                    <div className="text-[11px] text-neutral-400">Blocks non-admin app access with maintenance banner</div>
                  </div>
                  <input
                    type="checkbox"
                    checked={remoteConfig.maintenanceMode}
                    onChange={(e) => setRemoteConfig({ ...remoteConfig, maintenanceMode: e.target.checked })}
                    className="w-5 h-5 accent-amber-400 rounded cursor-pointer"
                  />
                </div>

                {/* App Versions */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-mono text-neutral-400 mb-1">
                      MINIMUM APP VERSION
                    </label>
                    <input
                      type="text"
                      value={remoteConfig.minimumAppVersion}
                      onChange={(e) => setRemoteConfig({ ...remoteConfig, minimumAppVersion: e.target.value })}
                      className="w-full px-3 py-2 rounded bg-black border border-[#242432] text-xs text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-mono text-neutral-400 mb-1">
                      LATEST RELEASE VERSION
                    </label>
                    <input
                      type="text"
                      value={remoteConfig.latestAppVersion}
                      onChange={(e) => setRemoteConfig({ ...remoteConfig, latestAppVersion: e.target.value })}
                      className="w-full px-3 py-2 rounded bg-black border border-[#242432] text-xs text-white font-mono"
                    />
                  </div>
                </div>

                {/* Announcement */}
                <div>
                  <label className="block text-[11px] font-mono text-neutral-400 mb-1">
                    ANNOUNCEMENT BANNER
                  </label>
                  <textarea
                    rows={2}
                    value={remoteConfig.announcement}
                    onChange={(e) => setRemoteConfig({ ...remoteConfig, announcement: e.target.value })}
                    className="w-full px-3 py-2 rounded bg-black border border-[#242432] text-xs text-white font-mono"
                  />
                </div>

                {/* Free Tier Access Policy */}
                <div className="p-4 rounded-lg bg-[#111118] border border-[#20202c] space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-xs font-bold text-white font-mono">FREE TIER ENTITLEMENT POLICY</div>
                      <div className="text-[11px] text-neutral-400">Configure feature access for non-paying traders</div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3 pt-2">
                    <label className="flex items-center justify-between p-2.5 rounded bg-black border border-[#242432] text-xs font-mono text-neutral-300">
                      <span>Trade Plan (SL/TP/Targets)</span>
                      <input
                        type="checkbox"
                        checked={remoteConfig.freeAccessPolicy?.allowTradePlan ?? false}
                        onChange={(e) =>
                          setRemoteConfig({
                            ...remoteConfig,
                            freeAccessPolicy: {
                              ...remoteConfig.freeAccessPolicy,
                              allowedSymbols: remoteConfig.freeAccessPolicy?.allowedSymbols || ['EURUSD'],
                              allowedTimeframes: remoteConfig.freeAccessPolicy?.allowedTimeframes || ['1h', '4h'],
                              allowTradePlan: e.target.checked,
                              allowOrderbook: remoteConfig.freeAccessPolicy?.allowOrderbook ?? false,
                              allowMatrix: remoteConfig.freeAccessPolicy?.allowMatrix ?? false,
                              allowAcademy: remoteConfig.freeAccessPolicy?.allowAcademy ?? false,
                            },
                          })
                        }
                        className="w-4 h-4 accent-amber-400 rounded cursor-pointer"
                      />
                    </label>

                    <label className="flex items-center justify-between p-2.5 rounded bg-black border border-[#242432] text-xs font-mono text-neutral-300">
                      <span>Live Orderbook / DOM</span>
                      <input
                        type="checkbox"
                        checked={remoteConfig.freeAccessPolicy?.allowOrderbook ?? false}
                        onChange={(e) =>
                          setRemoteConfig({
                            ...remoteConfig,
                            freeAccessPolicy: {
                              ...remoteConfig.freeAccessPolicy,
                              allowedSymbols: remoteConfig.freeAccessPolicy?.allowedSymbols || ['EURUSD'],
                              allowedTimeframes: remoteConfig.freeAccessPolicy?.allowedTimeframes || ['1h', '4h'],
                              allowTradePlan: remoteConfig.freeAccessPolicy?.allowTradePlan ?? false,
                              allowOrderbook: e.target.checked,
                              allowMatrix: remoteConfig.freeAccessPolicy?.allowMatrix ?? false,
                              allowAcademy: remoteConfig.freeAccessPolicy?.allowAcademy ?? false,
                            },
                          })
                        }
                        className="w-4 h-4 accent-amber-400 rounded cursor-pointer"
                      />
                    </label>

                    <label className="flex items-center justify-between p-2.5 rounded bg-black border border-[#242432] text-xs font-mono text-neutral-300">
                      <span>Matrix Multi-Asset Scanner</span>
                      <input
                        type="checkbox"
                        checked={remoteConfig.freeAccessPolicy?.allowMatrix ?? false}
                        onChange={(e) =>
                          setRemoteConfig({
                            ...remoteConfig,
                            freeAccessPolicy: {
                              ...remoteConfig.freeAccessPolicy,
                              allowedSymbols: remoteConfig.freeAccessPolicy?.allowedSymbols || ['EURUSD'],
                              allowedTimeframes: remoteConfig.freeAccessPolicy?.allowedTimeframes || ['1h', '4h'],
                              allowTradePlan: remoteConfig.freeAccessPolicy?.allowTradePlan ?? false,
                              allowOrderbook: remoteConfig.freeAccessPolicy?.allowOrderbook ?? false,
                              allowMatrix: e.target.checked,
                              allowAcademy: remoteConfig.freeAccessPolicy?.allowAcademy ?? false,
                            },
                          })
                        }
                        className="w-4 h-4 accent-amber-400 rounded cursor-pointer"
                      />
                    </label>

                    <label className="flex items-center justify-between p-2.5 rounded bg-black border border-[#242432] text-xs font-mono text-neutral-300">
                      <span>14 Books & Strategy Academy</span>
                      <input
                        type="checkbox"
                        checked={remoteConfig.freeAccessPolicy?.allowAcademy ?? false}
                        onChange={(e) =>
                          setRemoteConfig({
                            ...remoteConfig,
                            freeAccessPolicy: {
                              ...remoteConfig.freeAccessPolicy,
                              allowedSymbols: remoteConfig.freeAccessPolicy?.allowedSymbols || ['EURUSD'],
                              allowedTimeframes: remoteConfig.freeAccessPolicy?.allowedTimeframes || ['1h', '4h'],
                              allowTradePlan: remoteConfig.freeAccessPolicy?.allowTradePlan ?? false,
                              allowOrderbook: remoteConfig.freeAccessPolicy?.allowOrderbook ?? false,
                              allowMatrix: remoteConfig.freeAccessPolicy?.allowMatrix ?? false,
                              allowAcademy: e.target.checked,
                            },
                          })
                        }
                        className="w-4 h-4 accent-amber-400 rounded cursor-pointer"
                      />
                    </label>
                  </div>
                </div>

                {/* Support Message */}
                <div>
                  <label className="block text-[11px] font-mono text-neutral-400 mb-1">
                    SUPPORT MESSAGE & CONTACT
                  </label>
                  <input
                    type="text"
                    value={remoteConfig.supportMessage}
                    onChange={(e) => setRemoteConfig({ ...remoteConfig, supportMessage: e.target.value })}
                    className="w-full px-3 py-2 rounded bg-black border border-[#242432] text-xs text-white font-mono"
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-2.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-black font-mono text-xs font-bold transition flex items-center justify-center gap-2"
                >
                  <Sliders size={13} />
                  <span>PUBLISH CONFIGURATION LIVE</span>
                </button>
              </form>
            )}
          </div>
        )}

        {activeTab === 'logs' && (
          <div className="max-w-4xl mx-auto space-y-3">
            <div className="flex items-center justify-between text-xs font-mono text-neutral-400">
              <span>ADMINISTRATIVE AUDIT TRAIL ({auditLogs.length})</span>
              <span>IMMUTABLE LOGS</span>
            </div>

            <div className="space-y-2">
              {auditLogs.map((log, idx) => (
                <div
                  key={log.id || idx}
                  className="p-3 rounded-lg bg-[#0c0c12] border border-[#1e1e28] text-xs font-mono flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="px-1.5 py-0.5 rounded bg-amber-400/20 text-amber-300 text-[10px] font-bold">
                        {log.action}
                      </span>
                      <span className="text-white text-xs">{log.details}</span>
                    </div>
                    {log.targetUserUid && (
                      <div className="text-[10px] text-neutral-500 mt-1">
                        Target UID: {log.targetUserUid}
                      </div>
                    )}
                  </div>
                  <div className="text-right text-[10px] text-neutral-400 shrink-0">
                    <div>{log.adminEmail}</div>
                    <div>{new Date(log.timestamp).toLocaleString()}</div>
                  </div>
                </div>
              ))}
              {auditLogs.length === 0 && (
                <div className="p-8 text-center text-neutral-500 font-mono text-xs">
                  No administrative actions logged yet.
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteModal && selectedUser && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm">
          <div className="p-5 rounded-xl bg-[#121218] border border-red-900/60 max-w-sm w-full space-y-4">
            <div className="flex items-center gap-2 text-red-400 font-bold font-mono text-xs">
              <AlertTriangle size={16} />
              <span>PERMANENT USER DELETION</span>
            </div>
            <p className="text-xs text-neutral-300 leading-relaxed">
              Are you sure you want to delete user <strong>{selectedUser.name || selectedUser.uid}</strong>? This action cannot be undone. Type <strong>DELETE</strong> below to confirm.
            </p>
            <input
              type="text"
              placeholder="Type DELETE..."
              value={deleteConfirmText}
              onChange={(e) => setDeleteConfirmText(e.target.value)}
              className="w-full px-3 py-2 rounded bg-black border border-red-900/50 text-xs text-white font-mono"
            />
            <div className="flex gap-2">
              <button
                onClick={handleDeleteUserAccount}
                disabled={deleteConfirmText !== 'DELETE' || loading}
                className="flex-1 py-2 rounded bg-red-600 hover:bg-red-500 disabled:opacity-40 text-white font-mono text-xs font-bold transition"
              >
                CONFIRM DELETION
              </button>
              <button
                onClick={() => {
                  setShowDeleteModal(false)
                  setDeleteConfirmText('')
                }}
                className="px-4 py-2 rounded bg-[#1c1c26] text-neutral-400 font-mono text-xs"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
