import { memo, useEffect, useState } from 'react'
import { Download, Trash2, X, ChevronDown, ChevronUp, ShieldCheck, AlertTriangle, ShieldAlert, RefreshCw } from 'lucide-react'
import { useJournal } from '../hooks/useJournal'
import {
  isClosed,
  assessTradeRisk,
  sanitizeIctString,
  sanitizeConfluenceTags,
  formatTradeReason,
  formatRMultiple,
  type JournalRecord,
} from '../lib/journal'
import { SYMBOLS, symbolById, fmtPrice, fetchKlines } from '../lib/market'
import { calibrateCandles } from '../lib/brokerCalibration'
import { analyse } from '../lib/ict'
import { loadSelection } from '../lib/concepts'
import { istTimeLabel } from '../lib/clock'
import { evaluateEntitlement } from '../lib/subscriptionService'
import type { UserProfile } from '../lib/authService'
import TerminalLockedScreen from './TerminalLockedScreen'

const STATUS_COLOR: Record<string, string> = {
  PLANNED: '#787B86',
  SETUP_FORMING: '#FFD740',
  ENTRY_CONFIRMED: '#00E676',
  RUNNING: '#FFFFFF',
  TP1: '#00E676',
  TP2: '#00E676',
  TP3: '#00E676',
  BREAKEVEN: '#9CA3AF',
  'CLOSED (BE)': '#9CA3AF',
  CLOSED: '#FFFFFF',
  STOPPED: '#F23645',
  EXPIRED: '#787B86',
  INVALIDATED: '#787B86',
  CANCELLED: '#787B86',
}

function StatusLabel({ status, risky }: { status: string; risky?: boolean }) {
  const displayStatus = status === 'BREAKEVEN' ? 'CLOSED (BE)' : status
  const color = STATUS_COLOR[displayStatus] ?? STATUS_COLOR.PLANNED
  return (
    <span className="text-[10px] font-semibold tracking-wide uppercase whitespace-nowrap tabular-nums" style={{ color }}>
      {displayStatus}
      {risky && !isClosed({ stage: status, status } as never) ? ' · Risk' : ''}
    </span>
  )
}

const RecordRow = memo(function RecordRow({
  r,
  onClose,
  onMoveBE,
}: {
  r: JournalRecord
  onClose: (id: string) => void
  onMoveBE: (id: string, entry: number) => void
}) {
  const [open, setOpen] = useState(false)
  const sym = symbolById(r.symbolId)
  const closed = isClosed(r)
  const isCancelledOrAborted = r.status === 'CANCELLED' || r.stage === 'CANCELLED' || r.status === 'INVALIDATED' || r.status === 'EXPIRED'
  const isClosedBe = r.status === 'CLOSED (BE)' || r.stage === 'CLOSED (BE)' || r.status === 'BREAKEVEN' || r.stage === 'BREAKEVEN'
  const safeR = typeof r.resultR === 'number' && isFinite(r.resultR) && Math.abs(r.resultR) <= 50 ? r.resultR : 0
  const win = !isCancelledOrAborted && safeR > 0.05
  const loss = !isCancelledOrAborted && safeR < -0.05
  const risk = assessTradeRisk(r)
  const isActive = !closed && r.stage !== 'SETUP_FORMING'
  const isBeProtected = Boolean(r.beProtected) || Math.abs((r.entry || 0) - (r.stop || 0)) <= 0.0001 || r.stage === 'TP1' || r.stage === 'TP2'
  const cleanConfluences = sanitizeConfluenceTags(r.confluences)
  const tradeReasonText = formatTradeReason(r)

  return (
    <div className={`card p-3.5 space-y-2.5 ${risk.level === 'HIGH' && !closed ? 'border-[#F23645]' : ''}`}>
      <button className="w-full text-left cursor-pointer active:scale-98" onClick={() => setOpen(o => !o)}>
        <div className="flex flex-wrap items-center justify-between gap-x-2 gap-y-1">
          <div className="flex items-center gap-1.5 min-w-0 flex-1">
            <span
              className="text-[11.5px] font-bold shrink-0"
              style={{ color: r.direction === 'LONG' ? '#00E676' : '#F23645' }}
            >
              {r.direction === 'LONG' ? 'LONG' : 'SHORT'}
            </span>
            <span className="text-[13px] font-semibold text-[#FFFFFF] shrink-0">{r.symbolLabel}</span>
            <span className="text-[11px] text-[#787B86] uppercase shrink-0">{r.tf}</span>
            <span className="text-[11px] text-[#787B86] truncate min-w-0" style={{ textOverflow: 'ellipsis' }}>
              · {sanitizeIctString(r.model)}
            </span>
          </div>
          <div className="flex items-center gap-2 shrink-0 tabular-nums ml-auto">
            {!closed && risk.level === 'HIGH' && (
              <span className="text-[10px] font-bold text-[#F23645]">
                High Risk
              </span>
            )}
            {!closed && isBeProtected && (
              <span className="text-[10px] font-semibold text-[#00E676]">
                BE
              </span>
            )}
            <StatusLabel status={r.status} risky={risk.level === 'HIGH'} />
            {closed && !isCancelledOrAborted && (
              <span
                className="text-[12px] font-semibold tabular-nums"
                style={{ color: win ? '#00E676' : loss ? '#F23645' : '#9CA3AF' }}
              >
                {isClosedBe && Math.abs(safeR) < 0.005 ? '0.00R' : formatRMultiple(safeR)}
              </span>
            )}
            {open ? <ChevronUp size={14} className="text-[#787B86]" /> : <ChevronDown size={14} className="text-[#787B86]" />}
          </div>
        </div>
      </button>

      {/* Always-Visible Price Levels (Entry, SL, TP1, TP2, TP3, Grade) */}
      <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 text-[11.5px] tabular-nums">
        <div className="p-2 rounded-[8px] bg-[#0B0E14] border border-[#1E222D]">
          <div className="label mb-0.5">Entry</div>
          <div className="text-[#FFFFFF] font-semibold">{fmtPrice(r.entry, sym.digits)}</div>
        </div>
        <div className="p-2 rounded-[8px] bg-[#0B0E14] border border-[#1E222D]">
          <div className="label mb-0.5">Stop (SL)</div>
          <div className="text-[#F23645] font-semibold">{fmtPrice(r.stop, sym.digits)}</div>
        </div>
        <div className="p-2 rounded-[8px] bg-[#0B0E14] border border-[#1E222D]">
          <div className="label mb-0.5">TP1</div>
          <div className="text-[#00E676] font-semibold">{fmtPrice(r.tp1, sym.digits)}</div>
        </div>
        <div className="p-2 rounded-[8px] bg-[#0B0E14] border border-[#1E222D]">
          <div className="label mb-0.5">TP2</div>
          <div className="text-[#00E676] font-semibold">{fmtPrice(r.tp2, sym.digits)}</div>
        </div>
        <div className="p-2 rounded-[8px] bg-[#0B0E14] border border-[#1E222D]">
          <div className="label mb-0.5">TP3</div>
          <div className="text-[#00E676] font-semibold">{r.tp3 ? fmtPrice(r.tp3, sym.digits) : '—'}</div>
        </div>
        <div className="p-2 rounded-[8px] bg-[#0B0E14] border border-[#1E222D]">
          <div className="label mb-0.5">Grade / RR</div>
          <div className="text-[#FFFFFF] font-semibold">{r.grade} · 1:{Number(r.rr || 2).toFixed(2)}</div>
        </div>
      </div>

      {/* Always-Visible Trade Reason & Confluences */}
      <div className="p-2.5 rounded-[8px] bg-[#0B0E14] border border-[#1E222D] space-y-1">
        <div className="text-[11.5px] text-[#D1D4DC] leading-relaxed">
          <span className="text-[#787B86] font-semibold">Trade Reason: </span>
          <span>{tradeReasonText}</span>
        </div>
        {cleanConfluences.length > 0 && (
          <div className="text-[10.5px] text-[#787B86] pt-1 border-t border-[#1E222D]">
            Confluences ({cleanConfluences.length}): <span className="text-[#FFFFFF]">{cleanConfluences.join(' · ')}</span>
          </div>
        )}
      </div>

      {/* Quick Actions & Timestamp Footer */}
      <div className="flex flex-wrap items-center justify-between gap-2 text-[10.5px] text-[#787B86] tabular-nums">
        <span>Logged {istTimeLabel(r.createdTs)} · {r.events?.length || 1} lifecycle events</span>
        {!closed && (
          <div className="flex items-center gap-2">
            {!isBeProtected && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation()
                  onMoveBE(r.id, r.entry)
                }}
                className="px-2.5 py-1 bg-[#FFFFFF] text-[#0B0E14] font-semibold rounded-[6px] text-[10px] cursor-pointer active:scale-98"
              >
                Move SL to BE
              </button>
            )}
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation()
                onClose(r.id)
              }}
              className="px-2.5 py-1 bg-[#131722] border border-[#F23645] text-[#F23645] font-semibold rounded-[6px] text-[10px] cursor-pointer active:scale-98"
            >
              {r.stage === 'SETUP_FORMING' ? 'Cancel Setup' : isBeProtected ? 'Close (BE)' : 'Close Trade'}
            </button>
          </div>
        )}
      </div>

      {open && (
        <div className="pt-2.5 border-t border-[#1E222D] space-y-3 fadein">
          {!closed && (
            <div className={`p-3 rounded-[10px] bg-[#0B0E14] border ${risk.level === 'HIGH' ? 'border-[#F23645]' : 'border-[#1E222D]'}`}>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5">
                  {risk.level === 'HIGH' ? (
                    <ShieldAlert size={14} className="text-[#F23645]" />
                  ) : (
                    <AlertTriangle size={14} className="text-[#787B86]" />
                  )}
                  <span className="text-[11px] font-semibold text-[#FFFFFF]">
                    Risk Analysis & Protection
                  </span>
                </div>
                <span
                  className="text-[10.5px] font-bold tabular-nums"
                  style={{
                    color: risk.level === 'HIGH' ? '#F23645' : '#089981',
                  }}
                >
                  Score: {risk.score}/100
                </span>
              </div>

              <div className="space-y-1 my-1.5">
                {risk.reasons.map((reason, idx) => (
                  <div key={idx} className="text-[11px] text-[#787B86] flex items-start gap-1.5">
                    <span className="text-[#FFFFFF]">·</span>
                    <span>{reason}</span>
                  </div>
                ))}
              </div>

              <div className="p-2.5 rounded-[8px] bg-[#131722] border border-[#1E222D] mt-2">
                <div className="text-[11px] font-semibold text-[#FFFFFF] mb-0.5">
                  {risk.recommendedAction}
                </div>
                <p className="text-[10.5px] text-[#787B86] leading-relaxed">
                  When price moves adversely toward the stop, lock Stop Loss at Entry Price (Break-Even).
                </p>
              </div>

              {isActive && (
                <div className="flex gap-2.5 mt-3">
                  <button
                    type="button"
                    onClick={() => onMoveBE(r.id, r.entry)}
                    className="flex-1 min-h-[42px] px-3 rounded-[8px] bg-[#FFFFFF] text-[#0B0E14] font-semibold text-[11.5px] flex items-center justify-center gap-1.5 active:scale-98 cursor-pointer"
                  >
                    <ShieldCheck size={15} /> Move SL to Break-Even
                  </button>
                  <button
                    type="button"
                    onClick={() => onClose(r.id)}
                    className="min-h-[42px] px-4 rounded-[8px] border border-[#F23645] bg-[#131722] text-[#F23645] font-semibold text-[11.5px] flex items-center justify-center gap-1.5 active:scale-98 cursor-pointer"
                  >
                    <X size={14} /> Close
                  </button>
                </div>
              )}
            </div>
          )}

          <div className="space-y-1 pt-1">
            <div className="label mb-1">Trade Lifecycle History</div>
            {r.events.map((e, i) => (
              <div key={i} className="flex justify-between text-[10.5px] text-[#787B86] tabular-nums py-0.5 border-b border-[#1E222D]/60 last:border-b-0">
                <span className="text-[#D1D4DC]">{e.stage}{e.note ? ` — ${e.note}` : ''}</span>
                <span className="shrink-0 ml-2">{istTimeLabel(e.ts)}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
})

export default function JournalScreen({
  userProfile,
  onOpenSubscription,
}: {
  userProfile?: UserProfile | null
  onOpenSubscription?: () => void
}) {
  const entitlement = evaluateEntitlement(userProfile ?? null)
  const journal = useJournal()
  const { stats } = journal
  const [filter, setFilter] = useState<'ALL' | 'OPEN' | 'RISKY' | 'CLOSED'>('ALL')
  const [scanningPairs, setScanningPairs] = useState(false)

  const scanAllPairsForAutoJournal = async () => {
    if (scanningPairs) return
    setScanningPairs(true)
    try {
      const sel = loadSelection()
      for (const s of SYMBOLS) {
        for (const tf of ['15m', '5m']) {
          try {
            const raw = await fetchKlines(s.src, tf, 150)
            if (Array.isArray(raw) && raw.length >= 80) {
              const cal = calibrateCandles(s.id, raw)
              const livePrice = cal[cal.length - 1].c
              const a = analyse(cal, tf, [], sel, { loaded: false, events: [] }, s.digits)
              if (a.ok && a.plan.valid) {
                journal.maybeRecord(a, s.id, s.label, tf, livePrice)
              }
              journal.tick(s.id, livePrice)
            }
          } catch {}
        }
      }
    } finally {
      setScanningPairs(false)
    }
  }

  useEffect(() => {
    if (entitlement.isActive) {
      void scanAllPairsForAutoJournal()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [entitlement.isActive])

  if (!entitlement.isActive) {
    return (
      <TerminalLockedScreen
        userProfile={userProfile ?? null}
        onViewPlans={() => onOpenSubscription?.()}
        onSubscribeNow={() => onOpenSubscription?.()}
      />
    )
  }

  const records = journal.records.filter(r => {
    if (filter === 'ALL') return true
    if (filter === 'OPEN') return !isClosed(r)
    if (filter === 'CLOSED') return isClosed(r)
    if (filter === 'RISKY') {
      const risk = assessTradeRisk(r)
      return !isClosed(r) && (risk.level === 'HIGH' || risk.level === 'MODERATE' || r.risky)
    }
    return true
  })

  const openRiskyCount = journal.records.filter(r => {
    if (isClosed(r)) return false
    const risk = assessTradeRisk(r)
    return risk.level === 'HIGH'
  }).length

  const handleManualCloseWithLivePrice = async (rec: JournalRecord) => {
    let exitPrice = rec.priceAtCreate || rec.entry
    try {
      const symDef = symbolById(rec.symbolId)
      const raw = await fetchKlines(symDef.src, rec.tf || '15m', 5)
      if (Array.isArray(raw) && raw.length > 0) {
        const cal = calibrateCandles(rec.symbolId, raw)
        exitPrice = cal[cal.length - 1].c
      }
    } catch {
      const lastEvWithPrice = [...(rec.events || [])].reverse().find(e => typeof e.price === 'number' && e.price > 0)
      if (lastEvWithPrice?.price) exitPrice = lastEvWithPrice.price
    }
    journal.closeManual(rec.id, exitPrice)
  }

  const doExport = () => {
    const blob = new Blob([JSON.stringify({ exported: new Date().toISOString(), records: journal.records }, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `sr-journal-${new Date().toISOString().slice(0, 10)}.json`
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="p-4 pb-8 max-w-xl mx-auto space-y-3 fadein">
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <div>
          <h1 className="display text-lg font-bold tracking-tight text-[#FFFFFF]">Auto-Journaling & Trade History</h1>
          <p className="text-[11px] text-[#787B86] mt-0.5">Automated ICT execution logs, Trade Reasons, drawdown radar & BE protection</p>
        </div>
        <div className="flex gap-1.5">
          <button
            type="button"
            disabled={scanningPairs}
            onClick={() => void scanAllPairsForAutoJournal()}
            className="chip flex items-center gap-1 cursor-pointer active:scale-98 disabled:opacity-50"
          >
            <RefreshCw size={11} className={scanningPairs ? 'animate-spin' : ''} />
            <span>{scanningPairs ? 'Scanning…' : 'Scan 5 Pairs'}</span>
          </button>
          <button className="chip flex items-center gap-1 cursor-pointer active:scale-98" onClick={doExport}><Download size={11} /> Export</button>
          <button className="chip flex items-center gap-1 cursor-pointer active:scale-98" onClick={() => { if (confirm('Clear all journal records?')) journal.clear() }}><Trash2 size={11} /> Clear</button>
        </div>
      </div>

      {openRiskyCount > 0 && (
        <div className="p-3.5 rounded-[12px] bg-[#131722] border border-[#F23645] flex items-start gap-2.5 text-[#FFFFFF]">
          <ShieldAlert size={17} className="text-[#F23645] shrink-0 mt-0.5" />
          <div className="text-[11.5px]">
            <strong className="text-[#F23645]">Risk Alert: {openRiskyCount} Active Setup Near Invalidation</strong>
            <p className="text-[#787B86] text-[11px] mt-0.5 leading-relaxed">
              Adverse excursion is approaching Stop Loss. Use Move SL to Break-Even on the active trade row below to protect capital.
            </p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-4 gap-3 tabular-nums">
        <div className="card p-3"><div className="label">Trades</div><div className="text-[16px] font-semibold text-[#FFFFFF] mt-1">{stats.total}</div></div>
        <div className="card p-3"><div className="label">Open</div><div className="text-[16px] font-semibold text-[#FFFFFF] mt-1">{stats.open}</div></div>
        <div className="card p-3"><div className="label">Win Rate</div><div className="text-[16px] font-semibold text-[#FFFFFF] mt-1">{stats.closed ? `${stats.winRate}%` : '—'}</div></div>
        <div className="card p-3">
          <div className="label">Total R</div>
          <div
            className="text-[16px] font-semibold mt-1 tabular-nums"
            style={{ color: stats.totalR >= 0 ? '#00E676' : '#F23645' }}
          >
            {stats.totalR >= 0 ? '+' : ''}{stats.totalR}R
          </div>
        </div>
      </div>

      <div className="flex gap-3 px-1 text-[11px] text-[#787B86] tabular-nums">
        <span>Won {stats.wins}</span>
        <span>·</span>
        <span>Lost {stats.losses}</span>
        <span>·</span>
        <span>BE {stats.breakeven}</span>
        <span className="ml-auto text-[#FFFFFF] font-medium">Expectancy {stats.expectancyR >= 0 ? '+' : ''}{stats.expectancyR}R</span>
      </div>

      <div className="seg-tab-group grid-cols-4">
        {(['ALL', 'OPEN', 'RISKY', 'CLOSED'] as const).map(f => (
          <button
            key={f}
            className={`seg-tab active:scale-98 ${filter === f ? 'seg-tab-active' : ''}`}
            onClick={() => setFilter(f)}
          >
            {f === 'RISKY' ? `Risky ${openRiskyCount > 0 ? `(${openRiskyCount})` : ''}` : f.charAt(0) + f.slice(1).toLowerCase()}
          </button>
        ))}
      </div>

      <div className="space-y-3">
        {records.length === 0 && (
          <div className="card p-7 text-center space-y-2">
            <p className="text-[12.5px] text-[#787B86]">
              {filter === 'RISKY' ? 'No active trades currently flagged as high risk.' : 'Scanning live pairs for valid ICT setups to auto-journal…'}
            </p>
            <button
              type="button"
              onClick={() => void scanAllPairsForAutoJournal()}
              className="px-3.5 py-2 rounded-[8px] bg-[#FFFFFF] text-[#0B0E14] font-semibold text-[11.5px] cursor-pointer active:scale-98"
            >
              Scan All 5 Pairs Now
            </button>
          </div>
        )}
        {records.map(r => (
          <RecordRow
            key={r.id}
            r={r}
            onClose={() => { void handleManualCloseWithLivePrice(r) }}
            onMoveBE={(id, entry) => journal.moveToBE(id, entry)}
          />
        ))}
      </div>
    </div>
  )
}
