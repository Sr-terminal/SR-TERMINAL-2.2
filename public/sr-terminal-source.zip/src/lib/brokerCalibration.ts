// @ts-nocheck
import type { Candle } from './market'

interface BenchmarkData {
  price: number
  updatedAt: number
}

// In-memory benchmark cache with realistic baseline values
const benchmarks: Record<string, BenchmarkData> = {
  XAUUSD: { price: 0, updatedAt: 0 },
  GBPUSD: { price: 1.2850, updatedAt: 0 },
  EURUSD: { price: 1.0850, updatedAt: 0 },
  BTCUSD: { price: 0, updatedAt: 0 },
  ETHUSD: { price: 0, updatedAt: 0 },
}

// Ratios to convert raw crypto feed (e.g. GBPUSDT to GBPUSD) with strictly bounded tolerance
const calibrationRatios: Record<string, number> = {
  XAUUSD: 1.0,
  GBPUSD: 1.0,
  EURUSD: 1.0,
  BTCUSD: 1.0,
  ETHUSD: 1.0,
}

const listeners = new Set<() => void>()

function notify() {
  listeners.forEach(fn => {
    try { fn() } catch {}
  })
}

export function onCalibrationChange(listener: () => void): () => void {
  listeners.add(listener)
  return () => {
    listeners.delete(listener)
  }
}

export function getBrokerOffset(symbolId: string): number {
  if (typeof window === 'undefined') return 0
  try {
    const raw = localStorage.getItem(`sr.broker_offset.${symbolId}`)
    return raw ? parseFloat(raw) || 0 : 0
  } catch {
    return 0
  }
}

export function setBrokerOffset(symbolId: string, offset: number): void {
  if (typeof window === 'undefined') return
  try {
    localStorage.setItem(`sr.broker_offset.${symbolId}`, offset.toString())
    notify()
  } catch {}
}

export function resetBrokerOffset(symbolId: string): void {
  if (typeof window === 'undefined') return
  try {
    localStorage.removeItem(`sr.broker_offset.${symbolId}`)
    notify()
  } catch {}
}

export function syncToBrokerPrice(symbolId: string, currentDisplayPrice: number, targetBrokerPrice: number): void {
  if (!isFinite(currentDisplayPrice) || !isFinite(targetBrokerPrice) || targetBrokerPrice <= 0) return
  const currentOffset = getBrokerOffset(symbolId)
  const diff = targetBrokerPrice - currentDisplayPrice
  setBrokerOffset(symbolId, currentOffset + diff)
}

let lastSyncTime = 0
let isSyncing = false

// Track which benchmark timestamp each ratio was anchored against
const ratioAnchoredAt: Record<string, number> = {
  XAUUSD: 0,
  GBPUSD: 0,
  EURUSD: 0,
}

function updateRatiosFromRawPrices(currentRawPrices?: Record<string, number>): boolean {
  if (!currentRawPrices) return false
  let changed = false

  const rawGbp = currentRawPrices.GBPUSDT || currentRawPrices.GBPUSD
  if (rawGbp && rawGbp > 0.5 && benchmarks.GBPUSD.price > 0.5) {
    const newRatio = benchmarks.GBPUSD.price / rawGbp
    if (newRatio >= 0.90 && newRatio <= 1.30 && (ratioAnchoredAt.GBPUSD !== benchmarks.GBPUSD.updatedAt || Math.abs((calibrationRatios.GBPUSD || 1) - newRatio) > 0.0005)) {
      calibrationRatios.GBPUSD = newRatio
      ratioAnchoredAt.GBPUSD = benchmarks.GBPUSD.updatedAt || Date.now()
      changed = true
    }
  }

  const rawPaxg = currentRawPrices.PAXGUSDT || currentRawPrices.XAUUSD
  if (rawPaxg && rawPaxg > 1500 && benchmarks.XAUUSD.price > 1500) {
    const newRatio = benchmarks.XAUUSD.price / rawPaxg
    if (newRatio >= 0.95 && newRatio <= 1.05 && (ratioAnchoredAt.XAUUSD !== benchmarks.XAUUSD.updatedAt || Math.abs((calibrationRatios.XAUUSD || 1) - newRatio) > 0.0005)) {
      calibrationRatios.XAUUSD = newRatio
      ratioAnchoredAt.XAUUSD = benchmarks.XAUUSD.updatedAt || Date.now()
      changed = true
    }
  }

  const rawEur = currentRawPrices.EURUSDT || currentRawPrices.EURUSD
  if (rawEur && rawEur > 0.5 && benchmarks.EURUSD.price > 0.5) {
    const newRatio = benchmarks.EURUSD.price / rawEur
    if (newRatio >= 0.90 && newRatio <= 1.15 && (ratioAnchoredAt.EURUSD !== benchmarks.EURUSD.updatedAt || Math.abs((calibrationRatios.EURUSD || 1) - newRatio) > 0.0005)) {
      calibrationRatios.EURUSD = newRatio
      ratioAnchoredAt.EURUSD = benchmarks.EURUSD.updatedAt || Date.now()
      changed = true
    }
  }

  return changed
}

/**
 * Fetch real interbank spot prices for Forex and Metals to calibrate out any broker divergence.
 */
export async function syncBenchmarks(currentRawPrices?: Record<string, number>): Promise<void> {
  const now = Date.now()
  if (isSyncing) {
    if (updateRatiosFromRawPrices(currentRawPrices)) notify()
    return
  }
  // Limit benchmark external fetching to at most once per 60 seconds
  if (now - lastSyncTime < 60000) {
    if (updateRatiosFromRawPrices(currentRawPrices)) notify()
    return
  }

  isSyncing = true
  lastSyncTime = now
  let changed = false

  try {
    // 1. Fetch live spot Gold (XAU/USD)
    const goldPromise = fetch('https://api.gold-api.com/price/XAU')
      .then(r => r.json())
      .then(data => {
        if (data && typeof data.price === 'number' && data.price > 1000) {
          const prev = benchmarks.XAUUSD.price
          if (!prev || Math.abs(prev - data.price) / prev > 0.0005) {
            benchmarks.XAUUSD = { price: data.price, updatedAt: now }
            changed = true
          }
        }
      })
      .catch(() => null)

    // 2. Fetch live interbank GBP/USD & EUR/USD
    const gbpPromise = fetch('https://api.frankfurter.app/latest?from=GBP&to=USD')
      .then(r => r.json())
      .then(data => {
        if (data && data.rates && typeof data.rates.USD === 'number') {
          const prev = benchmarks.GBPUSD.price
          if (!prev || Math.abs(prev - data.rates.USD) / prev > 0.0005) {
            benchmarks.GBPUSD = { price: data.rates.USD, updatedAt: now }
            changed = true
          }
        }
      })
      .catch(() => null)

    const eurPromise = fetch('https://api.frankfurter.app/latest?from=EUR&to=USD')
      .then(r => r.json())
      .then(data => {
        if (data && data.rates && typeof data.rates.USD === 'number') {
          const prev = benchmarks.EURUSD.price
          if (!prev || Math.abs(prev - data.rates.USD) / prev > 0.0005) {
            benchmarks.EURUSD = { price: data.rates.USD, updatedAt: now }
            changed = true
          }
        }
      })
      .catch(() => null)

    await Promise.all([goldPromise, gbpPromise, eurPromise])

    // Fallback: If any primary failed, check open currency repo
    const needFallback = !benchmarks.GBPUSD.updatedAt || (now - benchmarks.GBPUSD.updatedAt > 300000)
    if (needFallback) {
      try {
        const fbRes = await fetch('https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/usd.json')
        const fb = await fbRes.json()
        if (fb && fb.usd) {
          if (fb.usd.gbp) {
            const p = 1 / fb.usd.gbp
            const prev = benchmarks.GBPUSD.price
            if (!prev || Math.abs(prev - p) / prev > 0.0005) {
              benchmarks.GBPUSD = { price: p, updatedAt: now }
              changed = true
            }
          }
          if (fb.usd.eur) {
            const p = 1 / fb.usd.eur
            const prev = benchmarks.EURUSD.price
            if (!prev || Math.abs(prev - p) / prev > 0.0005) {
              benchmarks.EURUSD = { price: p, updatedAt: now }
              changed = true
            }
          }
          if (fb.usd.xau && (!benchmarks.XAUUSD.updatedAt || now - benchmarks.XAUUSD.updatedAt > 300000)) {
            const p = 1 / fb.usd.xau
            const prev = benchmarks.XAUUSD.price
            if (!prev || Math.abs(prev - p) / prev > 0.0005) {
              benchmarks.XAUUSD = { price: p, updatedAt: now }
              changed = true
            }
          }
        }
      } catch {}
    }

    if (updateRatiosFromRawPrices(currentRawPrices)) {
      changed = true
    }

    if (changed) {
      notify()
    }
  } catch (err) {
    console.warn('Benchmark sync failed:', err)
  } finally {
    isSyncing = false
  }
}

// Auto-sync in background every 120s (in browser; server engine calls syncBenchmarks on cycle)
if (typeof window !== 'undefined') {
  setTimeout(() => syncBenchmarks(), 500)
  setInterval(() => syncBenchmarks(), 120000)
}

export function getCalibrationMultiplier(symbolId: string, rawPrice?: number): number {
  if (symbolId === 'GBPUSD') {
    if (
      rawPrice &&
      rawPrice > 0.5 &&
      benchmarks.GBPUSD.price > 0.5 &&
      benchmarks.GBPUSD.updatedAt > 0 &&
      ratioAnchoredAt.GBPUSD !== benchmarks.GBPUSD.updatedAt
    ) {
      const calculatedRatio = benchmarks.GBPUSD.price / rawPrice
      if (calculatedRatio >= 0.90 && calculatedRatio <= 1.30) {
        calibrationRatios.GBPUSD = calculatedRatio
        ratioAnchoredAt.GBPUSD = benchmarks.GBPUSD.updatedAt
      }
    }
    const ratio = calibrationRatios.GBPUSD ?? 1.0
    return ratio >= 0.90 && ratio <= 1.30 ? ratio : 1.0
  }
  if (symbolId === 'XAUUSD') {
    if (
      rawPrice &&
      rawPrice > 1500 &&
      benchmarks.XAUUSD.price > 1500 &&
      benchmarks.XAUUSD.updatedAt > 0 &&
      ratioAnchoredAt.XAUUSD !== benchmarks.XAUUSD.updatedAt
    ) {
      const calculatedRatio = benchmarks.XAUUSD.price / rawPrice
      // Paxos Gold is 1:1 physical gold backed; sanity range strictly [0.95, 1.05]
      if (calculatedRatio >= 0.95 && calculatedRatio <= 1.05) {
        calibrationRatios.XAUUSD = calculatedRatio
        ratioAnchoredAt.XAUUSD = benchmarks.XAUUSD.updatedAt
      }
    }
    const ratio = calibrationRatios.XAUUSD ?? 1.0
    return ratio >= 0.95 && ratio <= 1.05 ? ratio : 1.0
  }
  if (symbolId === 'EURUSD') {
    if (
      rawPrice &&
      rawPrice > 0.5 &&
      benchmarks.EURUSD.price > 0.5 &&
      benchmarks.EURUSD.updatedAt > 0 &&
      ratioAnchoredAt.EURUSD !== benchmarks.EURUSD.updatedAt
    ) {
      const calculatedRatio = benchmarks.EURUSD.price / rawPrice
      if (calculatedRatio >= 0.90 && calculatedRatio <= 1.15) {
        calibrationRatios.EURUSD = calculatedRatio
        ratioAnchoredAt.EURUSD = benchmarks.EURUSD.updatedAt
      }
    }
    const ratio = calibrationRatios.EURUSD ?? 1.0
    return ratio >= 0.90 && ratio <= 1.15 ? ratio : 1.0
  }
  return 1.0
}

export function calibratePrice(symbolId: string, rawPrice: number): number {
  if (!isFinite(rawPrice) || rawPrice <= 0) return rawPrice
  const mult = getCalibrationMultiplier(symbolId, rawPrice)
  const offset = getBrokerOffset(symbolId)
  return (rawPrice * mult) + offset
}

export function calibrateCandle(symbolId: string, candle: Candle): Candle {
  const mult = getCalibrationMultiplier(symbolId, candle.c)
  const offset = getBrokerOffset(symbolId)
  const out: Candle = {
    t: candle.t,
    o: (candle.o * mult) + offset,
    h: (candle.h * mult) + offset,
    l: (candle.l * mult) + offset,
    c: (candle.c * mult) + offset,
    v: candle.v,
    final: candle.final,
  }
  if (candle._meta) {
    Object.defineProperty(out, '_meta', {
      value: candle._meta,
      enumerable: false,
      configurable: true,
      writable: true,
    })
  }
  return out
}

export function calibrateCandles(symbolId: string, candles: Candle[]): Candle[] {
  if (!candles || candles.length === 0) return []
  const lastC = candles[candles.length - 1].c
  const mult = getCalibrationMultiplier(symbolId, lastC)
  const offset = getBrokerOffset(symbolId)
  if (Math.abs(mult - 1.0) < 0.00001 && offset === 0) {
    return candles
  }
  return candles.map(c => {
    const out: Candle = {
      t: c.t,
      o: (c.o * mult) + offset,
      h: (c.h * mult) + offset,
      l: (c.l * mult) + offset,
      c: (c.c * mult) + offset,
      v: c.v,
      final: c.final,
    }
    if (c._meta) {
      Object.defineProperty(out, '_meta', {
        value: c._meta,
        enumerable: false,
        configurable: true,
        writable: true,
      })
    }
    return out
  })
}
