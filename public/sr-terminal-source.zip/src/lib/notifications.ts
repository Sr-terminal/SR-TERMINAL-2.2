import { safeStorage } from './storage'
import { Capacitor } from '@capacitor/core'

export interface NotificationPrefs {
  planCreated: boolean
  executed: boolean
  tp1: boolean
  tp2: boolean
  tp3: boolean
  moveBE: boolean
  beClosed: boolean
  stop: boolean
  riskAlert: boolean
  manualClosed: boolean
  updates: boolean
  sound: boolean
  vibrate: boolean
  [key: string]: boolean
}

const NOTIF_KEY = 'sr.notif.prefs'

export const DEFAULT_NOTIF_PREFS: NotificationPrefs = {
  planCreated: true,
  executed: true,
  tp1: true,
  tp2: true,
  tp3: true,
  moveBE: true,
  beClosed: true,
  stop: true,
  riskAlert: true,
  manualClosed: false,
  updates: true,
  sound: true,
  vibrate: true,
}

export function getNotificationPrefs(): NotificationPrefs {
  try {
    const raw = safeStorage.getItem(NOTIF_KEY)
    if (!raw) return { ...DEFAULT_NOTIF_PREFS }
    return { ...DEFAULT_NOTIF_PREFS, ...JSON.parse(raw) }
  } catch {
    return { ...DEFAULT_NOTIF_PREFS }
  }
}

export function saveNotificationPrefs(prefs: Partial<NotificationPrefs>): NotificationPrefs {
  try {
    const current = getNotificationPrefs()
    const updated = { ...current, ...prefs }
    safeStorage.setItem(NOTIF_KEY, JSON.stringify(updated))
    return updated
  } catch {
    return { ...DEFAULT_NOTIF_PREFS }
  }
}

export function isNativePlatform(): boolean {
  if (typeof window === 'undefined') return false
  return Boolean((window as any).AndroidBridge) || Capacitor.isNativePlatform()
}

export async function areNotificationsEnabled(): Promise<boolean> {
  if (typeof window === 'undefined') return false

  // Capacitor Native Notifications (Android APK)
  if (Capacitor.isNativePlatform()) {
    try {
      const { LocalNotifications } = await import('@capacitor/local-notifications')
      const status = await LocalNotifications.checkPermissions()
      return status.display === 'granted'
    } catch {
      return false
    }
  }

  // Android Native Bridge
  if ((window as any).AndroidBridge?.areNotificationsEnabled) {
    try {
      return Boolean((window as any).AndroidBridge.areNotificationsEnabled())
    } catch {
      return true
    }
  }

  // Web Notification API
  if ('Notification' in window) {
    return Notification.permission === 'granted'
  }

  return true
}

const HIGH_IMPORTANCE_CHANNEL_ID = 'sr-trade-alerts-v2'
let channelInitialized = false
let notifSequence = 0

function nextUniqueNotificationId(): number {
  notifSequence = (notifSequence + 1) % 1000
  // Guaranteed unique positive 31-bit integer safe for Android NotificationManager & Capacitor LocalNotifications
  return Math.floor((Date.now() % 2000000) * 1000 + notifSequence)
}

async function ensureHighImportanceChannel(): Promise<void> {
  if (channelInitialized || typeof window === 'undefined' || !Capacitor.isNativePlatform()) return
  try {
    const { LocalNotifications } = await import('@capacitor/local-notifications')
    await LocalNotifications.createChannel({
      id: HIGH_IMPORTANCE_CHANNEL_ID,
      name: 'SR Terminal High Priority Alerts',
      description: 'Real-time ICT trade signals, target hits, and AI agent completion alerts',
      importance: 5, // NotificationManager.IMPORTANCE_HIGH (heads-up popup + sound + vibration)
      visibility: 1, // Notification.VISIBILITY_PUBLIC
      vibration: true,
      lights: true,
    })
    channelInitialized = true
  } catch {
    // Channel creation handled by native Java fallback if plugin is unavailable
  }
}

export async function requestNotificationPermission(): Promise<boolean> {
  if (typeof window === 'undefined') return false

  // 1. Android Native Bridge (requests POST_NOTIFICATIONS on Android 13+ API 33+)
  if ((window as any).AndroidBridge?.requestPermission) {
    try {
      ;(window as any).AndroidBridge.requestPermission()
    } catch {
      // continue to Capacitor/Web checks
    }
  }

  // 2. Capacitor Native Notifications (Android APK)
  if (Capacitor.isNativePlatform()) {
    try {
      const { LocalNotifications } = await import('@capacitor/local-notifications')
      await ensureHighImportanceChannel()
      const status = await LocalNotifications.checkPermissions()
      if (status.display === 'granted') return true
      const res = await LocalNotifications.requestPermissions()
      return res.display === 'granted'
    } catch {
      return Boolean((window as any).AndroidBridge)
    }
  }

  // 3. Web Notification API
  if ('Notification' in window) {
    try {
      if (Notification.permission === 'granted') return true
      const res = await Notification.requestPermission()
      return res === 'granted'
    } catch {
      return false
    }
  }

  return true
}

/**
 * Plays a clean harmonic alert sound via Web Audio API
 */
export function playAlertChime() {
  if (typeof window === 'undefined') return
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext
    if (!AudioContextClass) return
    const ctx = new AudioContextClass()
    if (ctx.state === 'suspended') {
      ctx.resume().catch(() => {})
    }

    const now = ctx.currentTime
    const osc1 = ctx.createOscillator()
    const osc2 = ctx.createOscillator()
    const gain = ctx.createGain()

    osc1.type = 'sine'
    osc1.frequency.setValueAtTime(880, now) // A5
    osc1.frequency.exponentialRampToValueAtTime(1318.51, now + 0.18) // E6

    osc2.type = 'triangle'
    osc2.frequency.setValueAtTime(440, now)
    osc2.frequency.exponentialRampToValueAtTime(880, now + 0.18)

    gain.gain.setValueAtTime(0.2, now)
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35)

    osc1.connect(gain)
    osc2.connect(gain)
    gain.connect(ctx.destination)

    osc1.start(now)
    osc2.start(now)
    osc1.stop(now + 0.36)
    osc2.stop(now + 0.36)
  } catch {}
}

const TYPE_KEY_MAP: Record<string, keyof NotificationPrefs> = {
  PRE_TRADE_APPROACHING: 'planCreated',
  PLAN_CREATED: 'planCreated',
  ENTRY_CONFIRMED: 'executed',
  TRADE_EXECUTED: 'executed',
  TP1_HIT: 'tp1',
  TP2_HIT: 'tp2',
  TP3_HIT: 'tp3',
  MOVE_BREAKEVEN: 'moveBE',
  BREAKEVEN: 'beClosed',
  BREAKEVEN_CLOSED: 'beClosed',
  STOP_HIT: 'stop',
  RISK_ALERT: 'riskAlert',
  MANUAL_CLOSED: 'manualClosed',
  INVALIDATED: 'updates',
  EXPIRED: 'updates',
  UPDATE: 'updates',
  AI_AGENT_UPDATE: 'updates',
  TASK_COMPLETE: 'updates',
  TEST: 'updates',
}

/**
 * Unified notification dispatcher for Android Native APK and Web Browser
 */
export async function sendTradeNotification(type: string, title: string, body: string): Promise<boolean> {
  if (typeof window === 'undefined') return false

  const prefs = getNotificationPrefs()
  const prefKey = TYPE_KEY_MAP[type]
  if (prefKey && prefs[prefKey] === false) {
    return false
  }

  // 1. Play sound if enabled
  if (prefs.sound !== false) {
    playAlertChime()
  }

  // 2. Vibrate if enabled and available
  if (prefs.vibrate !== false && typeof navigator !== 'undefined' && navigator.vibrate) {
    try {
      navigator.vibrate([120, 60, 180])
    } catch {}
  }

  const uniqueId = nextUniqueNotificationId()
  let sent = false

  // 3. Direct Android Native Bridge (Immediate heads-up notification via NotificationManager.IMPORTANCE_HIGH)
  if ((window as any).AndroidBridge?.postNotification) {
    try {
      ;(window as any).AndroidBridge.postNotification(title, body)
      sent = true
    } catch (e) {
      console.warn('AndroidBridge notification failed:', e)
    }
  }

  // 4. Capacitor Native Notifications (Android APK)
  if (!sent && Capacitor.isNativePlatform()) {
    try {
      const { LocalNotifications } = await import('@capacitor/local-notifications')
      await ensureHighImportanceChannel()
      await LocalNotifications.schedule({
        notifications: [
          {
            title,
            body,
            id: uniqueId,
            channelId: HIGH_IMPORTANCE_CHANNEL_ID,
            schedule: { at: new Date(Date.now() + 50), allowWhileIdle: true },
            sound: prefs.sound !== false ? 'beep.wav' : undefined,
            actionTypeId: '',
            extra: { type, notificationId: uniqueId },
          },
        ],
      })
      sent = true
    } catch (e) {
      console.warn('Capacitor LocalNotifications dispatch notice:', e)
    }
  }

  // 5. Web / PWA ServiceWorker & Notification API (works when tab is minimized/backgrounded)
  if (!sent && 'Notification' in window) {
    try {
      if (Notification.permission === 'default') {
        await Notification.requestPermission()
      }
      if (Notification.permission === 'granted') {
        if ('serviceWorker' in navigator) {
          const reg = await navigator.serviceWorker.getRegistration()
          if (reg && typeof reg.showNotification === 'function') {
            await reg.showNotification(title, {
              body,
              icon: '/favicon.ico',
              tag: `sr-${uniqueId}`,
              renotify: true,
              vibrate: [200, 100, 250],
            } as any)
            sent = true
          }
        }
        if (!sent) {
          new Notification(title, {
            body,
            icon: '/favicon.ico',
            tag: `sr-${uniqueId}`,
          })
          sent = true
        }
      }
    } catch (e) {
      console.warn('Web notification failed:', e)
    }
  }

  // 6. In-app custom event for visual alerts/toasts
  try {
    window.dispatchEvent(new CustomEvent('sr-notification', { detail: { id: uniqueId, type, title, body } }))
  } catch {}

  return sent
}

export function requestBatteryOptimizationExemption(): boolean {
  if (typeof window === 'undefined') return false
  try {
    if ((window as any).AndroidBridge?.requestBatteryOptimizationExemption) {
      ;(window as any).AndroidBridge.requestBatteryOptimizationExemption()
      return true
    }
  } catch {}
  return false
}

export function testNotification(): Promise<boolean> {
  return sendTradeNotification(
    'TEST',
    '⚡ [ICT APEX-PULSE] XAUUSD BUY | Entry: 2750.50 | SL: 2742.00 | TP1: 2767.50 | Confluence: 86% (Swept SSL (PDL) + Bullish FVG (+OB))',
    '⚡ [ICT APEX-PULSE] High-Priority Channel (IMPORTANCE_HIGH), 30s Background Heartbeat, Sound & Vibration 100% Active!'
  )
}
