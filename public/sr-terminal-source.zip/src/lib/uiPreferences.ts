import { safeStorage } from './storage'
import { ChartToggles } from '../components/LiveChart'

export interface SymbolUiPreferences {
  chartToggles?: Partial<ChartToggles>
  chartView?: 'SR' | 'TV'
}

export interface GlobalUiPreferences {
  toggles: ChartToggles
  chartView: 'SR' | 'TV'
  symbolOverrides: Record<string, SymbolUiPreferences>
}

const UI_PREFS_KEY = 'sr.ui.preferences.v1'

const DEFAULT_TOGGLES: ChartToggles = {
  plan: true,
  levels: true,
  zones: true,
  key: true,
}

const DEFAULT_PREFS: GlobalUiPreferences = {
  toggles: { ...DEFAULT_TOGGLES },
  chartView: 'SR',
  symbolOverrides: {},
}

let cachedPrefs: GlobalUiPreferences | null = null

function loadPreferences(): GlobalUiPreferences {
  if (cachedPrefs) return cachedPrefs
  try {
    const raw = safeStorage.getItem(UI_PREFS_KEY)
    if (!raw) {
      cachedPrefs = { ...DEFAULT_PREFS, toggles: { ...DEFAULT_TOGGLES }, symbolOverrides: {} }
      return cachedPrefs
    }
    const parsed = JSON.parse(raw)
    cachedPrefs = {
      toggles: {
        plan: typeof parsed?.toggles?.plan === 'boolean' ? parsed.toggles.plan : DEFAULT_TOGGLES.plan,
        levels: typeof parsed?.toggles?.levels === 'boolean' ? parsed.toggles.levels : DEFAULT_TOGGLES.levels,
        zones: typeof parsed?.toggles?.zones === 'boolean' ? parsed.toggles.zones : DEFAULT_TOGGLES.zones,
        key: typeof parsed?.toggles?.key === 'boolean' ? parsed.toggles.key : DEFAULT_TOGGLES.key,
      },
      chartView: parsed?.chartView === 'TV' ? 'TV' : 'SR',
      symbolOverrides: parsed?.symbolOverrides && typeof parsed.symbolOverrides === 'object' ? parsed.symbolOverrides : {},
    }
    return cachedPrefs
  } catch {
    cachedPrefs = { ...DEFAULT_PREFS, toggles: { ...DEFAULT_TOGGLES }, symbolOverrides: {} }
    return cachedPrefs
  }
}

function persistPreferences(prefs: GlobalUiPreferences): void {
  cachedPrefs = prefs
  try {
    safeStorage.setItem(UI_PREFS_KEY, JSON.stringify(prefs))
  } catch {}
}

/**
 * Get effective ChartToggles for a specific symbol.
 * If user has set an override for this symbol, use it; otherwise fall back to global toggle preference.
 */
export function getChartToggles(symbolId: string): ChartToggles {
  const prefs = loadPreferences()
  const symOverride = prefs.symbolOverrides[symbolId]?.chartToggles
  return {
    plan: typeof symOverride?.plan === 'boolean' ? symOverride.plan : prefs.toggles.plan,
    levels: typeof symOverride?.levels === 'boolean' ? symOverride.levels : prefs.toggles.levels,
    zones: typeof symOverride?.zones === 'boolean' ? symOverride.zones : prefs.toggles.zones,
    key: typeof symOverride?.key === 'boolean' ? symOverride.key : prefs.toggles.key,
  }
}

/**
 * Save ChartToggles for a specific symbol or globally.
 * Persists in safeStorage so it survives refresh, pair switch, backgrounding, and restart.
 */
export function setChartToggle(symbolId: string, key: keyof ChartToggles, value: boolean, symbolSpecific = false): ChartToggles {
  const prefs = loadPreferences()
  if (symbolSpecific) {
    const existing = prefs.symbolOverrides[symbolId] || {}
    const existingToggles = existing.chartToggles || {}
    const updated = {
      ...prefs,
      symbolOverrides: {
        ...prefs.symbolOverrides,
        [symbolId]: {
          ...existing,
          chartToggles: {
            ...existingToggles,
            [key]: value,
          },
        },
      },
    }
    persistPreferences(updated)
    return getChartToggles(symbolId)
  } else {
    // Update global and clear specific override for clean consistency
    const updated = {
      ...prefs,
      toggles: {
        ...prefs.toggles,
        [key]: value,
      },
    }
    persistPreferences(updated)
    return getChartToggles(symbolId)
  }
}

/**
 * Save complete ChartToggles for a specific symbol.
 */
export function saveChartToggles(symbolId: string, toggles: ChartToggles, symbolSpecific = false): void {
  const prefs = loadPreferences()
  if (symbolSpecific) {
    const existing = prefs.symbolOverrides[symbolId] || {}
    const updated = {
      ...prefs,
      symbolOverrides: {
        ...prefs.symbolOverrides,
        [symbolId]: {
          ...existing,
          chartToggles: { ...toggles },
        },
      },
    }
    persistPreferences(updated)
  } else {
    const updated = {
      ...prefs,
      toggles: { ...toggles },
    }
    persistPreferences(updated)
  }
}

/**
 * Get saved ChartView ('SR' | 'TV')
 */
export function getSavedChartView(): 'SR' | 'TV' {
  return loadPreferences().chartView
}

/**
 * Save ChartView ('SR' | 'TV')
 */
export function saveChartView(view: 'SR' | 'TV'): void {
  const prefs = loadPreferences()
  persistPreferences({
    ...prefs,
    chartView: view,
  })
}
