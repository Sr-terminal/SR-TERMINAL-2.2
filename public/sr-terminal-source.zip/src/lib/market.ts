import {
  validateTickFreshness,
  computeExecutionEfficiencyPct,
  type TickMetadata,
  type LiveDataStatus,
  type CandleExecutionMeta,
  type ExecutionMetadataStream,
  SILENT_FEED_THRESHOLD_MS,
} from './dataIntegrity'

export type { CandleExecutionMeta, ExecutionMetadataStream }

export interface SymbolDef {
  id: string
  label: string
  src: string
  tv: string
  kind: 'METAL' | 'FX' | 'CRYPTO'
  digits: number
}

export interface IntervalDef {
  id: string
  label: string
  role: string
}

export interface Candle {
  t: number
  o: number
  h: number
  l: number
  c: number
  v: number
  final?: boolean
  _meta?: CandleExecutionMeta
}

export interface Ticker {
  symbol: string
  price: number
  changePct: number
}

export const SYMBOLS: SymbolDef[] = [
  { id: 'XAUUSD', label: 'GOLD', src: 'PAXGUSDT', tv: 'OANDA:XAUUSD', kind: 'METAL', digits: 2 },
  { id: 'EURUSD', label: 'EUR/USD', src: 'EURUSDT', tv: 'OANDA:EURUSD', kind: 'FX', digits: 5 },
  { id: 'GBPUSD', label: 'GBP/USD', src: 'GBPUSDT', tv: 'OANDA:GBPUSD', kind: 'FX', digits: 5 },
  { id: 'BTCUSD', label: 'BTC/USDT', src: 'BTCUSDT', tv: 'BINANCE:BTCUSDT', kind: 'CRYPTO', digits: 2 },
  { id: 'ETHUSD', label: 'ETH/USDT', src: 'ETHUSDT', tv: 'BINANCE:ETHUSDT', kind: 'CRYPTO', digits: 2 },
]

export const INTERVALS: IntervalDef[] = [
  { id: '1m', label: '1M', role: 'SCALP ENTRY' },
  { id: '5m', label: '5M', role: 'EXECUTION' },
  { id: '15m', label: '15M', role: 'CONFIRMATION' },
  { id: '1h', label: '1H', role: 'INTRADAY BIAS' },
  { id: '4h', label: '4H', role: 'SWING MAP' },
  { id: '1d', label: '1D', role: 'DAILY NARRATIVE' },
  { id: '1w', label: '1W', role: 'MACRO WEEKLY' },
]

/**
 * Returns false for Forex & Metal spot pairs (XAUUSD, EURUSD, GBPUSD)
 * during the weekend market close (Friday 21:00 UTC through Sunday 21:00 UTC).
 */
export function isForexMarketOpen(symbolId: string, nowMs = Date.now()): boolean {
  if (symbolId !== 'XAUUSD' && symbolId !== 'EURUSD' && symbolId !== 'GBPUSD') {
    return true
  }
  const d = new Date(nowMs)
  const day = d.getUTCDay() // 0 = Sun, 5 = Fri, 6 = Sat
  const hour = d.getUTCHours()

  if (day === 6) return false // Closed all Saturday UTC
  if (day === 5 && hour >= 21) return false // Closed Friday >= 21:00 UTC
  if (day === 0 && hour < 21) return false // Closed Sunday < 21:00 UTC
  return true
}

export function symbolById(id: string): SymbolDef {
  if (id === 'BTCUSDT') return SYMBOLS.find((s) => s.id === 'BTCUSD') ?? SYMBOLS[0]
  if (id === 'ETHUSDT') return SYMBOLS.find((s) => s.id === 'ETHUSD') ?? SYMBOLS[0]
  return SYMBOLS.find((s) => s.id === id) ?? SYMBOLS[0]
}

const BINANCE_HOSTS = [
  'https://data-api.binance.vision',
  'https://api.binance.com',
  'https://api1.binance.com',
  'https://api2.binance.com',
  'https://api3.binance.com',
]

// Hidden metadata stream registry capturing execution time (ms) and latency (ms)
const hiddenMetadataStreams = new Map<string, ExecutionMetadataStream>()
const hiddenMetadataListeners = new Set<(meta: ExecutionMetadataStream) => void>()

function getHighResNow(): number {
  if (typeof performance !== 'undefined' && typeof performance.now === 'function') {
    return performance.now()
  }
  return Date.now()
}

export function recordExecutionMetadataSample(
  symbol: string,
  interval: string,
  executionTimeMs: number,
  latencyMs: number
): ExecutionMetadataStream {
  const normSym = symbol.toUpperCase()
  const normTf = interval.toLowerCase()
  const key = `${normSym}_${normTf}`
  const existing = hiddenMetadataStreams.get(key)
  const cleanExec = Math.max(0.1, Math.round(executionTimeMs * 100) / 100)
  const cleanLat = Math.max(1, Math.round(latencyMs * 10) / 10)

  const samplesCount = (existing?.samplesCount ?? 0) + 1
  const avgExecutionTimeMs = existing
    ? Math.round((existing.avgExecutionTimeMs * 0.8 + cleanExec * 0.2) * 100) / 100
    : cleanExec
  const avgLatencyMs = existing
    ? Math.round((existing.avgLatencyMs * 0.8 + cleanLat * 0.2) * 10) / 10
    : cleanLat
  const executionEfficiencyPct = computeExecutionEfficiencyPct(avgExecutionTimeMs, avgLatencyMs)

  const updated: ExecutionMetadataStream = {
    symbol: normSym,
    interval: normTf,
    executionTimeMs: cleanExec,
    latencyMs: cleanLat,
    avgExecutionTimeMs,
    avgLatencyMs,
    executionEfficiencyPct,
    samplesCount,
    lastUpdatedTs: Date.now(),
  }

  hiddenMetadataStreams.set(key, updated)
  hiddenMetadataStreams.set(normSym, updated)
  hiddenMetadataListeners.forEach((fn) => {
    try {
      fn(updated)
    } catch {}
  })
  return updated
}

export function getLatestExecutionMetadata(symbol = 'XAUUSD', interval = '15m'): ExecutionMetadataStream {
  const symDef = symbolById(symbol.toUpperCase())
  const tf = interval.toLowerCase()
  const byIdKey = `${symDef.id}_${tf}`
  const bySrcKey = `${symDef.src}_${tf}`
  const found =
    hiddenMetadataStreams.get(byIdKey) ||
    hiddenMetadataStreams.get(bySrcKey) ||
    hiddenMetadataStreams.get(symDef.id) ||
    hiddenMetadataStreams.get(symDef.src)
  if (found) return found

  const defaultExec = 1.8
  const defaultLat = 38.0
  return {
    symbol: symDef.id,
    interval: tf,
    executionTimeMs: defaultExec,
    latencyMs: defaultLat,
    avgExecutionTimeMs: defaultExec,
    avgLatencyMs: defaultLat,
    executionEfficiencyPct: computeExecutionEfficiencyPct(defaultExec, defaultLat),
    samplesCount: 1,
    lastUpdatedTs: Date.now(),
  }
}

export function subscribeExecutionMetadataStream(
  listener: (meta: ExecutionMetadataStream) => void
): () => void {
  hiddenMetadataListeners.add(listener)
  return () => {
    hiddenMetadataListeners.delete(listener)
  }
}

export async function fetchKlines(symbol: string, interval: string, limit = 320): Promise<Candle[]> {
  let lastErr = null
  for (const host of BINANCE_HOSTS) {
    try {
      const fetchStartClock = Date.now()
      const fetchStartHiRes = getHighResNow()
      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), 5000)
      const url = `${host}/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`
      const res = await fetch(url, { signal: controller.signal })
      clearTimeout(timeoutId)
      const networkEndHiRes = getHighResNow()
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const raw = await res.json()
      if (!Array.isArray(raw) || raw.length === 0) throw new Error('Empty klines')

      const parseStartHiRes = getHighResNow()
      const receiveTs = Date.now()
      const latencyMs = Math.max(1, Math.round((networkEndHiRes - fetchStartHiRes) * 10) / 10)

      const candles: Candle[] = raw.map((k: any) => ({
        t: Number(k[0]),
        o: Number(k[1]),
        h: Number(k[2]),
        l: Number(k[3]),
        c: Number(k[4]),
        v: Number(k[5]),
      }))

      const executionTimeMs = Math.max(0.2, Math.round((getHighResNow() - parseStartHiRes) * 100) / 100)
      const streamMeta = recordExecutionMetadataSample(symbol, interval, executionTimeMs, latencyMs)
      const symMatch = SYMBOLS.find((s) => s.src === symbol || s.id === symbol)
      if (symMatch) {
        recordExecutionMetadataSample(symMatch.id, interval, executionTimeMs, latencyMs)
      }

      const hiddenMeta: CandleExecutionMeta = {
        executionTimeMs: streamMeta.executionTimeMs,
        latencyMs: streamMeta.latencyMs,
        exchangeTs: candles[candles.length - 1]?.t || fetchStartClock,
        receiveTs,
        source: host,
      }

      // Attach non-enumerable hidden metadata stream to the array and last candle
      for (let i = 0; i < candles.length; i++) {
        Object.defineProperty(candles[i], '_meta', {
          value: hiddenMeta,
          enumerable: false,
          configurable: true,
          writable: true,
        })
      }
      return candles
    } catch (err) {
      lastErr = err
    }
  }
  throw lastErr ?? new Error('klines fetch failed')
}

export async function fetch24hTickers(symbols: string[]): Promise<Record<string, Ticker>> {
  for (const host of BINANCE_HOSTS) {
    try {
      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), 4000)
      const q = encodeURIComponent(JSON.stringify(symbols))
      const res = await fetch(`${host}/api/v3/ticker/24hr?symbols=${q}`, { signal: controller.signal })
      clearTimeout(timeoutId)
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const list = await res.json()
      const out: Record<string, Ticker> = {}
      for (const t of list) {
        out[t.symbol] = {
          symbol: t.symbol,
          price: Number(t.lastPrice),
          changePct: Number(t.priceChangePercent),
        }
      }
      return out
    } catch {}
  }
  return {}
}

const WS_HOSTS = [
  'wss://data-stream.binance.vision',
  'wss://stream.binance.com:9443',
  'wss://stream.binance.vision:9443',
]

interface SubEntry {
  key: string
  subId: number
  onKline: (k: Candle, meta?: TickMetadata) => void
  onStatus: (status: LiveDataStatus, meta?: { ageMs: number; latencyMs: number }) => void
  lastValidTickTs: number
}

const wsState = {
  ws: null as WebSocket | null,
  hostIdx: 0,
  subs: new Map<string, SubEntry>(),
  retries: 0,
  timer: null as any,
  heartbeatTimer: null as any,
  lastMsg: 0,
  subCounter: 0,
}

function stopHeartbeat() {
  if (wsState.heartbeatTimer) {
    clearInterval(wsState.heartbeatTimer)
    wsState.heartbeatTimer = null
  }
}

function startHeartbeat() {
  stopHeartbeat()
  wsState.heartbeatTimer = setInterval(() => {
    if (wsState.subs.size === 0) return

    const now = Date.now()
    const silenceDuration = now - wsState.lastMsg

    // If no message on open socket for SILENT_FEED_THRESHOLD_MS, flag STALE / RECONNECTING
    if (silenceDuration > SILENT_FEED_THRESHOLD_MS) {
      wsState.subs.forEach((sub) => {
        sub.onStatus('STALE', { ageMs: silenceDuration, latencyMs: silenceDuration })
      })

      // If silence continues over 18s, proactively force reconnect
      if (silenceDuration > 18000) {
        if (wsState.ws) {
          try {
            wsState.ws.close()
          } catch {}
          wsState.ws = null
        }
        reconnectWs(true)
      }
    }
  }, 2000)
}

function connectWs() {
  if (wsState.ws || wsState.subs.size === 0) return
  const streams = [...wsState.subs.keys()].join('/')
  const url = `${WS_HOSTS[wsState.hostIdx % WS_HOSTS.length]}/stream?streams=${streams}`

  // Notify syncing
  wsState.subs.forEach((s) => s.onStatus('SYNCING'))

  let ws: WebSocket
  try {
    ws = new WebSocket(url)
  } catch {
    reconnectWs()
    return
  }
  wsState.ws = ws

  ws.onopen = () => {
    wsState.retries = 0
    wsState.lastMsg = Date.now()
    wsState.subs.forEach((s) => s.onStatus('LIVE', { ageMs: 0, latencyMs: 0 }))
    startHeartbeat()
  }

  ws.onmessage = (evt) => {
    const serverReceiveTs = Date.now()
    const execStartHiRes = getHighResNow()
    wsState.lastMsg = serverReceiveTs

    try {
      const msg = JSON.parse(evt.data)
      if (msg.stream && msg.data && msg.data.k) {
        const k = msg.data.k
        const sub = wsState.subs.get(msg.stream)
        if (sub) {
          // CRITICAL FIX: Use msg.data.E (stream event timestamp in ms), NOT k.T (future candle close time!)
          const exchangeTs = Number(msg.data.E || msg.E || serverReceiveTs)
          const validation = validateTickFreshness(exchangeTs, sub.lastValidTickTs)

          const processingTs = Date.now()
          const latencyMs = Math.max(1, processingTs - exchangeTs)
          const executionTimeMs = Math.max(0.1, Math.round((getHighResNow() - execStartHiRes) * 100) / 100)
          const symSrc = String(k.s || msg.stream.split('@')[0] || 'PAXGUSDT').toUpperCase()
          const intervalId = String(k.i || msg.stream.split('_')?.[1] || '15m').toLowerCase()

          recordExecutionMetadataSample(symSrc, intervalId, executionTimeMs, latencyMs)
          const symMatch = SYMBOLS.find((s) => s.src === symSrc || s.id === symSrc)
          if (symMatch) {
            recordExecutionMetadataSample(symMatch.id, intervalId, executionTimeMs, latencyMs)
          }

          const meta: TickMetadata = {
            exchangeTs,
            serverReceiveTs,
            processingTs,
            displayTs: processingTs,
            latencyMs,
            executionTimeMs,
            isStale: validation.isStale,
            source: 'binance-ws',
          }

          if (validation.valid) {
            sub.lastValidTickTs = exchangeTs
            sub.onStatus('LIVE', { ageMs: validation.ageMs, latencyMs })
            const klineCandle: Candle = {
              t: Number(k.t),
              o: Number(k.o),
              h: Number(k.h),
              l: Number(k.l),
              c: Number(k.c),
              v: Number(k.v),
              final: !!k.x,
            }
            Object.defineProperty(klineCandle, '_meta', {
              value: {
                executionTimeMs,
                latencyMs,
                exchangeTs,
                receiveTs: serverReceiveTs,
                source: 'binance-ws',
              } satisfies CandleExecutionMeta,
              enumerable: false,
              configurable: true,
              writable: true,
            })
            sub.onKline(klineCandle, meta)
          } else {
            // Tick is stale / delayed / out of order — notify STALE status, DO NOT PASS to candle engine
            sub.onStatus('STALE', { ageMs: validation.ageMs, latencyMs })
          }
        }
      }
    } catch {}
  }

  ws.onclose = () => {
    wsState.ws = null
    stopHeartbeat()
    wsState.subs.forEach((s) => s.onStatus('RECONNECTING'))
    reconnectWs()
  }

  ws.onerror = () => {
    try {
      ws.close()
    } catch {}
  }
}

function reconnectWs(immediate = false) {
  if (wsState.timer) return
  const delay = immediate ? 200 : Math.min(10000, 1000 * Math.pow(1.5, wsState.retries))
  wsState.retries++
  wsState.timer = setTimeout(() => {
    wsState.timer = null
    wsState.hostIdx++
    connectWs()
  }, delay)
}

/**
 * Resets and forces reconnection of WebSocket with fresh subscriptions.
 */
export function forceWsReconnect(): void {
  if (wsState.timer) {
    clearTimeout(wsState.timer)
    wsState.timer = null
  }
  if (wsState.ws) {
    try {
      wsState.ws.close()
    } catch {}
    wsState.ws = null
  }
  wsState.retries = 0
  connectWs()
}

/**
 * Robust subscription to candlestick feed with tick freshness metadata.
 * Prevents race conditions and multiple streams updating the same price simultaneously.
 */
export function subscribeKline(
  symbol: string,
  interval: string,
  onKline: (k: Candle, meta?: TickMetadata) => void,
  onStatus: (status: LiveDataStatus, meta?: { ageMs: number; latencyMs: number }) => void = () => {},
) {
  const streamKey = `${symbol.toLowerCase()}@kline_${interval}`
  const subId = ++wsState.subCounter

  const subEntry: SubEntry = {
    key: streamKey,
    subId,
    onKline,
    onStatus,
    lastValidTickTs: 0,
  }

  // Save new subscription
  wsState.subs.set(streamKey, subEntry)

  if (wsState.ws && wsState.ws.readyState === WebSocket.OPEN) {
    try {
      wsState.ws.send(JSON.stringify({ method: 'SUBSCRIBE', params: [streamKey], id: Date.now() }))
      onStatus('LIVE', { ageMs: 0, latencyMs: 0 })
    } catch {
      onStatus('SYNCING')
    }
  } else {
    onStatus('SYNCING')
    connectWs()
  }

  return () => {
    // Only delete if this is still the active subscription for this streamKey
    const current = wsState.subs.get(streamKey)
    if (current && current.subId === subId) {
      wsState.subs.delete(streamKey)
      if (wsState.ws && wsState.ws.readyState === WebSocket.OPEN) {
        try {
          wsState.ws.send(JSON.stringify({ method: 'UNSUBSCRIBE', params: [streamKey], id: Date.now() }))
        } catch {}
      }
      if (wsState.subs.size === 0) {
        stopHeartbeat()
        if (wsState.ws) {
          try {
            wsState.ws.close()
          } catch {}
          wsState.ws = null
        }
      }
    }
  }
}

export function fmtPrice(price: number, digits: number): string {
  if (!isFinite(price)) return '—'
  return price.toLocaleString('en-US', {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  })
}
