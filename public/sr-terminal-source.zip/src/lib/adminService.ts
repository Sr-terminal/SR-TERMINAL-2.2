import {
  collection,
  doc,
  getDocs,
  getDoc,
  updateDoc,
  deleteDoc,
  addDoc,
  setDoc,
  onSnapshot,
  serverTimestamp,
} from 'firebase/firestore'
import { db } from './firebase'
import type { UserProfile } from './authService'
import type { RemoteConfig } from './remoteConfigService'

export type UserEntitlementCategory =
  | 'Active Trial'
  | 'Trial Expired'
  | 'Active Paid Subscription'
  | 'Paid Subscription Expired'
  | 'Cancelled'
  | 'Blocked'
  | 'Free / None'

export function getUserEntitlementCategory(u: UserProfile): UserEntitlementCategory {
  if (u.accountStatus === 'blocked' || u.accountStatus === 'suspended') {
    return 'Blocked'
  }
  const now = Date.now()

  if (u.subscriptionStatus === 'trial') {
    const exp = new Date(u.trialExpiry || u.subscriptionExpiry || '').getTime()
    if (!isNaN(exp) && exp > now) return 'Active Trial'
    return 'Trial Expired'
  }
  if (u.subscriptionStatus === 'trial_expired') {
    return 'Trial Expired'
  }
  if (u.subscriptionStatus === 'cancelled') {
    return 'Cancelled'
  }
  if (u.subscriptionStatus === 'active') {
    const exp = new Date(u.subscriptionExpiry || '').getTime()
    if (!isNaN(exp) && exp > now) return 'Active Paid Subscription'
    return 'Paid Subscription Expired'
  }
  if (u.subscriptionStatus === 'expired') {
    return 'Paid Subscription Expired'
  }
  return 'Free / None'
}

export interface AdminMetrics {
  totalUsers: number
  activeUsers: number
  blockedUsers: number
  freeUsers: number
  activeSubscriptions: number
  expiredSubscriptions: number
  activeTrials: number
  expiredTrials: number
  cancelledSubscriptions: number
  recentRegistrations: UserProfile[]
  recentLogins: UserProfile[]
}

export interface AdminAuditLog {
  id?: string
  adminUid: string
  adminEmail: string
  action: string
  targetUserUid?: string
  details: string
  timestamp: string
}

/**
 * Calculate dashboard metrics synchronously from a list of user profiles
 */
export function calculateMetrics(allUsers: UserProfile[]): AdminMetrics {
  let activeUsers = 0
  let blockedUsers = 0
  let freeUsers = 0
  let activeSubscriptions = 0
  let expiredSubscriptions = 0
  let activeTrials = 0
  let expiredTrials = 0
  let cancelledSubscriptions = 0

  for (const u of allUsers) {
    if (u.accountStatus === 'active') activeUsers++
    if (u.accountStatus === 'blocked' || u.accountStatus === 'suspended') blockedUsers++

    const cat = getUserEntitlementCategory(u)
    if (cat === 'Active Trial') {
      activeTrials++
    } else if (cat === 'Trial Expired') {
      expiredTrials++
    } else if (cat === 'Active Paid Subscription') {
      activeSubscriptions++
    } else if (cat === 'Paid Subscription Expired') {
      expiredSubscriptions++
    } else if (cat === 'Cancelled') {
      cancelledSubscriptions++
    } else if (cat === 'Free / None') {
      freeUsers++
    }
  }

  const sortedByCreated = [...allUsers]
    .sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''))
    .slice(0, 10)
  const sortedByLogin = [...allUsers]
    .sort((a, b) => (b.lastLoginAt || '').localeCompare(a.lastLoginAt || ''))
    .slice(0, 10)

  return {
    totalUsers: allUsers.length,
    activeUsers,
    blockedUsers,
    freeUsers,
    activeSubscriptions,
    expiredSubscriptions,
    activeTrials,
    expiredTrials,
    cancelledSubscriptions,
    recentRegistrations: sortedByCreated,
    recentLogins: sortedByLogin,
  }
}

/**
 * Check if the user is authorized to perform admin actions
 */
export function isUserAdmin(profile: UserProfile | null): boolean {
  if (!profile) return false
  return (
    profile.role === 'admin' ||
    profile.subscriptionPlan === 'admin' ||
    profile.subscriptionPlan === 'Admin Master License' ||
    (profile.email || '').toLowerCase().trim() === 'surajrayxyz09@gmail.com'
  )
}

/**
 * Log administrative operations for compliance and security
 */
export async function createAdminLog(
  adminProfile: UserProfile,
  action: string,
  details: string,
  targetUserUid?: string
): Promise<void> {
  if (!db) return
  try {
    await addDoc(collection(db, 'adminLogs'), {
      adminUid: adminProfile.uid,
      adminEmail: adminProfile.email || 'admin',
      action,
      targetUserUid: targetUserUid || null,
      details,
      timestamp: new Date().toISOString(),
    })
  } catch (err) {
    console.warn('Failed to record admin audit log:', err)
  }
}

async function fetchMergedUsersFromFirestore(): Promise<UserProfile[]> {
  if (!db) return []
  const byUid = new Map<string, UserProfile>()

  try {
    const dirSnap = await getDoc(doc(db, 'system_config', 'user_directory'))
    if (dirSnap.exists()) {
      const dirUsers = dirSnap.data()?.users || {}
      for (const [key, val] of Object.entries(dirUsers)) {
        const u = val as UserProfile
        if (u && (u.uid || key)) {
          const id = u.uid || key
          byUid.set(id, { ...u, uid: id })
        }
      }
    }
  } catch {}

  try {
    const snap = await getDocs(collection(db, 'users'))
    snap.forEach((d) => {
      const u = d.data() as UserProfile
      if (u) {
        // Always prioritize actual Firestore document ID so admin updates target the exact doc
        if (u.uid && u.uid !== d.id) {
          byUid.delete(u.uid)
        }
        byUid.set(d.id, { ...u, uid: d.id })
      }
    })
  } catch {}

  return Array.from(byUid.values())
}

/**
 * Subscribe to all users in real time from Firestore.
 * Updates the admin panel immediately when any user changes from another device.
 */
export function subscribeAllUsers(
  callback: (users: UserProfile[], metrics: AdminMetrics) => void
): () => void {
  if (!db) return () => {}
  let colUsers: UserProfile[] = []
  let dirUsers: UserProfile[] = []

  const emitMerged = () => {
    const byUid = new Map<string, UserProfile>()
    const byEmail = new Map<string, string>()

    for (const u of dirUsers) {
      if (u?.uid) {
        byUid.set(u.uid, u)
        if (u.email) byEmail.set(u.email.toLowerCase(), u.uid)
      }
    }
    for (const u of colUsers) {
      if (u?.uid) {
        if (u.email) {
          const prevUid = byEmail.get(u.email.toLowerCase())
          if (prevUid && prevUid !== u.uid) {
            byUid.delete(prevUid)
          }
          byEmail.set(u.email.toLowerCase(), u.uid)
        }
        byUid.set(u.uid, u)
      }
    }
    const merged = Array.from(byUid.values())
    callback(merged, calculateMetrics(merged))
  }

  const unsubDir = onSnapshot(
    doc(db, 'system_config', 'user_directory'),
    (snap) => {
      if (snap.exists()) {
        const map = snap.data()?.users || {}
        dirUsers = Object.entries(map).map(([k, v]) => ({
          ...(v as UserProfile),
          uid: (v as UserProfile)?.uid || k,
        }))
      } else {
        dirUsers = []
      }
      emitMerged()
    },
    () => {}
  )

  const unsubCol = onSnapshot(
    collection(db, 'users'),
    (snapshot) => {
      const users: UserProfile[] = []
      snapshot.forEach((d) => {
        const u = d.data() as UserProfile
        // Always set uid to d.id so Admin actions mutate the exact Firestore document
        users.push({ ...u, uid: d.id })
      })
      colUsers = users
      emitMerged()
    },
    () => {
      // Fallback handled by unsubDir
      emitMerged()
    }
  )

  return () => {
    unsubDir()
    unsubCol()
  }
}

/**
 * Fetch overview metrics for the Admin Dashboard (One-time fetch)
 */
export async function getAdminMetrics(): Promise<AdminMetrics> {
  if (!db) {
    return {
      totalUsers: 0,
      activeUsers: 0,
      blockedUsers: 0,
      freeUsers: 0,
      activeSubscriptions: 0,
      expiredSubscriptions: 0,
      activeTrials: 0,
      expiredTrials: 0,
      cancelledSubscriptions: 0,
      recentRegistrations: [],
      recentLogins: [],
    }
  }

  const allUsers = await fetchMergedUsersFromFirestore()
  return calculateMetrics(allUsers)
}

/**
 * Search users by UID, email, phone, or name
 */
export async function searchUsers(searchTerm: string): Promise<UserProfile[]> {
  if (!db) return []
  const q = searchTerm.trim().toLowerCase()
  const allUsers = await fetchMergedUsersFromFirestore()
  if (!q) return allUsers

  return allUsers.filter((u) => {
    const matchesUid = (u.uid || '').toLowerCase().includes(q)
    const matchesEmail = (u.email || '').toLowerCase().includes(q)
    const matchesPhone = (u.phone || '').toLowerCase().includes(q)
    const matchesName = (u.name || '').toLowerCase().includes(q)
    const matchesDevice =
      (u.deviceInfo?.deviceModel || '').toLowerCase().includes(q) ||
      (u.deviceInfo?.userAgent || '').toLowerCase().includes(q) ||
      (u.deviceInfo?.platform || '').toLowerCase().includes(q)

    return matchesUid || matchesEmail || matchesPhone || matchesName || matchesDevice
  })
}

async function mirrorDirectoryUpdate(targetUid: string, patch: Record<string, any> | null): Promise<void> {
  if (!db) return
  try {
    const dirRef = doc(db, 'system_config', 'user_directory')
    const snap = await getDoc(dirRef)
    const currentUsers = snap.exists() ? { ...(snap.data()?.users || {}) } : {}
    if (patch === null) {
      delete currentUsers[targetUid]
    } else if (currentUsers[targetUid]) {
      currentUsers[targetUid] = { ...currentUsers[targetUid], ...patch, uid: targetUid }
    }
    await setDoc(dirRef, { users: currentUsers, updatedAt: new Date().toISOString() }, { merge: true })
  } catch {}
}

/**
 * Update user account status (active / blocked / suspended)
 * Real-time Firestore update with serverTimestamp and audit logging.
 */
export async function setAccountStatus(
  adminProfile: UserProfile,
  targetUid: string,
  status: 'active' | 'blocked' | 'suspended',
  reason?: string
): Promise<void> {
  if (!db) throw new Error('Database unavailable')
  const userRef = doc(db, 'users', targetUid)
  const nowIso = new Date().toISOString()
  const patch = {
    uid: targetUid,
    accountStatus: status,
    statusReason: reason || (status === 'blocked' ? 'Account blocked by administrator' : 'Account active'),
    updatedAt: nowIso,
  }

  await setDoc(
    userRef,
    {
      ...patch,
      serverUpdatedAt: serverTimestamp(),
    },
    { merge: true }
  )
  await mirrorDirectoryUpdate(targetUid, patch)

  await createAdminLog(
    adminProfile,
    `ACCOUNT_STATUS_${status.toUpperCase()}`,
    `Changed status of user ${targetUid} to ${status}. Reason: ${reason || 'Administrative action'}`,
    targetUid
  )
}

/**
 * Grant or adjust subscription entitlement for a user.
 * Atomic update maintaining consistency of plan, start, expiry, and trial flags.
 */
export async function grantSubscription(
  adminProfile: UserProfile,
  targetUid: string,
  planId: string,
  durationDays: number,
  note?: string
): Promise<void> {
  if (!db) throw new Error('Database unavailable')
  const now = new Date()
  const nowIso = now.toISOString()
  const expiryDate = new Date(now.getTime() + durationDays * 24 * 60 * 60 * 1000)
  const expiryIso = expiryDate.toISOString()

  const userRef = doc(db, 'users', targetUid)
  const isTrial = planId === 'sr_terminal_7d_trial'

  const updates: Record<string, any> = {
    uid: targetUid,
    subscriptionStatus: isTrial ? 'trial' : 'active',
    subscriptionPlan: planId,
    subscriptionStart: nowIso,
    subscriptionExpiry: expiryIso,
    isTrial: isTrial,
    trialUsed: isTrial ? true : undefined,
    trialStart: isTrial ? nowIso : undefined,
    trialExpiry: isTrial ? expiryIso : undefined,
    trialActivatedAt: isTrial ? nowIso : undefined,
    trialExpiresAt: isTrial ? expiryIso : undefined,
    updatedAt: nowIso,
  }

  // Remove undefined properties before updating Firestore
  Object.keys(updates).forEach((k) => updates[k] === undefined && delete updates[k])

  await setDoc(userRef, { ...updates, serverUpdatedAt: serverTimestamp() }, { merge: true })
  await mirrorDirectoryUpdate(targetUid, updates)

  await createAdminLog(
    adminProfile,
    'GRANT_SUBSCRIPTION',
    `Granted ${durationDays} days of plan ${planId}. Expiry: ${expiryIso}. Note: ${note || 'Admin manual grant'}`,
    targetUid
  )
}

/**
 * Update subscription expiry date directly
 */
export async function updateSubscriptionExpiry(
  adminProfile: UserProfile,
  targetUid: string,
  newExpiryIso: string,
  note?: string
): Promise<void> {
  if (!db) throw new Error('Database unavailable')
  const userRef = doc(db, 'users', targetUid)
  const nowIso = new Date().toISOString()
  const patch = {
    uid: targetUid,
    subscriptionExpiry: newExpiryIso,
    trialExpiry: newExpiryIso,
    updatedAt: nowIso,
  }

  await setDoc(
    userRef,
    {
      ...patch,
      serverUpdatedAt: serverTimestamp(),
    },
    { merge: true }
  )
  await mirrorDirectoryUpdate(targetUid, patch)

  await createAdminLog(
    adminProfile,
    'UPDATE_EXPIRY',
    `Updated subscription expiry for ${targetUid} to ${newExpiryIso}. Note: ${note || 'Admin adjustment'}`,
    targetUid
  )
}

/**
 * Revoke subscription access and reset to Free tier atomically
 */
export async function revokeSubscription(
  adminProfile: UserProfile,
  targetUid: string,
  reason?: string
): Promise<void> {
  if (!db) throw new Error('Database unavailable')
  const userRef = doc(db, 'users', targetUid)
  const nowIso = new Date().toISOString()
  const patch = {
    uid: targetUid,
    subscriptionStatus: 'none',
    subscriptionPlan: 'none',
    isTrial: false,
    trialExpiry: null,
    trialExpiresAt: null,
    subscriptionStart: null,
    subscriptionExpiry: null,
    updatedAt: nowIso,
  }

  await setDoc(
    userRef,
    {
      ...patch,
      serverUpdatedAt: serverTimestamp(),
    },
    { merge: true }
  )
  await mirrorDirectoryUpdate(targetUid, patch)

  await createAdminLog(
    adminProfile,
    'REVOKE_SUBSCRIPTION',
    `Revoked subscription access and reset user ${targetUid} to Free tier. Reason: ${reason || 'Admin action'}`,
    targetUid
  )
}

/**
 * Delete a user profile and mark as deleted
 */
export async function deleteUser(
  adminProfile: UserProfile,
  targetUid: string,
  reason: string
): Promise<void> {
  if (!db) throw new Error('Database unavailable')
  const userRef = doc(db, 'users', targetUid)
  await deleteDoc(userRef)
  await mirrorDirectoryUpdate(targetUid, null)
  await createAdminLog(
    adminProfile,
    'DELETE_USER',
    `Deleted user ${targetUid}. Reason: ${reason}`,
    targetUid
  )
}

/**
 * Save updated remote config
 */
export async function saveRemoteConfig(
  adminProfile: UserProfile,
  newConfig: RemoteConfig
): Promise<void> {
  if (!db) throw new Error('Database unavailable')
  const ref = doc(db, 'system_config', 'app_settings')
  const payload = {
    ...newConfig,
    updatedAt: new Date().toISOString(),
    updatedBy: adminProfile.email || adminProfile.uid,
  }
  await setDoc(ref, payload)
  await createAdminLog(adminProfile, 'UPDATE_REMOTE_CONFIG', 'Updated live remote configuration')
}

/**
 * Fetch latest admin audit logs
 */
export async function fetchAuditLogs(limitCount = 50): Promise<AdminAuditLog[]> {
  if (!db) return []
  try {
    const logsCol = collection(db, 'adminLogs')
    const snap = await getDocs(logsCol)
    const logs: AdminAuditLog[] = []
    snap.forEach((d) => {
      logs.push({ id: d.id, ...(d.data() as AdminAuditLog) })
    })
    return logs.sort((a, b) => (b.timestamp || '').localeCompare(a.timestamp || '')).slice(0, limitCount)
  } catch (err) {
    console.warn('Error fetching audit logs:', err)
    return []
  }
}
