// @ts-nocheck
import { safeStorage } from "./storage";
import {
  classifySetup,
  updateTradeLifecycleOnTick,
  revalidateFormingSetups,
  isTerminalStage,
  type ImmutableTradeRecord,
  type TradeStage,
} from "./tradeLifecycleEngine";

const lg = "sr.journal.v1",
  ag = 500;

/**
 * Pure ICT Confluence & Strategy Name Sanitizer.
 * Removes retail terms ("SR CONCEPT", "SR CONCEPT REVERSAL", "EMA STACK", "EMA20", "TURTLE SOUP")
 * and maps them strictly to pure ICT institutional terminology.
 */
export function sanitizeIctString(text?: string): string {
  if (!text) return "LIQUIDITY SWEEP";
  return String(text)
    .replace(/SR CONCEPT PLUS ONE/gi, "LIQUIDITY SWEEP + CISD")
    .replace(/SR CONCEPT \+1/gi, "LIQUIDITY SWEEP + CISD")
    .replace(/SR CONCEPT REVERSAL/gi, "LIQUIDITY SWEEP")
    .replace(/SR CONCEPT/gi, "LIQUIDITY SWEEP")
    .replace(/TURTLE SOUP PLUS ONE/gi, "LIQUIDITY SWEEP + CISD")
    .replace(/TURTLE SOUP REVERSAL/gi, "LIQUIDITY SWEEP")
    .replace(/TURTLE SOUP/gi, "LIQUIDITY SWEEP")
    .replace(/ADX TREND PULLBACK/gi, "PD ARRAY CONTINUATION")
    .replace(/EMA STACK/gi, "ORDER BLOCK (OB)")
    .replace(/EMA20/gi, "PD ARRAY");
}

export function sanitizeConfluenceTags(tags?: string[]): string[] {
  if (!Array.isArray(tags) || tags.length === 0) return [];
  const mapped = tags
    .map((raw) => {
      const t = String(raw || "").trim().toUpperCase();
      if (!t) return null;
      if (t.includes("SR CONCEPT") || t.includes("TURTLE") || t === "SWEEP" || t.includes("SSL SWEEP") || t.includes("BSL SWEEP")) {
        return "LIQUIDITY SWEEP";
      }
      if (t.includes("EMA STACK") || t === "OB" || t.includes("ORDER BLOCK") || t.includes("BREAKER")) {
        return "ORDER BLOCK (OB)";
      }
      if (t === "EMA20" || t === "PD-CORRECT" || t === "HTF ALIGN" || t.includes("PD ARRAY")) {
        return "PD ARRAY";
      }
      if (t === "FVG" || t === "IFVG" || t === "BPR" || t.includes("VOLUME IMBALANCE") || t.includes("FVG / IFVG")) {
        return "FVG / IFVG";
      }
      if (t.includes("UNICORN")) {
        return "ORDER BLOCK (OB)";
      }
      if (t === "CHoCH" || t === "CHOCH" || t === "BOS" || t === "DISPLACEMENT" || t === "MSS") {
        return "MSS";
      }
      if (t.includes("ITL") || t.includes("ITH")) {
        return "ITL/ITH RAID";
      }
      if (t === "CISD") return "CISD";
      if (t === "OTE") return "OTE";
      if (t === "KILLZONE") return "KILLZONE";
      return sanitizeIctString(t);
    })
    .filter(Boolean) as string[];
  return [...new Set(mapped)];
}

/**
 * Formats the Trade Reason string so that:
 * 1. Retail terms are replaced with pure ICT terminology
 * 2. "X concepts aligned" dynamically matches `confluences.length`
 */
export function formatTradeReason(r: any): string {
  if (!r) return "—";
  const confluences = sanitizeConfluenceTags(r.confluences);
  const count = confluences.length;
  let base = sanitizeIctString(r.logicSummary || r.model || "LIQUIDITY SWEEP");
  if (count > 0) {
    if (/\b\d+\s+concepts?\s+aligned/i.test(base)) {
      base = base.replace(
        /\b\d+\s+concepts?\s+aligned/gi,
        `${count} concept${count === 1 ? "" : "s"} aligned`
      );
    } else if (r.direction === "LONG" || r.direction === "SHORT") {
      base = `${r.direction} — ${count} concept${count === 1 ? "" : "s"} aligned (${base})`;
    }
  }
  return base;
}

/**
 * Strict R-Multiple Calculation using ONLY initialStopLoss.
 * Prevents division-by-zero when SL is moved to Break-Even (Entry === CurrentSL).
 * Clamps output to [-10R, +50R] and formats to 2 decimal places.
 */
export function calculateSafeRMultiple(
  entryPrice: number,
  exitOrCurrentPrice: number,
  initialStopLoss: number,
  direction: "LONG" | "SHORT"
): number {
  if (
    typeof entryPrice !== "number" ||
    typeof exitOrCurrentPrice !== "number" ||
    typeof initialStopLoss !== "number" ||
    !isFinite(entryPrice) ||
    !isFinite(exitOrCurrentPrice) ||
    !isFinite(initialStopLoss)
  ) {
    return 0;
  }
  const initialRisk = Math.abs(entryPrice - initialStopLoss);
  if (!isFinite(initialRisk) || initialRisk <= 0.0001) {
    return 0;
  }
  const isLong = direction === "LONG";
  const rawR = (isLong ? exitOrCurrentPrice - entryPrice : entryPrice - exitOrCurrentPrice) / initialRisk;
  if (!isFinite(rawR)) {
    return 0;
  }
  const clamped = Math.max(-10, Math.min(50, rawR));
  const rounded = Number(clamped.toFixed(2));
  return Object.is(rounded, -0) ? 0 : rounded;
}

/**
 * Formats an R-Multiple safely for UI badges (e.g. "+2.50R", "-1.00R", "0.00R").
 */
export function formatRMultiple(resultR?: number): string {
  if (resultR === undefined || resultR === null || !isFinite(resultR) || Math.abs(resultR) > 50) {
    return "0.00R";
  }
  const clamped = Math.max(-10, Math.min(50, resultR));
  if (Math.abs(clamped) < 0.005) {
    return "0.00R";
  }
  return `${clamped > 0 ? "+" : ""}${clamped.toFixed(2)}R`;
}

function inferInitialStopLoss(rec: any): number {
  const entry = Number(rec?.entry) || 0;
  const candidate1 = Number(rec?.initialStopLoss);
  if (isFinite(candidate1) && candidate1 > 0 && Math.abs(entry - candidate1) > 0.0001) {
    return candidate1;
  }
  const candidate2 = Number(rec?.initialStop);
  if (isFinite(candidate2) && candidate2 > 0 && Math.abs(entry - candidate2) > 0.0001) {
    return candidate2;
  }
  const currentStop = Number(rec?.stop) || 0;
  if (isFinite(currentStop) && currentStop > 0 && Math.abs(entry - currentStop) > 0.0001) {
    return currentStop;
  }
  // If stop was already overwritten to entry (BE), infer original 1R distance from TP1 (which is 2R) or fallback 0.5% of entry
  const tp1 = Number(rec?.tp1) || 0;
  const rr1 = Number(rec?.rr1) || 2;
  if (entry > 0 && tp1 > 0 && Math.abs(tp1 - entry) > 0.0001) {
    const inferredDist = Math.abs(tp1 - entry) / Math.max(rr1, 1);
    return rec?.direction === "LONG" ? entry - inferredDist : entry + inferredDist;
  }
  const fallbackDist = Math.max(entry * 0.005, 1);
  return rec?.direction === "LONG" ? entry - fallbackDist : entry + fallbackDist;
}

function sanitizeTradeRecord(rec: any): ImmutableTradeRecord {
  const initialStopLoss = inferInitialStopLoss(rec);
  const confluences = sanitizeConfluenceTags(rec?.confluences);
  const model = sanitizeIctString(rec?.model);
  const hadBeEvent =
    Boolean(rec?.beProtected) ||
    Math.abs((Number(rec?.entry) || 0) - (Number(rec?.stop) || 0)) <= 0.0001 ||
    (Array.isArray(rec?.events) &&
      rec.events.some((ev: any) => /Break-Even|breakeven/i.test(String(ev?.note || ""))));

  let stage: TradeStage = rec?.stage || rec?.status || "SETUP_FORMING";
  let status: TradeStage = rec?.status || stage;
  let resultR = rec?.resultR;

  // Repair corrupted division-by-zero R-Multiples (e.g., +22649252175.91R)
  if (resultR !== undefined && (!isFinite(resultR) || Math.abs(resultR) > 50)) {
    resultR = 0;
  }

  // If trade was active / BE-protected and closed at Break-Even, status must be CLOSED (BE) with 0.00R, NOT CANCELLED
  if ((stage === "CANCELLED" || status === "CANCELLED") && hadBeEvent) {
    stage = "CLOSED (BE)";
    status = "CLOSED (BE)";
    resultR = 0;
  } else if (stage === "BREAKEVEN" || status === "BREAKEVEN") {
    stage = "CLOSED (BE)";
    status = "CLOSED (BE)";
    if (resultR === undefined || !isFinite(resultR) || Math.abs(resultR) > 50) {
      resultR = 0;
    }
  } else if (stage === "CANCELLED" || status === "CANCELLED") {
    resultR = 0;
  }

  if (resultR !== undefined && isFinite(resultR)) {
    resultR = Number(Math.max(-10, Math.min(50, resultR)).toFixed(2));
    if (Object.is(resultR, -0)) resultR = 0;
  }

  const sanitized: ImmutableTradeRecord = {
    ...rec,
    model,
    confluences,
    initialStopLoss,
    initialStop: initialStopLoss,
    beProtected: hadBeEvent,
    stage,
    status,
    resultR,
  };
  sanitized.logicSummary = formatTradeReason(sanitized);
  return sanitized;
}

function Yv(): ImmutableTradeRecord[] {
  try {
    const r = safeStorage.getItem(lg);
    if (!r) return [];
    const e = JSON.parse(r);
    if (!Array.isArray(e)) return [];
    const sanitized = e.map(sanitizeTradeRecord);
    return sanitized;
  } catch {
    return [];
  }
}

function p2(r: ImmutableTradeRecord[]) {
  try {
    const sanitized = Array.isArray(r) ? r.slice(0, ag).map(sanitizeTradeRecord) : [];
    safeStorage.setItem(lg, JSON.stringify(sanitized));
  } catch {}
}

function Ki(r: any): boolean {
  if (!r) return true;
  return isTerminalStage(r.stage || r.status);
}

/**
 * Creates or updates a record using the TradeLifecycleEngine state machine.
 * Prevents duplicate entries for the same underlying setup.
 */
function g2(plan: any, symbolId: string, symbolLabel: string, tf: string, livePrice: number, records: ImmutableTradeRecord[]) {
  const classification = classifySetup(plan, symbolId, symbolLabel, tf, livePrice, records);
  if (classification.type === "NEW_SETUP") {
    const cleanTrade = sanitizeTradeRecord(classification.trade);
    return {
      records: [cleanTrade, ...records].slice(0, ag),
      record: cleanTrade,
      classificationType: "NEW_SETUP",
    };
  } else if (classification.type === "UPDATE_EXISTING") {
    const cleanTrade = sanitizeTradeRecord(classification.trade);
    const updated = records.map((rec) =>
      rec.id === cleanTrade.id ? cleanTrade : rec
    );
    return {
      records: updated,
      record: cleanTrade,
      classificationType: "UPDATE_EXISTING",
    };
  }
  return null;
}

/**
 * Updates active trade records on price tick through the state machine.
 * Produces deduplicated notifications for pre-trade warnings, confirmed entries, TP1/2/3, and SL.
 */
function y2(records: ImmutableTradeRecord[], symbolId: string, livePrice: number, now = Date.now()) {
  const result = updateTradeLifecycleOnTick(records, symbolId, livePrice, now);
  const fired = result.notificationsToSend.map((n) => ({
    rec: sanitizeTradeRecord(n.trade),
    status: n.type,
    title: n.title,
    body: n.body,
    resultR: n.trade.resultR,
  }));
  return {
    records: result.records.map(sanitizeTradeRecord),
    fired,
    notificationsToSend: result.notificationsToSend,
  };
}

export function assessTradeRisk(r: any, currentPrice?: number) {
  if (!r) return { level: "LOW", score: 0, badgeLabel: "SAFE", reasons: [], recommendedAction: "Plan on track", actionUrgent: false, adverseR: 0, currentR: 0 };
  const isClosedTrade = Ki(r);
  const isLong = r.direction === "LONG";
  const initialStopLoss = inferInitialStopLoss(r);
  const initialRisk = Math.abs(r.entry - initialStopLoss);

  let adverseR = typeof r.maxAdverseR === "number" && isFinite(r.maxAdverseR) ? Math.min(10, Math.max(0, r.maxAdverseR)) : 0;
  let currentR = 0;
  if (currentPrice && initialRisk > 0.0001 && (r.stage === "RUNNING" || r.stage === "TP1" || r.stage === "TP2")) {
    const liveAdv = isLong ? (r.entry - currentPrice) / initialRisk : (currentPrice - r.entry) / initialRisk;
    currentR = calculateSafeRMultiple(r.entry, currentPrice, initialStopLoss, r.direction);
    if (isFinite(liveAdv) && liveAdv > adverseR) {
      adverseR = Number(Math.min(10, Math.max(0, liveAdv)).toFixed(2));
    }
  }

  const reasons = [];
  let score = 15;

  if (r.grade === "C") {
    score += 25;
    reasons.push("Grade C Setup (Low Confidence model)");
  } else if (r.grade === "B") {
    score += 10;
  }

  if (r.rr && r.rr < 1.7) {
    score += 15;
    reasons.push(`Low R:R Ratio (${Number(r.rr).toFixed(1)}R)`);
  }

  if (adverseR >= 0.65) {
    score += 55;
    reasons.push(`High Drawdown: ${Math.round(adverseR * 100)}% of initial risk (-${adverseR.toFixed(2)}R)`);
  } else if (adverseR >= 0.4) {
    score += 30;
    reasons.push(`Moderate Drawdown: ${Math.round(adverseR * 100)}% toward SL (-${adverseR.toFixed(2)}R)`);
  }

  const ageHours = (Date.now() - (r.createdTs || Date.now())) / 36e5;
  if (!isClosedTrade && r.stage === "RUNNING" && ageHours > 2.5 && Math.abs(currentR) < 0.25) {
    score += 15;
    reasons.push("Trade stagnant in entry zone (> 2.5 hours)");
  }

  let level = "LOW";
  let badgeLabel = "NORMAL / SAFE";
  let recommendedAction = "Trade healthy hai. Rules ke mutabiq TP target ka wait karein.";
  let actionUrgent = false;

  const isBeLocked =
    r.stage === "BREAKEVEN" ||
    r.stage === "CLOSED (BE)" ||
    r.beProtected ||
    Math.abs((r.entry || 0) - (r.stop || 0)) <= 0.0001;

  if (isBeLocked) {
    level = "PROTECTED";
    badgeLabel = "BE PROTECTED 🛡️";
    recommendedAction = "SL Entry par locked hai (Zero loss). Free runner ride karein.";
  } else if (score >= 60 || adverseR >= 0.65) {
    level = "HIGH";
    badgeLabel = "HIGH RISK ⚠️";
    actionUrgent = true;
    recommendedAction = "⚠️ Trade kafi risky zone me hai: Stop Loss ko turant BREAK-EVEN (Entry) par shift karein ya rejection sign dekhein!";
  } else if (score >= 35 || adverseR >= 0.4) {
    level = "MODERATE";
    badgeLabel = "MODERATE RISK ⚡";
    recommendedAction = "⚡ Price opposite move kar raha hai: 1-2 candle wick rejection dekhein, momentum slow ho toh BE shift karein.";
  }

  return {
    level,
    score: Math.min(100, score),
    badgeLabel,
    reasons: reasons.length ? reasons : ["Trade standard boundaries ke andar move kar raha hai"],
    recommendedAction,
    actionUrgent,
    adverseR,
    currentR,
  };
}

export function moveToBreakEven(r: any, currentPrice?: number) {
  const initialStopLoss = inferInitialStopLoss(r);
  const activeStage = r.stage === "SETUP_FORMING" ? "RUNNING" : (r.stage || "RUNNING");
  return sanitizeTradeRecord({
    ...r,
    initialStopLoss,
    initialStop: initialStopLoss,
    stop: r.entry,
    beProtected: true,
    stage: activeStage,
    status: activeStage,
    statusTs: Date.now(),
    events: [
      ...(r.events || []),
      { ts: Date.now(), stage: activeStage, price: currentPrice, note: `SL shifted to Break-Even (${r.entry})` },
    ],
  });
}

function b2(r: any, e: number) {
  const initialStopLoss = inferInitialStopLoss(r);
  const wasNeverTriggered = r.stage === "SETUP_FORMING" || r.status === "PLANNED";

  // 1. Order never triggered -> CANCELLED with 0.00R
  if (wasNeverTriggered) {
    return sanitizeTradeRecord({
      ...r,
      initialStopLoss,
      initialStop: initialStopLoss,
      stage: "CANCELLED",
      status: "CANCELLED",
      statusTs: Date.now(),
      resultR: 0,
      events: [
        ...(r.events || []),
        { ts: Date.now(), stage: "CANCELLED", price: e, note: "Pending setup cancelled before fill" },
      ],
    });
  }

  // 2. Active trade closed at Break-Even (Entry === SL or BE-protected or exit === entry) -> CLOSED (BE) with 0.00R
  const isAtBreakEven =
    Boolean(r.beProtected) ||
    Math.abs((r.entry || 0) - (r.stop || 0)) <= 0.0001 ||
    Math.abs((e || 0) - (r.entry || 0)) <= 0.0001;

  if (isAtBreakEven) {
    return sanitizeTradeRecord({
      ...r,
      initialStopLoss,
      initialStop: initialStopLoss,
      stage: "CLOSED (BE)",
      status: "CLOSED (BE)",
      statusTs: Date.now(),
      resultR: 0,
      events: [
        ...(r.events || []),
        { ts: Date.now(), stage: "CLOSED (BE)", price: r.entry, note: `Closed at Break-Even (${r.entry})` },
      ],
    });
  }

  const calculatedR = calculateSafeRMultiple(r.entry, e, initialStopLoss, r.direction);
  const finalStage: TradeStage = Math.abs(calculatedR) <= 0.02 ? "CLOSED (BE)" : "CLOSED";
  const finalR = finalStage === "CLOSED (BE)" ? 0 : calculatedR;

  return sanitizeTradeRecord({
    ...r,
    initialStopLoss,
    initialStop: initialStopLoss,
    stage: finalStage,
    status: finalStage,
    statusTs: Date.now(),
    resultR: finalR,
    events: [
      ...(r.events || []),
      { ts: Date.now(), stage: finalStage, price: e, note: `Manual close at ${e} (${formatRMultiple(finalR)})` },
    ],
  });
}

function x2(r: any[]) {
  const e = r.filter(Ki),
    executed = e.filter((d) => d.status !== "CANCELLED" && d.stage !== "CANCELLED" && d.status !== "INVALIDATED" && d.status !== "EXPIRED"),
    s = executed.filter((d) => (d.resultR ?? 0) > 0.05).length,
    l = executed.filter((d) => (d.resultR ?? 0) < -0.05).length,
    u = executed.length - s - l,
    c = executed.reduce((d, f) => {
      const val = typeof f.resultR === "number" && isFinite(f.resultR) && Math.abs(f.resultR) <= 50 ? f.resultR : 0;
      return d + val;
    }, 0);
  const safeTotalR = Number(c.toFixed(2));
  const safeExpectancy = executed.length ? Number((c / executed.length).toFixed(2)) : 0;
  return {
    total: r.length,
    open: r.length - e.length,
    closed: e.length,
    wins: s,
    losses: l,
    breakeven: u,
    winRate: executed.length ? Math.round((s / executed.length) * 100) : 0,
    totalR: Object.is(safeTotalR, -0) ? 0 : safeTotalR,
    expectancyR: Object.is(safeExpectancy, -0) ? 0 : safeExpectancy,
  };
}

export const isClosed = Ki;
export const loadJournal = Yv;
export const saveJournal = p2;
export const createRecord = g2;
export const updateRecordsOnTick = y2;
export const revalidateSetups = revalidateFormingSetups;
export const manualClose = b2;
export const computeStats = x2;
export type JournalRecord = ImmutableTradeRecord;
export type JournalStats = any;
