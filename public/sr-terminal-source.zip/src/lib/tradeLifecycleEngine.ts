/**
 * SR TERMINAL — TRADE LIFECYCLE STATE MACHINE & DEDUPLICATION ENGINE
 * 
 * Formal state transitions:
 *   SETUP_FORMING (Pre-trade warning)
 *     ↓
 *   ENTRY_CONFIRMED (Trade entered notification)
 *     ↓
 *   RUNNING (Active trade monitoring)
 *     ↓
 *   TP1 HIT / TP2 HIT / TP3 HIT (Partial/Full profit)
 *     OR
 *   STOP LOSS HIT (Trade closed with loss)
 *     OR
 *   BREAKEVEN (Stop hit after TP1/TP2 partials)
 *     OR
 *   INVALIDATED (Setup broke before entry)
 *     OR
 *   EXPIRED (Entry was never reached within time limit)
 *     OR
 *   CANCELLED (Manually closed)
 * 
 * Guarantees:
 * 1. Unique signal identity (symbol, tf, direction, model, setupWindow)
 * 2. Setup locking: Once confirmed/running, NO duplicate entries for same setup
 * 3. Pre-trade warning vs Trade Entry confirmation distinction
 * 4. Deduplication: Every notification event fired exactly once
 * 5. Immutable trade record as single source of truth
 */

import { safeStorage } from './storage'

export type TradeStage =
  | 'SETUP_FORMING'
  | 'ENTRY_CONFIRMED'
  | 'RUNNING'
  | 'TP1'
  | 'TP2'
  | 'TP3'
  | 'BREAKEVEN'
  | 'CLOSED (BE)'
  | 'CLOSED'
  | 'STOPPED'
  | 'INVALIDATED'
  | 'EXPIRED'
  | 'CANCELLED'

export interface TradeEventLog {
  ts: number
  stage: TradeStage
  price?: number
  note: string
}

export interface ImmutableTradeRecord {
  id: string
  signalId: string
  symbolId: string
  symbolLabel: string
  tf: string
  direction: 'LONG' | 'SHORT'
  model: string
  modelKind?: string
  entry: number
  entryZone: [number, number]
  stop: number
  initialStopLoss: number
  initialStop?: number
  beProtected?: boolean
  tp1: number
  tp2: number
  tp3: number
  rr: number
  rr1?: number
  rr3?: number
  grade: string
  confidence?: number
  confluences: string[]
  logicSummary?: string
  createdTs: number
  statusTs: number
  stage: TradeStage
  status: TradeStage
  risky: boolean
  maxAdverseR?: number
  resultR?: number
  events: TradeEventLog[]
  priceAtCreate: number
  preWarningFired?: boolean
  entryConfirmedFired?: boolean
  digits?: number
}

export type SetupClassification =
  | { type: 'NEW_SETUP'; trade: ImmutableTradeRecord }
  | { type: 'UPDATE_EXISTING'; trade: ImmutableTradeRecord }
  | { type: 'TRADE_ALREADY_ACTIVE'; trade: ImmutableTradeRecord }
  | { type: 'NO_TRADE'; reason: string }

const NOTIF_EVENT_KEY = 'sr_processed_notification_events'

/**
 * Loads processed event keys from persistent storage
 */
export function getProcessedNotificationEvents(): Set<string> {
  try {
    const raw = safeStorage.getItem(NOTIF_EVENT_KEY)
    if (!raw) return new Set()
    const arr = JSON.parse(raw)
    return new Set(Array.isArray(arr) ? arr : [])
  } catch {
    return new Set()
  }
}

/**
 * Marks a notification event as processed permanently so it never re-fires
 */
export function markNotificationEventProcessed(eventId: string) {
  try {
    const set = getProcessedNotificationEvents()
    set.add(eventId)
    // Keep last 1000 event IDs
    const arr = Array.from(set).slice(-1000)
    safeStorage.setItem(NOTIF_EVENT_KEY, JSON.stringify(arr))
  } catch {}
}

/**
 * Checks if a notification event was already fired
 */
export function isNotificationEventProcessed(eventId: string): boolean {
  const set = getProcessedNotificationEvents()
  return set.has(eventId)
}

/**
 * Checks if a trade stage is terminal (completed)
 */
export function isTerminalStage(stage: TradeStage | string): boolean {
  return (
    stage === 'TP3' ||
    stage === 'BREAKEVEN' ||
    stage === 'CLOSED (BE)' ||
    stage === 'CLOSED' ||
    stage === 'STOPPED' ||
    stage === 'INVALIDATED' ||
    stage === 'EXPIRED' ||
    stage === 'CANCELLED'
  )
}

/**
 * Generates a stable unique signal ID for a setup based on symbol, timeframe, direction, model & swing
 */
export function generateSignalId(
  symbolId: string,
  tf: string,
  direction: 'LONG' | 'SHORT',
  model: string,
  entry: number,
  ts: number
): string {
  // Approximate window to group candles within same swing/setup (e.g. 4-hour bucket for intraday)
  const windowMs = tf === '1m' ? 30 * 60 * 1000
    : tf === '5m' ? 2 * 60 * 60 * 1000
    : tf === '15m' ? 6 * 60 * 60 * 1000
    : tf === '1h' ? 24 * 60 * 60 * 1000
    : tf === '4h' ? 72 * 60 * 60 * 1000
    : tf === '1d' ? 7 * 24 * 60 * 60 * 1000
    : 14 * 24 * 60 * 60 * 1000

  const windowBucket = Math.floor(ts / windowMs)
  const cleanModel = (model || 'ICT').replace(/[^a-zA-Z0-9]/g, '').slice(0, 12)
  const cleanEntry = Math.round(entry * 100) / 100
  return `${symbolId}_${tf}_${direction}_${cleanModel}_w${windowBucket}_e${cleanEntry}`
}

/**
 * Evaluates an incoming plan against the existing trade records.
 * Solves the duplicate entry bug by locking active setups and distinguishing:
 * - NEW SETUP
 * - UPDATE TO EXISTING SETUP
 * - TRADE ALREADY ACTIVE
 * - NO TRADE
 */
export function classifySetup(
  plan: any,
  symbolId: string,
  symbolLabel: string,
  tf: string,
  livePrice: number,
  existingRecords: ImmutableTradeRecord[],
  digits: number = 2,
  customTimestamp?: number
): SetupClassification {
  if (!plan || !plan.valid || plan.direction === 'STAND ASIDE') {
    return { type: 'NO_TRADE', reason: 'Engine plan invalid or standing aside' }
  }

  const direction: 'LONG' | 'SHORT' = plan.direction
  const now = customTimestamp || plan.createdTs || Date.now()

  // 1. Cross-Timeframe Concurrency Guard:
  // Check if there is ANY active (non-terminal) trade for this symbol across ANY timeframe
  const activeTradeAcrossTf = existingRecords.find(
    (t) => t.symbolId === symbolId && !isTerminalStage(t.stage)
  )

  if (activeTradeAcrossTf) {
    const isSameTimeframe = activeTradeAcrossTf.tf === tf
    const isSameDirection = activeTradeAcrossTf.direction === direction
    const entryDiffPct = Math.abs(activeTradeAcrossTf.entry - plan.entry) / (activeTradeAcrossTf.entry || 1)

    // If trade is already active (ENTRY_CONFIRMED, RUNNING, TP1, TP2)
    if (
      activeTradeAcrossTf.stage === 'ENTRY_CONFIRMED' ||
      activeTradeAcrossTf.stage === 'RUNNING' ||
      activeTradeAcrossTf.stage === 'TP1' ||
      activeTradeAcrossTf.stage === 'TP2'
    ) {
      // If same direction and within 3% price proximity, block duplicate entry across all timeframes
      if (isSameDirection || entryDiffPct < 0.03) {
        return { type: 'TRADE_ALREADY_ACTIVE', trade: activeTradeAcrossTf }
      }
    }

    // If active trade is in SETUP_FORMING:
    if (activeTradeAcrossTf.stage === 'SETUP_FORMING') {
      if (isSameDirection) {
        // If same timeframe and close in price, refine forming setup
        if (isSameTimeframe && (entryDiffPct < 0.015 || now - activeTradeAcrossTf.createdTs < 12 * 3600 * 1000)) {
          const nextStop = plan.stop ?? activeTradeAcrossTf.stop
          const nextConfluences = plan.confluences ?? activeTradeAcrossTf.confluences ?? []
          const rawSummary = plan.logic?.summary || activeTradeAcrossTf.logicSummary || plan.model || activeTradeAcrossTf.model
          const syncedSummary = nextConfluences.length > 0
            ? String(rawSummary).replace(/\b\d+\s+concepts?\s+aligned/i, `${nextConfluences.length} concept${nextConfluences.length === 1 ? '' : 's'} aligned`)
            : rawSummary
          const updated: ImmutableTradeRecord = {
            ...activeTradeAcrossTf,
            entry: plan.entry ?? activeTradeAcrossTf.entry,
            entryZone: plan.entryZone ?? activeTradeAcrossTf.entryZone,
            stop: nextStop,
            initialStopLoss: nextStop,
            initialStop: nextStop,
            tp1: plan.tp1 ?? activeTradeAcrossTf.tp1,
            tp2: plan.tp2 ?? activeTradeAcrossTf.tp2,
            tp3: plan.tp3 ?? activeTradeAcrossTf.tp3,
            rr: plan.rr ?? activeTradeAcrossTf.rr,
            rr1: plan.rr1 ?? activeTradeAcrossTf.rr1,
            grade: plan.grade ?? activeTradeAcrossTf.grade,
            confidence: plan.confidence ?? activeTradeAcrossTf.confidence,
            confluences: nextConfluences,
            logicSummary: syncedSummary,
            statusTs: now,
          }
          return { type: 'UPDATE_EXISTING', trade: updated }
        }
        return { type: 'TRADE_ALREADY_ACTIVE', trade: activeTradeAcrossTf }
      } else {
        // Opposite structure formed while setup was still forming
        activeTradeAcrossTf.stage = 'INVALIDATED'
        activeTradeAcrossTf.status = 'INVALIDATED'
        activeTradeAcrossTf.statusTs = now
        activeTradeAcrossTf.events.push({ ts: now, stage: 'INVALIDATED', note: 'Opposite structure formed before entry' })
      }
    }
  }

  // 2. Check if a recent completed trade was identical to avoid immediate re-entry on same price
  const recentSameSetup = existingRecords.find(
    (t) =>
      t.symbolId === symbolId &&
      t.tf === tf &&
      t.direction === direction &&
      Math.abs(t.entry - plan.entry) / (t.entry || 1) < 0.002 &&
      now - t.statusTs < 30 * 60 * 1000 // 30 minute cooldown after closing same price setup
  )
  if (recentSameSetup) {
    return { type: 'NO_TRADE', reason: 'Cooldown active for recently completed setup at same level' }
  }

  // 3. Brand New Setup Creation
  const signalId = generateSignalId(symbolId, tf, direction, plan.model, plan.entry, now)
  const id = `trade_${signalId}_${now}`
  const confluencesList: string[] = Array.isArray(plan.confluences) ? plan.confluences : []
  const rawLogicSummary = plan.logic?.summary || plan.model || 'ICT Model'
  const syncedLogicSummary = confluencesList.length > 0
    ? String(rawLogicSummary).replace(/\b\d+\s+concepts?\s+aligned/i, `${confluencesList.length} concept${confluencesList.length === 1 ? '' : 's'} aligned`)
    : rawLogicSummary
  const initRisk = Math.abs((plan.entry || 0) - (plan.stop || 0))
  const safeRr3 = plan.tp3 && plan.entry && initRisk > 0.0001
    ? Number(Math.min(50, Math.max(0, Math.abs(plan.tp3 - plan.entry) / initRisk)).toFixed(2))
    : 3

  const newTrade: ImmutableTradeRecord = {
    id,
    signalId,
    symbolId,
    symbolLabel: symbolLabel || symbolId,
    tf,
    direction,
    model: plan.model || 'ICT Model',
    modelKind: plan.modelKind,
    entry: plan.entry,
    entryZone: plan.entryZone || [plan.entry, plan.entry],
    stop: plan.stop,
    initialStopLoss: plan.stop,
    initialStop: plan.stop,
    beProtected: false,
    tp1: plan.tp1,
    tp2: plan.tp2,
    tp3: plan.tp3,
    rr: plan.rr || 2,
    rr1: plan.rr1 || 1,
    rr3: safeRr3,
    grade: plan.grade || 'A',
    confidence: plan.confidence || 80,
    confluences: confluencesList,
    logicSummary: syncedLogicSummary,
    createdTs: now,
    statusTs: now,
    stage: 'SETUP_FORMING',
    status: 'SETUP_FORMING',
    risky: false,
    maxAdverseR: 0,
    resultR: undefined,
    events: [{ ts: now, stage: 'SETUP_FORMING', price: livePrice, note: `Setup identified: ${plan.model}` }],
    priceAtCreate: livePrice,
    preWarningFired: false,
    entryConfirmedFired: false,
    digits,
  }

  return { type: 'NEW_SETUP', trade: newTrade }
}

export interface LifecycleEvaluationResult {
  records: ImmutableTradeRecord[]
  notificationsToSend: {
    eventId: string
    type: 'PRE_TRADE_APPROACHING' | 'ENTRY_CONFIRMED' | 'TP1_HIT' | 'TP2_HIT' | 'TP3_HIT' | 'STOP_HIT' | 'BREAKEVEN' | 'INVALIDATED' | 'EXPIRED'
    title: string
    body: string
    trade: ImmutableTradeRecord
  }[]
}

/**
 * Ticks active trades against current live price.
 * Manages full lifecycle transitions and generates deduplicated notifications.
 */
export function updateTradeLifecycleOnTick(
  records: ImmutableTradeRecord[],
  symbolId: string,
  livePrice: number,
  now: number = Date.now()
): LifecycleEvaluationResult {
  if (!isFinite(livePrice) || livePrice <= 0) {
    return { records, notificationsToSend: [] }
  }

  const notificationsToSend: LifecycleEvaluationResult['notificationsToSend'] = []
  let hasChanges = false

  const updatedRecords = records.map((trade) => {
    if (trade.symbolId !== symbolId || isTerminalStage(trade.stage)) {
      return trade
    }

    const t = { ...trade }
    const isLong = t.direction === 'LONG'
    // Calculate original risk distance strictly from initialStopLoss (never modified BE stop)
    const originalStop = t.initialStopLoss ?? t.initialStop ?? t.stop
    const riskDist = Math.abs(t.entry - originalStop)
    if (t.stage === 'SETUP_FORMING' && riskDist <= 0.0001) return trade
    const safeRiskDist = riskDist > 0.0001 ? riskDist : 0

    const minEntryZone = Math.min(...t.entryZone)
    const maxEntryZone = Math.max(...t.entryZone)
    const tolerance = safeRiskDist > 0 ? safeRiskDist * 0.1 : Math.abs(t.entry) * 0.0005

    // Expiry check for un-filled setups (> 24 hours)
    if (t.stage === 'SETUP_FORMING' && now - t.createdTs > 24 * 3600 * 1000) {
      t.stage = 'EXPIRED'
      t.status = 'EXPIRED'
      t.statusTs = now
      t.resultR = 0
      t.events = [...t.events, { ts: now, stage: 'EXPIRED', price: livePrice, note: 'Setup expired without fill' }]
      hasChanges = true
      return t
    }

    // -------------------------------------------------------------
    // 1. SETUP_FORMING STAGE:
    // Check for Pre-Trade Warning vs Invalidation vs Fill
    // -------------------------------------------------------------
    if (t.stage === 'SETUP_FORMING') {
      // Invalidation: Price ran through Stop Loss or TP1 before entering
      const invalidatedByStop = isLong ? livePrice <= t.stop : livePrice >= t.stop
      const invalidatedByTp = isLong ? livePrice >= t.tp1 : livePrice <= t.tp1

      if (invalidatedByStop || invalidatedByTp) {
        t.stage = 'INVALIDATED'
        t.status = 'INVALIDATED'
        t.statusTs = now
        t.resultR = 0
        t.events = [
          ...t.events,
          {
            ts: now,
            stage: 'INVALIDATED',
            price: livePrice,
            note: invalidatedByStop ? 'Stop swept before fill' : 'TP swept before fill',
          },
        ]
        hasChanges = true
        return t
      }

      // Check Fill: Price touches entry zone
      const isFilled =
        livePrice >= minEntryZone - tolerance &&
        livePrice <= maxEntryZone + tolerance

      if (isFilled) {
        t.stage = 'RUNNING'
        t.status = 'RUNNING'
        t.statusTs = now
        t.entryConfirmedFired = true
        t.events = [
          ...t.events,
          { ts: now, stage: 'ENTRY_CONFIRMED', price: livePrice, note: `Entry filled at ${livePrice}` },
          { ts: now, stage: 'RUNNING', price: livePrice, note: `Trade active` },
        ]
        hasChanges = true

        const eventId = `${t.signalId}-ENTRY_CONFIRMED`
        if (!isNotificationEventProcessed(eventId)) {
          markNotificationEventProcessed(eventId)
          notificationsToSend.push({
            eventId,
            type: 'ENTRY_CONFIRMED',
            title: `SR TERMINAL — TRADE CONFIRMED`,
            body: `${t.symbolLabel} ${t.tf} · ${t.direction}\nEntry: ${t.entry} | SL: ${t.stop}\nTP1: ${t.tp1} | TP2: ${t.tp2} | TP3: ${t.tp3}\nRR: 1:${t.rr} | Grade: ${t.grade}`,
            trade: t,
          })
        }
        return t
      }

      // Pre-Trade Warning Check: Price is approaching entry zone within 0.25% - 0.5% or 1.5 ATR
      const distance = Math.abs(livePrice - t.entry)
      const distancePct = (distance / (t.entry || 1)) * 100
      const isApproaching = distancePct <= 0.45 && !t.preWarningFired

      if (isApproaching) {
        t.preWarningFired = true
        hasChanges = true
        const eventId = `${t.signalId}-PRE_TRADE_APPROACHING`
        if (!isNotificationEventProcessed(eventId)) {
          markNotificationEventProcessed(eventId)
          notificationsToSend.push({
            eventId,
            type: 'PRE_TRADE_APPROACHING',
            title: `SR TERMINAL — Trade Setup Approaching`,
            body: `${t.symbolLabel} ${t.tf} · ${t.direction}\nEntry: ${t.entry} | Current: ${livePrice}\nDistance: ${distance.toFixed(t.digits ?? 2)} (${distancePct.toFixed(2)}%)\nModel: ${t.model}\nStatus: ACTIVE SETUP`,
            trade: t,
          })
        }
      }

      return t
    }

    // -------------------------------------------------------------
    // 2. ACTIVE RUNNING TRADE MONITORING (RUNNING, TP1, TP2)
    // -------------------------------------------------------------
    if (t.stage === 'RUNNING' || t.stage === 'TP1' || t.stage === 'TP2') {
      // Divergence Protection: If price deviates by >20% in a single tick from entry, ignore rogue data feed anomaly
      const pctDeviation = Math.abs(livePrice - t.entry) / (t.entry || 1)
      if (pctDeviation > 0.20) {
        return trade
      }

      const stopHit = isLong ? livePrice <= t.stop : livePrice >= t.stop
      const tp1Hit = isLong ? livePrice >= t.tp1 : livePrice <= t.tp1
      const tp2Hit = isLong ? livePrice >= t.tp2 : livePrice <= t.tp2
      const tp3Hit = isLong ? livePrice >= t.tp3 : livePrice <= t.tp3

      // Stop Loss Hit
      if (stopHit) {
        hasChanges = true
        const isBeProtected =
          Boolean(t.beProtected) ||
          Math.abs(t.stop - t.entry) <= Math.max(0.0001, Math.abs(t.entry) * 0.00005)
        if (t.stage === 'RUNNING' && !isBeProtected) {
          // Closed with loss
          t.stage = 'STOPPED'
          t.status = 'STOPPED'
          t.statusTs = now
          t.resultR = -1.0
          t.events = [...t.events, { ts: now, stage: 'STOPPED', price: livePrice, note: `Stopped at ${livePrice}` }]

          const eventId = `${t.signalId}-STOP_HIT`
          if (!isNotificationEventProcessed(eventId)) {
            markNotificationEventProcessed(eventId)
            notificationsToSend.push({
              eventId,
              type: 'STOP_HIT',
              title: `SR TERMINAL — Stop Loss Hit`,
              body: `${t.symbolLabel} ${t.tf} · ${t.direction}\nClosed at Stop Loss (${livePrice}) · -1.0R`,
              trade: t,
            })
          }
          return t
        } else {
          // Breakeven Stop Hit (either manually BE-protected in RUNNING or after TP1/TP2 partials)
          const hitFromStage = t.stage
          t.stage = 'CLOSED (BE)'
          t.status = 'CLOSED (BE)'
          t.statusTs = now
          t.resultR = hitFromStage === 'TP2' ? 1.5 : hitFromStage === 'TP1' ? 0.8 : 0.0
          t.events = [...t.events, { ts: now, stage: 'CLOSED (BE)', price: livePrice, note: `Break-Even stop filled at ${livePrice} (${t.resultR.toFixed(2)}R)` }]

          const eventId = `${t.signalId}-BREAKEVEN`
          if (!isNotificationEventProcessed(eventId)) {
            markNotificationEventProcessed(eventId)
            notificationsToSend.push({
              eventId,
              type: 'BREAKEVEN',
              title: `SR TERMINAL — Closed at Break-Even`,
              body: `${t.symbolLabel} ${t.tf} · ${t.direction}\nClosed at Break-Even (${t.resultR >= 0 ? '+' : ''}${t.resultR.toFixed(2)}R).`,
              trade: t,
            })
          }
          return t
        }
      }

      // TP3 Runner Hit (Full Target Achieved)
      if (tp3Hit) {
        hasChanges = true
        t.stage = 'TP3'
        t.status = 'TP3'
        t.statusTs = now
        t.resultR = Number(Math.min(50, Math.max(-10, t.rr3 || t.rr || 3.0)).toFixed(2))
        t.events = [...t.events, { ts: now, stage: 'TP3', price: livePrice, note: `TP3 runner hit at ${livePrice}` }]

        const eventId = `${t.signalId}-TP3_HIT`
        if (!isNotificationEventProcessed(eventId)) {
          markNotificationEventProcessed(eventId)
          notificationsToSend.push({
            eventId,
            type: 'TP3_HIT',
            title: `SR TERMINAL — TP3 RUNNER HIT!`,
            body: `${t.symbolLabel} ${t.tf} · ${t.direction}\nFull target reached at ${t.tp3} · +${t.resultR.toFixed(2)}R Profit Locked!`,
            trade: t,
          })
        }
        return t
      }

      // TP2 Hit
      if (tp2Hit && (t.stage === 'TP1' || t.stage === 'RUNNING')) {
        hasChanges = true
        t.initialStopLoss = t.initialStopLoss ?? t.initialStop ?? t.stop
        t.initialStop = t.initialStopLoss
        t.stage = 'TP2'
        t.status = 'TP2'
        t.statusTs = now
        // Trail stop to TP1 level to guarantee profit on runner
        t.stop = t.tp1
        t.events = [...t.events, { ts: now, stage: 'TP2', price: livePrice, note: `TP2 hit at ${livePrice}. Trailed stop to TP1 (${t.tp1})` }]

        const eventId = `${t.signalId}-TP2_HIT`
        if (!isNotificationEventProcessed(eventId)) {
          markNotificationEventProcessed(eventId)
          notificationsToSend.push({
            eventId,
            type: 'TP2_HIT',
            title: `SR TERMINAL — TP2 HIT (+2.0R)`,
            body: `${t.symbolLabel} ${t.tf} · ${t.direction}\nSecond partial secured at ${t.tp2}. Letting final runner ride to TP3!`,
            trade: t,
          })
        }
        return t
      }

      // TP1 Hit
      if (tp1Hit && t.stage === 'RUNNING') {
        hasChanges = true
        t.initialStopLoss = t.initialStopLoss ?? t.initialStop ?? t.stop
        t.initialStop = t.initialStopLoss
        t.beProtected = true
        t.stage = 'TP1'
        t.status = 'TP1'
        t.statusTs = now
        // Move stop to entry (Breakeven)
        t.stop = t.entry
        t.events = [
          ...t.events,
          { ts: now, stage: 'TP1', price: livePrice, note: `TP1 hit at ${livePrice}. Stop moved to breakeven.` },
        ]

        const eventId = `${t.signalId}-TP1_HIT`
        if (!isNotificationEventProcessed(eventId)) {
          markNotificationEventProcessed(eventId)
          notificationsToSend.push({
            eventId,
            type: 'TP1_HIT',
            title: `SR TERMINAL — TP1 HIT (+${t.rr1 || 1.0}R)`,
            body: `${t.symbolLabel} ${t.tf} · ${t.direction}\nFirst partial banked at ${t.tp1}! Stop moved to Breakeven (${t.entry}).`,
            trade: t,
          })
        }
        return t
      }

      // Update adverse drawdown strictly using safeRiskDist (initialStopLoss)
      if (safeRiskDist > 0.0001) {
        const adversePoints = isLong ? t.entry - livePrice : livePrice - t.entry
        const rawAdverseR = adversePoints / safeRiskDist
        if (isFinite(rawAdverseR)) {
          const clampedAdv = Math.min(10, Math.max(t.maxAdverseR || 0, rawAdverseR))
          const roundedAdv = Number(clampedAdv.toFixed(2))
          if (roundedAdv !== t.maxAdverseR) {
            t.maxAdverseR = roundedAdv
            hasChanges = true
          }
        }
      }
    }

    return t
  })

  return {
    records: hasChanges ? updatedRecords : records,
    notificationsToSend,
  }
}

/**
 * Revalidates any pending SETUP_FORMING trades when market conditions change
 * (e.g., high-impact news blackout triggers, or market structure/bias flips strongly against the setup).
 */
export function revalidateFormingSetups(
  records: ImmutableTradeRecord[],
  symbolId: string,
  tf: string,
  analysis: any,
  now: number = Date.now()
): { records: ImmutableTradeRecord[]; changed: boolean } {
  if (!analysis || !Array.isArray(records) || records.length === 0) {
    return { records, changed: false }
  }

  let changed = false
  const next = records.map((t) => {
    if (t.symbolId !== symbolId || t.tf !== tf || t.stage !== 'SETUP_FORMING') {
      return t
    }

    const isLong = t.direction === 'LONG'
    const score = typeof analysis.score === 'number' ? analysis.score : 0
    const blackout = Boolean(analysis.plan?.logic?.blackout)
    const oppositeStructureFlip =
      (isLong && score <= -35) ||
      (!isLong && score >= 35) ||
      (analysis.plan?.valid && analysis.plan?.direction && analysis.plan.direction !== 'STAND ASIDE' && analysis.plan.direction !== t.direction)

    if (blackout || oppositeStructureFlip) {
      changed = true
      const reason = blackout
        ? 'Invalidated due to high-impact news blackout window'
        : `Invalidated: market structure flipped (${analysis.bias || score})`
      return {
        ...t,
        stage: 'INVALIDATED' as TradeStage,
        status: 'INVALIDATED' as TradeStage,
        statusTs: now,
        resultR: 0,
        events: [...(t.events || []), { ts: now, stage: 'INVALIDATED' as TradeStage, price: analysis.price, note: reason }],
      }
    }
    return t
  })

  return { records: changed ? next : records, changed }
}

