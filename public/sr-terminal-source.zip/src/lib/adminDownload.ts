import { BUILD } from './version'
import { apiUrl } from './apiConfig'

const ADMIN_EMAIL = 'surajrayxyz09@gmail.com'

export async function downloadAdminArtifact(
  kind: 'apk' | 'zip',
  onStatus?: (msg: string | null) => void
): Promise<void> {
  const filename = kind === 'apk' ? `SR-Terminal-v${BUILD}.apk` : 'sr-terminal-source.zip'
  const endpoint =
    kind === 'apk'
      ? apiUrl(`/api/download/apk?ownerEmail=${encodeURIComponent(ADMIN_EMAIL)}&t=${Date.now()}`)
      : apiUrl(`/api/download/zip?ownerEmail=${encodeURIComponent(ADMIN_EMAIL)}&t=${Date.now()}`)

  try {
    onStatus?.(kind === 'apk' ? `Downloading ${filename}...` : 'Preparing Source ZIP...')
    const resp = await fetch(endpoint, {
      method: 'GET',
      credentials: 'include',
      cache: 'no-store',
      headers: {
        'X-Owner-Email': ADMIN_EMAIL,
      },
    })

    if (!resp.ok) {
      throw new Error(`HTTP ${resp.status}`)
    }

    const buffer = await resp.arrayBuffer()
    const mimeType =
      kind === 'apk' ? 'application/vnd.android.package-archive' : 'application/zip'
    const blob = new Blob([buffer], { type: mimeType })
    const blobUrl = URL.createObjectURL(blob)

    const link = document.createElement('a')
    link.href = blobUrl
    link.download = filename
    link.style.display = 'none'
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)

    setTimeout(() => URL.revokeObjectURL(blobUrl), 30000)
    onStatus?.(null)
  } catch (err) {
    console.warn('[AdminDownload] Blob fetch fallback to direct navigation:', err)
    onStatus?.(null)
    const fallbackUrl =
      kind === 'apk'
        ? `/SR-Terminal-v${BUILD}.apk?ownerEmail=${encodeURIComponent(ADMIN_EMAIL)}`
        : `/sr-terminal-source.zip?ownerEmail=${encodeURIComponent(ADMIN_EMAIL)}`
    const link = document.createElement('a')
    link.href = fallbackUrl
    link.download = filename
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }
}
