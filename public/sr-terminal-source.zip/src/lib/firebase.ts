import { initializeApp, getApps, type FirebaseApp } from 'firebase/app'
import { getAuth, GoogleAuthProvider, type Auth } from 'firebase/auth'
import { getFirestore, type Firestore } from 'firebase/firestore'

const env = (import.meta as any).env || {}

const config = {
  projectId: env.VITE_FIREBASE_PROJECT_ID || 'gen-lang-client-0327010007',
  appId: env.VITE_FIREBASE_APP_ID || '1:303899369872:web:593e8e9722bd4231829315',
  apiKey: env.VITE_FIREBASE_API_KEY || 'AIzaSyDtwi3T0AvQbuahbURkDYXsVVOg857xFm0',
  authDomain: env.VITE_FIREBASE_AUTH_DOMAIN || 'gen-lang-client-0327010007.firebaseapp.com',
  firestoreDatabaseId:
    env.VITE_FIREBASE_FIRESTORE_DATABASE_ID ||
    'ai-studio-srterminalprivat-41ef7494-5a58-4184-8c13-0b1ee9f8f190',
  storageBucket: env.VITE_FIREBASE_STORAGE_BUCKET || 'gen-lang-client-0327010007.firebasestorage.app',
  messagingSenderId: env.VITE_FIREBASE_MESSAGING_SENDER_ID || '303899369872',
  measurementId: env.VITE_FIREBASE_MEASUREMENT_ID || '',
}

let app: FirebaseApp
let auth: Auth
let db: Firestore

try {
  if (getApps().length === 0) {
    app = initializeApp(config)
  } else {
    app = getApps()[0]
  }
  auth = getAuth(app)
  db = getFirestore(app, config.firestoreDatabaseId)
} catch (err) {
  console.warn('Firebase initialization error, running in offline fallback mode:', err)
  // Fallback dummy objects if Firebase fails so the trading terminal never crashes
  app = {} as any
  auth = {} as any
  db = {} as any
}

export const googleProvider = new GoogleAuthProvider()
googleProvider.setCustomParameters({ prompt: 'select_account' })

export { app, auth, db }
