import { doc, getDoc, updateDoc, setDoc, collection, addDoc } from 'firebase/firestore'
import { db } from './firebase'
import { safeStorage } from './storage'
import type { UserProfile } from './authService'

export interface SubscriptionPlan {
  id: string
  name: string
  durationDays: number
  priceInr: number
  priceFormatted: string
  tag?: string
  description: string
  features: string[]
}

export const TRIAL_PLAN_ID = 'sr_terminal_7d_trial'

export const SUBSCRIPTION_PLANS: SubscriptionPlan[] = [
  {
    id: 'sr_terminal_30d',
    name: '30 Days Swing Pass',
    durationDays: 30,
    priceInr: 999,
    priceFormatted: '₹999',
    description: '30 Days Full Institutional Access',
    features: [
      '14 Book-Derived ICT Algorithm Models',
      'Strict Consensus Engine & Trade Plans',
      'Live Tick Charts & DOM Orderbook',
      'Native Android Push & Haptic Alerts',
      'Real-time Breakeven & Risk Automation',
    ],
  },
  {
    id: 'sr_terminal_2m',
    name: '2 Months Institutional',
    durationDays: 60,
    priceInr: 1899,
    priceFormatted: '₹1,899',
    tag: 'MOST POPULAR',
    description: '60 Days Complete Continuous Workspace',
    features: [
      'All 30-Day Features Included',
      '60/40 Walk-Forward Backtesting Engine',
      'High Impact News Blackout Radar',
      'Priority Cloud Data & Feed Latency',
      'Saves ₹99 vs Monthly Plan',
    ],
  },
  {
    id: 'sr_terminal_1y',
    name: '1 Year Annual Pro',
    durationDays: 365,
    priceInr: 10999,
    priceFormatted: '₹10,999',
    tag: 'BEST VALUE (SAVE ₹1,000)',
    description: '365 Days Unrestricted Prop-Firm License',
    features: [
      'All Institutional Workspace Features',
      'Unlimited Backtesting & Historical Analysis',
      'Institutional VIP Support Channel',
      'All Future Strategy Models & Updates',
      'Lowest Effective Daily Cost (₹30/day)',
    ],
  },
]

export type SubscriptionStatus =
  | 'none'
  | 'trial'
  | 'trial_expired'
  | 'active'
  | 'expired'
  | 'pending'
  | 'cancelled'
  | 'blocked'

export interface EntitlementInfo {
  isActive: boolean
  status: SubscriptionStatus
  isTrial: boolean
  planId: string
  planName: string
  expiryDate: string | null
  daysRemaining: number
  isExpired: boolean
}

/**
 * Check if the user's subscription or trial is currently active and valid
 */
export function evaluateEntitlement(profile: UserProfile | null): EntitlementInfo {
  if (!profile) {
    return {
      isActive: false,
      status: 'none',
      isTrial: false,
      planId: 'none',
      planName: 'None',
      expiryDate: null,
      daysRemaining: 0,
      isExpired: false,
    }
  }

  // Admins always have full institutional access
  if (profile.role === 'admin') {
    return {
      isActive: true,
      status: 'active',
      isTrial: false,
      planId: 'sr_terminal_1y',
      planName: 'Admin Master License',
      expiryDate: '2099-12-31T23:59:59.999Z',
      daysRemaining: 9999,
      isExpired: false,
    }
  }

  if (profile.accountStatus === 'blocked' || profile.accountStatus === 'suspended') {
    return {
      isActive: false,
      status: 'blocked',
      isTrial: false,
      planId: profile.subscriptionPlan || 'none',
      planName: 'Blocked Account',
      expiryDate: profile.subscriptionExpiry,
      daysRemaining: 0,
      isExpired: true,
    }
  }

  const now = Date.now()

  // 1. Check 7-Day Free Trial
  if (profile.subscriptionStatus === 'trial') {
    const trialExp = profile.trialExpiry || profile.subscriptionExpiry
    if (!trialExp) {
      return {
        isActive: false,
        status: 'trial_expired',
        isTrial: true,
        planId: TRIAL_PLAN_ID,
        planName: '7-Day Free Trial',
        expiryDate: null,
        daysRemaining: 0,
        isExpired: true,
      }
    }

    const expTime = new Date(trialExp).getTime()
    if (isNaN(expTime) || now >= expTime) {
      return {
        isActive: false,
        status: 'trial_expired',
        isTrial: true,
        planId: TRIAL_PLAN_ID,
        planName: '7-Day Free Trial (Expired)',
        expiryDate: trialExp,
        daysRemaining: 0,
        isExpired: true,
      }
    }

    const daysRemaining = Math.max(0, Math.ceil((expTime - now) / (1000 * 60 * 60 * 24)))
    return {
      isActive: true,
      status: 'trial',
      isTrial: true,
      planId: TRIAL_PLAN_ID,
      planName: '7-Day Free Trial',
      expiryDate: trialExp,
      daysRemaining,
      isExpired: false,
    }
  }

  // 2. Check Paid Active Subscription
  if (profile.subscriptionStatus === 'active') {
    if (!profile.subscriptionExpiry) {
      return {
        isActive: false,
        status: 'none',
        isTrial: false,
        planId: profile.subscriptionPlan || 'none',
        planName: 'Free Tier',
        expiryDate: null,
        daysRemaining: 0,
        isExpired: false,
      }
    }

    const expTime = new Date(profile.subscriptionExpiry).getTime()
    if (isNaN(expTime) || now >= expTime) {
      return {
        isActive: false,
        status: 'expired',
        isTrial: false,
        planId: profile.subscriptionPlan,
        planName: 'Expired Subscription',
        expiryDate: profile.subscriptionExpiry,
        daysRemaining: 0,
        isExpired: true,
      }
    }

    const daysRemaining = Math.max(0, Math.ceil((expTime - now) / (1000 * 60 * 60 * 24)))
    const plan = SUBSCRIPTION_PLANS.find((p) => p.id === profile.subscriptionPlan)

    return {
      isActive: true,
      status: 'active',
      isTrial: false,
      planId: profile.subscriptionPlan,
      planName: plan?.name || 'Active Plan',
      expiryDate: profile.subscriptionExpiry,
      daysRemaining,
      isExpired: false,
    }
  }

  // 3. Fallback for other states
  const hasUsedTrial = Boolean(profile.trialUsed || profile.isTrial || profile.trialStart)
  const isExpired = profile.subscriptionStatus === 'expired' || profile.subscriptionStatus === 'trial_expired' || (profile.subscriptionStatus === 'none' && hasUsedTrial)
  const status = profile.subscriptionStatus === 'none' && hasUsedTrial ? 'trial_expired' : ((profile.subscriptionStatus as SubscriptionStatus) || 'none')

  return {
    isActive: false,
    status,
    isTrial: !!profile.isTrial,
    planId: profile.subscriptionPlan || 'none',
    planName: status === 'trial_expired' ? '7-Day Trial Expired' : 'Free Tier',
    expiryDate: profile.subscriptionExpiry,
    daysRemaining: 0,
    isExpired,
  }
}

/**
 * Start the official Google Play 7-Day Free Trial
 * Validates eligibility in Firestore to ensure no duplicate trials
 * Strict Rule: ONE ACCOUNT = ONE 7-DAY TRIAL ONLY
 */
export async function start7DayFreeTrial(
  userProfile: UserProfile
): Promise<{ success: boolean; message: string }> {
  if (!userProfile?.uid) {
    throw new Error('Please sign in first to start your 7-Day Free Trial.')
  }

  // Anti-abuse: Check if user has already used a trial in session
  if (userProfile.trialUsed || userProfile.isTrial || userProfile.trialStart || userProfile.trialExpiresAt) {
    throw new Error('This account has already redeemed the 7-Day Free Trial. Rule: ONE ACCOUNT = ONE 7-DAY TRIAL ONLY. Please select a paid subscription plan.')
  }

  // Double check directly against Firestore doc to prevent tampering or multi-device abuse
  if (db) {
    try {
      const userSnap = await getDoc(doc(db, 'users', userProfile.uid))
      if (userSnap.exists()) {
        const data = userSnap.data() as UserProfile
        if (data.trialUsed || data.isTrial || data.trialStart || data.trialExpiresAt) {
          throw new Error('This account has already redeemed the 7-Day Free Trial. Rule: ONE ACCOUNT = ONE 7-DAY TRIAL ONLY. Please select a paid subscription plan.')
        }
      }
    } catch (checkErr: any) {
      if (checkErr?.message?.includes('ONE 7-DAY TRIAL ONLY')) {
        throw checkErr
      }
    }
  }

  // Check if native Android Google Play Billing is available
  const hasAndroidBilling =
    typeof window !== 'undefined' &&
    ((window as any).AndroidPlayBilling || (window as any).Capacitor?.isPluginAvailable?.('PlayBilling'))

  if (hasAndroidBilling) {
    try {
      if ((window as any).AndroidPlayBilling?.launchBillingFlowWithOffer) {
        (window as any).AndroidPlayBilling.launchBillingFlowWithOffer('sr_terminal_30d', '7-day-free-trial')
        return {
          success: true,
          message: 'Google Play Free Trial confirmation launched.',
        }
      }
    } catch (err) {
      console.warn('Play Billing launch error:', err)
    }
  }

  if (!db) {
    throw new Error('Database connection unavailable.')
  }

  const now = new Date()
  const trialDays = 7
  const expiryDate = new Date(now.getTime() + trialDays * 24 * 60 * 60 * 1000)
  const orderId = `TRIAL.PLAY.${Math.floor(100000 + Math.random() * 900000)}`

  // 1. Record trial transaction in subscriptions collection
  await addDoc(collection(db, 'subscriptions'), {
    uid: userProfile.uid,
    productId: TRIAL_PLAN_ID,
    planName: '7-Day Free Trial',
    amountInr: 0,
    isTrial: true,
    orderId,
    purchaseToken: `trial_tok_${Date.now()}`,
    status: 'TRIAL',
    startTime: now.toISOString(),
    expiryTime: expiryDate.toISOString(),
    verifiedAt: now.toISOString(),
    platform: hasAndroidBilling ? 'google_play_android_trial' : 'google_play_offer',
  })

  // 2. Update user profile in Firestore with immutable trialUsed flag
  const userRef = doc(db, 'users', userProfile.uid)
  await updateDoc(userRef, {
    subscriptionStatus: 'trial',
    subscriptionPlan: TRIAL_PLAN_ID,
    isTrial: true,
    trialUsed: true, // PERMANENT RECORD
    trialStart: now.toISOString(),
    trialExpiry: expiryDate.toISOString(),
    trialActivatedAt: now.toISOString(),
    trialExpiresAt: expiryDate.toISOString(),
    subscriptionStart: now.toISOString(),
    subscriptionExpiry: expiryDate.toISOString(),
    updatedAt: now.toISOString(),
  })

  // 3. Update local session storage
  const updatedProfile: UserProfile = {
    ...userProfile,
    subscriptionStatus: 'trial',
    subscriptionPlan: TRIAL_PLAN_ID,
    isTrial: true,
    trialUsed: true,
    trialStart: now.toISOString(),
    trialExpiry: expiryDate.toISOString(),
    subscriptionStart: now.toISOString(),
    subscriptionExpiry: expiryDate.toISOString(),
    updatedAt: now.toISOString(),
  }
  try {
    safeStorage.setItem('sr_user_session', JSON.stringify(updatedProfile))
  } catch {}

  return {
    success: true,
    message: '7-Day Free Trial activated successfully! Enjoy full institutional access.',
  }
}

/**
 * Initiate Google Play Billing Purchase Flow for Paid Plans
 */
export async function purchaseSubscription(
  planId: string,
  userProfile: UserProfile
): Promise<{ success: boolean; message: string }> {
  if (!userProfile?.uid) {
    throw new Error('Please sign in first to subscribe to SR TERMINAL.')
  }

  const plan = SUBSCRIPTION_PLANS.find((p) => p.id === planId)
  if (!plan) {
    throw new Error(`Invalid plan identifier: ${planId}`)
  }

  // Check if native Android Google Play Billing interface is available
  const hasAndroidBilling =
    typeof window !== 'undefined' &&
    ((window as any).AndroidPlayBilling || (window as any).Capacitor?.isPluginAvailable?.('PlayBilling'))

  if (hasAndroidBilling) {
    try {
      if ((window as any).AndroidPlayBilling?.launchBillingFlow) {
        (window as any).AndroidPlayBilling.launchBillingFlow(plan.id)
        return {
          success: true,
          message: 'Google Play Billing purchase dialog launched on device.',
        }
      }
    } catch (err: any) {
      console.warn('Native Play Billing invocation error:', err)
    }
  }

  // Verification & Recording in Firestore
  if (!db) {
    throw new Error('Database connection is not available for purchase verification.')
  }

  const now = new Date()
  const expiryDate = new Date(now.getTime() + plan.durationDays * 24 * 60 * 60 * 1000)
  const orderId = `PENDING_${Date.now()}_${Math.floor(1000 + Math.random() * 9000)}`
  const purchaseToken = `tok_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`

  // 1. Create subscription transaction record in PENDING state awaiting Play Billing / Admin verification
  await addDoc(collection(db, 'subscriptions'), {
    uid: userProfile.uid,
    productId: plan.id,
    planName: plan.name,
    amountInr: plan.priceInr,
    orderId,
    purchaseToken,
    status: 'PENDING',
    isTrial: false,
    startTime: now.toISOString(),
    expiryTime: expiryDate.toISOString(),
    requestedAt: now.toISOString(),
    platform: hasAndroidBilling ? 'google_play_android' : 'web_pending_verification',
  })

  // 2. Set user profile subscriptionStatus to 'pending' (never self-escalate to 'active' without verified billing)
  const userRef = doc(db, 'users', userProfile.uid)
  await updateDoc(userRef, {
    subscriptionStatus: 'pending',
    subscriptionPlan: plan.id,
    updatedAt: now.toISOString(),
  })

  return {
    success: false,
    message: `Purchase request recorded as PENDING (${orderId}). Paid subscriptions require Google Play Billing on Android or Administrator verification.`,
  }
}
