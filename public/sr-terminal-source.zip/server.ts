import 'dotenv/config'
import express from 'express'
import path from 'path'
import fs from 'fs'
import crypto from 'crypto'
import nodemailer from 'nodemailer'
import { createServer as createViteServer } from 'vite'
import {
  startServerTradingEngine,
  getServerEngineStatus,
  getServerActiveTrades,
  getServerRecentEvents,
  updateServerNewsBlackout,
  type ServerTradeEvent,
} from './src/lib/serverTradingEngine'
import { getCuratedWeeklyEvents, checkNewsBlackout, type EconomicEvent, type NewsHeadline } from './src/lib/newsService'
import { execSync } from 'child_process'
import { runAiTradingAnalysis, runAiDeveloperDiagnostic, runAiLossPostMortem } from './src/lib/aiServices'
import { analyse } from './src/lib/ict'

interface ServerOtpRecord {
  email: string
  codeHash: string
  salt: string
  attempts: number
  expiresAt: number
  createdAt: number
  purpose: string
  name?: string
}

interface TradeSignalEvent {
  id: string
  eventId: string
  symbolId: string
  symbolLabel: string
  tf: string
  direction: 'LONG' | 'SHORT'
  type: string
  title: string
  body: string
  ts: number
}

const PORT = 3000
const ADMIN_EMAILS = ['surajrayxyz09@gmail.com']
const SERVER_SECRET = process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex')

interface RegisteredAccountRecord {
  uid: string
  email: string
  name: string
  passwordHash?: string
  passwordSalt?: string
  role: 'admin' | 'user'
  subscriptionPlan: string
  subscriptionStatus: string
  createdAt: string
  lastLoginAt: string
}

const DATA_DIR = path.join(process.cwd(), '.data')
const REGISTERED_USERS_FILE = path.join(DATA_DIR, 'registered-users.json')
const registeredUsersMap = new Map<string, RegisteredAccountRecord>()

function loadRegisteredUsers(): void {
  try {
    if (fs.existsSync(REGISTERED_USERS_FILE)) {
      const raw = fs.readFileSync(REGISTERED_USERS_FILE, 'utf8')
      const parsed = JSON.parse(raw) as Record<string, RegisteredAccountRecord>
      for (const [emailKey, rec] of Object.entries(parsed)) {
        if (rec && rec.email) {
          registeredUsersMap.set(emailKey.toLowerCase(), rec)
        }
      }
    }
  } catch (err) {
    console.warn('[Server-Auth] Could not load registered users store:', err)
  }

  // Always ensure the owner/admin account is registered as an existing account
  for (const adminEmail of ADMIN_EMAILS) {
    const cleanAdmin = adminEmail.toLowerCase()
    if (!registeredUsersMap.has(cleanAdmin)) {
      const nowIso = new Date().toISOString()
      registeredUsersMap.set(cleanAdmin, {
        uid: 'admin_suraj_ray',
        email: cleanAdmin,
        name: 'Suraj Ray (Admin)',
        role: 'admin',
        subscriptionPlan: 'admin',
        subscriptionStatus: 'active',
        createdAt: nowIso,
        lastLoginAt: nowIso,
      })
    }
  }
}

function saveRegisteredUsers(): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true })
    }
    const obj: Record<string, RegisteredAccountRecord> = {}
    for (const [k, v] of registeredUsersMap.entries()) {
      obj[k] = v
    }
    fs.writeFileSync(REGISTERED_USERS_FILE, JSON.stringify(obj, null, 2), 'utf8')
  } catch (err) {
    console.warn('[Server-Auth] Could not persist registered users store:', err)
  }
}

loadRegisteredUsers()

// In-memory OTP storage: email -> ServerOtpRecord
const otpStore = new Map<string, ServerOtpRecord>()
// Verified OTP emails awaiting password login/registration completion: email -> verifiedAt timestamp
const verifiedOtpEmails = new Map<string, number>()
// Rate-limiting for request-otp: email -> lastRequestedAt
const rateLimitMap = new Map<string, number>()
// Recent trade events log
const recentEvents: TradeSignalEvent[] = []
// Connected SSE clients for background push
const sseClients = new Set<express.Response>()

function broadcastTradeSignal(event: TradeSignalEvent) {
  recentEvents.unshift(event)
  if (recentEvents.length > 50) recentEvents.pop()

  const payload = `data: ${JSON.stringify(event)}\n\n`
  for (const client of sseClients) {
    try {
      client.write(payload)
    } catch {
      sseClients.delete(client)
    }
  }
}

let smtpAuthFailedPermanently = false

// Helper: Get configured SMTP transporter with proper Gmail handling
function getSmtpTransporter() {
  if (smtpAuthFailedPermanently) return null
  const user = (process.env.SMTP_USER || '').trim()
  const pass = (process.env.SMTP_PASS || '').replace(/[\s"']/g, '')
  if (!user || !pass) {
    return null
  }

  const host = (process.env.SMTP_HOST || 'smtp.gmail.com').trim()
  const isGmail = host.includes('gmail') || user.includes('gmail.com')
  const port = Number(process.env.SMTP_PORT) || 587

  if (isGmail) {
    return nodemailer.createTransport({
      host: 'smtp.gmail.com',
      port: 587,
      secure: false, // STARTTLS
      auth: {
        user,
        pass,
      },
      tls: {
        rejectUnauthorized: false,
      },
    })
  }

  return nodemailer.createTransport({
    host,
    port,
    secure: port === 465,
    auth: {
      user,
      pass,
    },
    tls: {
      rejectUnauthorized: false,
    },
  })
}

interface EmailDispatchResult {
  sent: boolean
  provider?: string
  deliveryMode?: 'direct' | 'sandbox_relay' | 'unconfigured_relay'
  relayNotice?: string
  verificationCodeForRelay?: string
  error?: string
}


/**
 * Dispatches the 6-digit OTP code strictly to the user's submitted email address (`cleanEmail`)
 * while keeping the sender (`from` / `sender`) set to the configured system/admin sender:
 * 1. Nodemailer SMTP (if SMTP_USER & SMTP_PASS are configured) — universal direct delivery to `cleanEmail`.
 * 2. Brevo / SendGrid HTTP APIs (if BREVO_API_KEY or SENDGRID_API_KEY is configured) — direct delivery to `cleanEmail`.
 * 3. Resend HTTP API (if RESEND_API_KEY is configured) — direct delivery to `cleanEmail`.
 * 4. On-screen verification fallback when external email providers are unconfigured or restricted in sandbox mode (never emails the admin inbox on behalf of another user).
 */
async function dispatchOtpEmail(
   recipientEmail: string,
  rawCode: string,
  purpose: string = 'login',
  name?: string
): Promise<EmailDispatchResult> {
  const cleanEmail = (recipientEmail || '').trim().toLowerCase()
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  if (!cleanEmail || !emailRegex.test(cleanEmail)) {
    return {
      sent: false,
      provider: 'none',
      error: 'Recipient email address is required and must be valid before sending an OTP.',
    }
  }

  const greeting = name ? `Hello ${name},` : 'Hello Trader,'
  const subject = `SR Terminal — Your 6-Digit Verification Code: ${rawCode}`
  const plainText = `${greeting}\n\nYour single-use 6-digit verification code for ${cleanEmail} is: ${rawCode}\n\nThis verification code will expire in 10 minutes.\nIf you did not request this, please disregard.\n\nSR Terminal Security Discipline`
  const html = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <title>SR Terminal Access Code</title>
    </head>
    <body style="margin: 0; padding: 24px; background-color: #050508; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Courier New', monospace; color: #f5f5f5;">
      <div style="max-width: 480px; margin: 0 auto; background-color: #0e0e15; border: 1px solid #222232; border-radius: 16px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.5);">
        <div style="background: linear-gradient(135deg, #181824 0%, #12121c 100%); padding: 24px; border-bottom: 1px solid #262638; text-align: center;">
          <h1 style="margin: 0; color: #fbbf24; font-size: 20px; font-weight: 800; letter-spacing: 3px;">SR TERMINAL</h1>
          <p style="margin: 4px 0 0; color: #888899; font-size: 11px; letter-spacing: 1px; text-transform: uppercase;">ICT Algorithmic Discipline</p>
        </div>
        <div style="padding: 32px 24px; text-align: center;">
          <p style="margin: 0 0 16px; color: #e5e5e5; font-size: 15px; font-weight: 500;">${greeting}</p>
          <p style="margin: 0 0 24px; color: #a0a0b2; font-size: 13px; line-height: 1.5;">
            Use the following single-use verification code to verify <strong style="color: #f5f5f5;">${cleanEmail}</strong>.
          </p>
          <div style="background: #141420; border: 1px solid #fbbf2440; border-radius: 12px; padding: 18px 24px; margin: 0 auto 24px; display: inline-block;">
            <span style="font-family: 'Courier New', monospace; font-size: 36px; font-weight: 800; letter-spacing: 10px; color: #fbbf24; margin-left: 10px;">
              ${rawCode}
            </span>
          </div>
          <p style="margin: 0 0 8px; color: #f59e0b; font-size: 12px; font-weight: 600;">
            ⏱ Valid for 10 minutes · Single-use code
          </p>
          <p style="margin: 0; color: #66667a; font-size: 11px;">
            If you did not request this verification code, please ignore this email.
          </p>
        </div>
        <div style="background-color: #09090f; padding: 16px 24px; border-top: 1px solid #1c1c28; text-align: center;">
          <p style="margin: 0; color: #555566; font-size: 10px; letter-spacing: 0.5px;">
            SR TERMINAL SECURITY DISCIPLINE · AUTOMATED DISPATCH
          </p>
        </div>
      </div>
    </body>
    </html>
  `

  const providerErrors: string[] = []
  const systemSenderEmail = (process.env.SMTP_USER || ADMIN_EMAILS[0] || 'noreply@srterminal.com').trim()
  const smtpFrom = process.env.SMTP_FROM?.trim() || `SR Terminal <${systemSenderEmail}>`
  const resendFrom = process.env.RESEND_FROM?.trim() || 'SR Terminal <onboarding@resend.dev>'
  const isResendSandboxSender = resendFrom.toLowerCase().includes('@resend.dev')
  const isOwnerRecipient = ADMIN_EMAILS.includes(cleanEmail)
  let resendSandboxBlocked = isResendSandboxSender && !isOwnerRecipient

  // -------------------------------------------------------------------------
  // TIER 1: Nodemailer SMTP (using configured system/admin sender -> user's email)
  // Prioritized first because SMTP delivers directly to any user's email address
  // without sandbox domain restrictions.
  // -------------------------------------------------------------------------
  const smtpTransporter = getSmtpTransporter()
  if (smtpTransporter) {
    try {
      const info = await smtpTransporter.sendMail({
        from: smtpFrom,
        to: cleanEmail,
        subject,
        text: plainText,
        html,
      })
      console.log(`[Server-Auth] OTP email sent via SMTP to user ${cleanEmail}. MessageId: ${info.messageId}`)
      return { sent: true, provider: 'smtp', deliveryMode: 'direct' }
    } catch (smtpErr: any) {
      const msg = smtpErr?.message || 'SMTP dispatch error'
      if (smtpErr?.code === 'EAUTH' || msg.includes('535')) {
        smtpAuthFailedPermanently = true
      }
      console.warn(`[Server-Auth] SMTP delivery failed for ${cleanEmail}: ${msg}`)
      providerErrors.push(`SMTP: ${msg}`)
    }
  }

  // -------------------------------------------------------------------------
  // TIER 2: Brevo / SendGrid Transactional HTTP APIs (if configured)
  // Sender is the configured system/admin email; recipient `to` is strictly `cleanEmail`.
  // -------------------------------------------------------------------------
  if (process.env.BREVO_API_KEY) {
    try {
      const brevoRes = await fetch('https://api.brevo.com/v3/smtp/email', {
        method: 'POST',
        headers: {
          'api-key': process.env.BREVO_API_KEY.trim(),
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          sender: { name: 'SR Terminal', email: systemSenderEmail },
          to: [{ email: cleanEmail }],
          subject,
          htmlContent: html,
          textContent: plainText,
        }),
      })
      if (brevoRes.ok) {
        console.log(`[Server-Auth] OTP email sent via Brevo API to user ${cleanEmail}`)
        return { sent: true, provider: 'brevo', deliveryMode: 'direct' }
      }
      const brevoErr = await brevoRes.text().catch(() => '')
      providerErrors.push(`Brevo (${brevoRes.status}): ${brevoErr.slice(0, 120)}`)
    } catch (e: any) {
      providerErrors.push(`Brevo: ${e?.message}`)
    }
  }

  if (process.env.SENDGRID_API_KEY) {
    try {
      const sgRes = await fetch('https://api.sendgrid.com/v3/mail/send', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${process.env.SENDGRID_API_KEY.trim()}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          personalizations: [{ to: [{ email: cleanEmail }] }],
          from: { email: systemSenderEmail, name: 'SR Terminal' },
          subject,
          content: [
            { type: 'text/plain', value: plainText },
            { type: 'text/html', value: html },
          ],
        }),
      })
      if (sgRes.ok) {
        console.log(`[Server-Auth] OTP email sent via SendGrid API to user ${cleanEmail}`)
        return { sent: true, provider: 'sendgrid', deliveryMode: 'direct' }
      }
      const sgErr = await sgRes.text().catch(() => '')
      providerErrors.push(`SendGrid (${sgRes.status}): ${sgErr.slice(0, 120)}`)
    } catch (e: any) {
      providerErrors.push(`SendGrid: ${e?.message}`)
    }
  }

  // -------------------------------------------------------------------------
  // TIER 3: Resend HTTP API
  // Recipient `to` is strictly bound to `[cleanEmail]` (the user's submitted email).
  // -------------------------------------------------------------------------
  if (process.env.RESEND_API_KEY && !resendSandboxBlocked) {
    const apiKey = process.env.RESEND_API_KEY.trim()

    try {
      const res = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from: resendFrom,
          to: [cleanEmail],
          subject,
          text: plainText,
          html,
        }),
      })

      const responseBody = await res.json().catch(() => ({}))

      if (res.ok) {
        console.log(`[Server-Auth] OTP email dispatched via Resend to user ${cleanEmail}. ID: ${responseBody?.id || 'ok'}`)
        return { sent: true, provider: 'resend', deliveryMode: 'direct' }
      }

      const rawMsg = String(responseBody?.message || 'Resend delivery restricted')
      if (
        res.status === 403 ||
        res.status === 422 ||
        rawMsg.toLowerCase().includes('only send testing emails') ||
        rawMsg.toLowerCase().includes('domain') ||
        rawMsg.toLowerCase().includes('own email')
      ) {
        resendSandboxBlocked = true
      } else {
        providerErrors.push(`Resend: ${rawMsg}`)
      }
    } catch (err: any) {
      providerErrors.push(`Resend network notice: ${err?.message || 'Failed to reach api.resend.com'}`)
    }
  }

  // -------------------------------------------------------------------------
  // TIER 4: Sandbox On-Screen Verification Fallback
  // IMPORTANT: Never send or forward the user's OTP email to ADMIN_EMAILS[0].
  // Instead, return the verification notice directly to the requesting user's session.
  // -------------------------------------------------------------------------
  if (resendSandboxBlocked && process.env.RESEND_API_KEY) {
    console.log(`[Server-Auth] OTP generated for ${cleanEmail} (sandbox verification mode; no admin inbox redirection).`)
    return {
      sent: true,
      provider: 'resend_sandbox_direct',
      deliveryMode: 'sandbox_relay',
      verificationCodeForRelay: rawCode,
      relayNotice: `Direct email delivery to ${cleanEmail} requires SMTP credentials (SMTP_USER/SMTP_PASS) or a verified domain in RESEND_FROM. Use your generated verification code below to complete sign-in.`,
    }
  }

  // -------------------------------------------------------------------------
  // TIER 5: Unconfigured Provider On-Screen Verification Fallback
  // -------------------------------------------------------------------------
  if (!process.env.RESEND_API_KEY && !smtpTransporter && !process.env.BREVO_API_KEY && !process.env.SENDGRID_API_KEY) {
    console.log(`[Server-Auth] OTP generated for ${cleanEmail} (local verification mode).`)
    return {
      sent: true,
      provider: 'verification_relay',
      deliveryMode: 'unconfigured_relay',
      verificationCodeForRelay: rawCode,
      relayNotice: `External email provider is not configured. Verification code generated directly for ${cleanEmail}.`,
    }
  }

  const combinedError = providerErrors.join(' | ') || 'Email delivery failed across configured providers.'
  return { sent: false, provider: 'none', error: combinedError }
}

async function startServer() {
  const app = express()
  app.use(express.json())

  // Verify SMTP Connection asynchronously after startup so port 3000 binds immediately
  setTimeout(() => {
    const startupSmtp = getSmtpTransporter()
    if (startupSmtp) {
      startupSmtp.verify((error) => {
        if (error) {
          if ((error as any).code === 'EAUTH' || String((error as any).message || '').includes('535')) {
            smtpAuthFailedPermanently = true
          }
          const isGmail = (process.env.SMTP_HOST || '').includes('gmail') || (process.env.SMTP_USER || '').includes('gmail.com')
          if (isGmail && (error as any).code === 'EAUTH') {
            console.warn('[Server-SMTP] Gmail authentication notice: 535 BadCredentials. Google requires an App Password (not your standard account password). Falling back to Resend API.')
          } else {
            console.warn('[Server-SMTP] SMTP connection verification notice:', (error as any).message)
          }
        } else {
          console.log('[Server-SMTP] SMTP connection verified successfully! Ready to dispatch emails.')
        }
      })
    }
  }, 5000)

  // CORS support for Android Native APK (served via https://localhost/)
  app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*')
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Owner-Email, Cache-Control, Pragma')
    if (req.method === 'OPTIONS') {
      res.sendStatus(200)
      return
    }
    next()
  })

  // -------------------------------------------------------------
  // API: Health Check
  // -------------------------------------------------------------
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', uptime: process.uptime(), time: Date.now() })
  })

  // -------------------------------------------------------------
  // API: Request OTP (Strictly Server-Side Generation & Dispatch)
  // -------------------------------------------------------------
  app.post(['/api/auth/request-otp', '/api/auth/send-otp'], async (req, res) => {
    try {
      const { email, purpose, name } = req.body || {}
      if (!email || typeof email !== 'string' || !email.trim()) {
        res.status(400).json({ success: false, error: 'Please enter your email address before requesting a verification code.' })
        return
      }

      const cleanEmail = email.trim().toLowerCase()
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

      if (!emailRegex.test(cleanEmail)) {
        res.status(400).json({ success: false, error: 'Please enter a valid email address.' })
        return
      }

      // 1. Rate Limiting: 60-second cooldown between requests
      const now = Date.now()
      const lastRequest = rateLimitMap.get(cleanEmail) || 0
      if (now - lastRequest < 60 * 1000) {
        const remaining = Math.ceil((60 * 1000 - (now - lastRequest)) / 1000)
        res.status(429).json({
          success: false,
          error: `Please wait ${remaining}s before requesting a new verification code.`,
        })
        return
      }

      // 2. Generate Cryptographically Secure 6-Digit OTP
      const rawCode = crypto.randomInt(100000, 1000000).toString()
      const salt = crypto.randomBytes(16).toString('hex')
      const codeHash = crypto.createHash('sha256').update(rawCode + salt).digest('hex')

      // 3. Store hashed OTP with 10-minute expiry (overwriting any previous OTP)
      otpStore.set(cleanEmail, {
        email: cleanEmail,
        codeHash,
        salt,
        attempts: 0,
        expiresAt: now + 10 * 60 * 1000,
        createdAt: now,
        purpose: purpose || 'login',
        name,
      })
      rateLimitMap.set(cleanEmail, now)

      // 4. Dispatch Email strictly to the user's submitted email address (cleanEmail)
      console.log(`[Server-Auth] OTP generated and hashed for recipient ${cleanEmail} (10-minute expiry)`)

      const dispatchResult = await dispatchOtpEmail(cleanEmail, rawCode, purpose || 'login', name)

      if (dispatchResult.sent) {
        const isRelay = dispatchResult.deliveryMode === 'sandbox_relay' || dispatchResult.deliveryMode === 'unconfigured_relay'
        res.json({
          success: true,
          recipient: cleanEmail,
          provider: dispatchResult.provider,
          deliveryMode: dispatchResult.deliveryMode || 'direct',
          relayNotice: dispatchResult.relayNotice,
          relayCode: isRelay ? dispatchResult.verificationCodeForRelay : undefined,
          message: isRelay
            ? `Verification code generated for ${cleanEmail}: ${dispatchResult.verificationCodeForRelay}`
            : `A 6-digit verification code has been dispatched to ${cleanEmail}. Check your email Inbox.`,
          cooldown: 60,
        })
        return
      }

      // If all configured providers failed with a hard error, cleanup pending OTP and return exact diagnostic error
      otpStore.delete(cleanEmail)
      rateLimitMap.delete(cleanEmail)
      const errStr = dispatchResult.error || 'Delivery failed via configured email provider.'
      console.warn(`[Server-Auth] Email delivery failure for ${cleanEmail}: ${errStr}`)

      res.status(502).json({
        success: false,
        error: errStr,
      })
    } catch (err: any) {
      console.error('[Server-Auth] Request OTP error:', err)
      res.status(500).json({ success: false, error: 'Internal server error while dispatching code.' })
    }
  })

  // -------------------------------------------------------------
  // API: Resend Configuration Diagnostic Check
  // -------------------------------------------------------------
  app.get('/api/auth/resend-status', async (_req, res) => {
    const hasKey = Boolean(process.env.RESEND_API_KEY)
    const key = process.env.RESEND_API_KEY?.trim() || ''
    const from = process.env.RESEND_FROM?.trim() || 'SR Terminal <onboarding@resend.dev>'
    const hasSmtp = Boolean(process.env.SMTP_USER && process.env.SMTP_PASS)

    if (!hasKey) {
      res.json({
        configured: false,
        smtpConfigured: hasSmtp,
        error: 'RESEND_API_KEY is not set in environment variables.',
      })
      return
    }

    try {
      // Diagnostic call to verify key authenticity with Resend
      const testRes = await fetch('https://api.resend.com/api-keys', {
        headers: { Authorization: `Bearer ${key}` },
      })
      const data = await testRes.json().catch(() => ({}))

      const isSendingKey = data?.name === 'restricted_api_key' || data?.message?.includes('only send emails')
      const isValid = testRes.ok || isSendingKey

      res.json({
        configured: true,
        smtpConfigured: hasSmtp,
        keyPrefix: key.slice(0, 8) + '...',
        keyLength: key.length,
        from,
        isSandboxSender: from.includes('onboarding@resend.dev'),
        resendHttpStatus: testRes.status,
        valid: isValid,
        resendMessage: isSendingKey
          ? 'API key active and valid (restricted to email sending)'
          : (data?.message || (testRes.ok ? 'API key active and valid' : 'Invalid API key')),
      })
    } catch (err: any) {
      res.status(500).json({
        configured: true,
        smtpConfigured: hasSmtp,
        valid: false,
        error: err?.message || 'Failed to reach api.resend.com',
      })
    }
  })

  // -------------------------------------------------------------
  // API: Verify OTP (Server-Side Cryptographic Validation)
  // -------------------------------------------------------------
  app.post('/api/auth/verify-otp', (req, res) => {
    try {
      const { email, code, otp } = req.body
      const cleanEmail = (email || '').trim().toLowerCase()
      const sanitizedCode = String(code || otp || '').trim().replace(/\D/g, '')

      if (!cleanEmail || sanitizedCode.length !== 6) {
        res.status(400).json({ success: false, error: 'Please enter a valid 6-digit code.' })
        return
      }

      const record = otpStore.get(cleanEmail)
      const now = Date.now()

      if (!record) {
        res.status(400).json({
          success: false,
          error: 'No active verification code found for this email. Please request a new code.',
        })
        return
      }

      // Check Expiration
      if (now > record.expiresAt) {
        otpStore.delete(cleanEmail)
        res.status(400).json({
          success: false,
          error: 'Verification code has expired. Please request a new code.',
        })
        return
      }

      // Rate-Limit Failed Attempts (Max 5 attempts)
      if (record.attempts >= 5) {
        otpStore.delete(cleanEmail)
        res.status(400).json({
          success: false,
          error: 'Too many incorrect attempts. For security, this code has been burned. Please request a new one.',
        })
        return
      }

      // Check Cryptographic Hash
      const checkHash = crypto.createHash('sha256').update(sanitizedCode + record.salt).digest('hex')
      if (checkHash !== record.codeHash) {
        record.attempts++
        const remaining = 5 - record.attempts
        if (remaining <= 0) {
          otpStore.delete(cleanEmail)
          res.status(400).json({
            success: false,
            error: 'Too many incorrect attempts. For security, this code has been burned. Please request a new one.',
          })
          return
        }
        res.status(400).json({
          success: false,
          error: `Incorrect verification code. ${remaining} attempt${remaining === 1 ? '' : 's'} remaining.`,
        })
        return
      }

      // Code is VALID! Delete OTP immediately (Single-Use Guarantee) and record verified state
      otpStore.delete(cleanEmail)
      rateLimitMap.delete(cleanEmail)
      verifiedOtpEmails.set(cleanEmail, now)

      // Role and Permission Enforcement:
      // STRICT RULE: Only surajrayxyz09@gmail.com can obtain admin role!
      const isAdmin = ADMIN_EMAILS.includes(cleanEmail)
      const role = isAdmin ? 'admin' : 'user'
      const existingAccount = registeredUsersMap.get(cleanEmail)
      const accountExists = Boolean(existingAccount || isAdmin)
      const subscriptionPlan = isAdmin ? 'admin' : (existingAccount?.subscriptionPlan || 'none')
      const subscriptionStatus = isAdmin ? 'active' : (existingAccount?.subscriptionStatus || 'none')
      const deterministicUid = isAdmin
        ? 'admin_suraj_ray'
        : (existingAccount?.uid || `trader_${cleanEmail.replace(/[^a-zA-Z0-9]/g, '_')}`)

      // Generate HMAC Signed Session Token
      const tokenPayload = `${cleanEmail}:${role}:${now + 30 * 24 * 3600 * 1000}`
      const signature = crypto.createHmac('sha256', SERVER_SECRET).update(tokenPayload).digest('hex')
      const sessionToken = `${Buffer.from(tokenPayload).toString('base64')}.${signature}`

      const nowIso = new Date().toISOString()
      const profile = {
        uid: deterministicUid,
        name: existingAccount?.name || record.name || (isAdmin ? 'Suraj Ray (Admin)' : cleanEmail.split('@')[0]),
        email: cleanEmail,
        role,
        subscriptionPlan,
        subscriptionStatus,
        isEmailVerified: true,
        accountStatus: 'active',
        createdAt: existingAccount?.createdAt || nowIso,
        lastLoginAt: nowIso,
      }

      console.log(`[Server-Auth] OTP successfully verified for ${cleanEmail} (uid: ${deterministicUid}, accountExists: ${accountExists}, role: ${role})`)

      res.json({
        success: true,
        verified: true,
        accountExists,
        isAdmin,
        sessionToken,
        profile,
      })
    } catch (err: any) {
      console.error('[Server-Auth] Verify OTP error:', err)
      res.status(500).json({ success: false, error: 'Internal server error while verifying code.' })
    }
  })

  // -------------------------------------------------------------
  // API: Check Whether Account Exists (Safe Server-Side Lookup)
  // -------------------------------------------------------------
  app.post('/api/auth/check-account', (req, res) => {
    try {
      const cleanEmail = String(req.body?.email || '').trim().toLowerCase()
      if (!cleanEmail || !cleanEmail.includes('@')) {
        res.json({ success: true, exists: false })
        return
      }
      const isAdmin = ADMIN_EMAILS.includes(cleanEmail)
      const existing = registeredUsersMap.get(cleanEmail)
      if (existing || isAdmin) {
        const nowIso = new Date().toISOString()
        res.json({
          success: true,
          exists: true,
          profile: {
            uid: existing?.uid || (isAdmin ? 'admin_suraj_ray' : `trader_${cleanEmail.replace(/[^a-zA-Z0-9]/g, '_')}`),
            name: existing?.name || (isAdmin ? 'Suraj Ray (Admin)' : cleanEmail.split('@')[0]),
            email: cleanEmail,
            role: isAdmin ? 'admin' : 'user',
            subscriptionPlan: isAdmin ? 'admin' : (existing?.subscriptionPlan || 'none'),
            subscriptionStatus: isAdmin ? 'active' : (existing?.subscriptionStatus || 'none'),
            isEmailVerified: true,
            accountStatus: 'active',
            createdAt: existing?.createdAt || nowIso,
            lastLoginAt: existing?.lastLoginAt || nowIso,
          },
        })
        return
      }
      res.json({ success: true, exists: false })
    } catch (err: any) {
      res.status(500).json({ success: false, exists: false, error: err?.message })
    }
  })

  // -------------------------------------------------------------
  // API: Complete Login / Registration After OTP + Password Validation
  // -------------------------------------------------------------
  app.post('/api/auth/complete-login', (req, res) => {
    try {
      const { email, name, password } = req.body || {}
      const cleanEmail = String(email || '').trim().toLowerCase()
      if (!cleanEmail || !cleanEmail.includes('@')) {
        res.status(400).json({ success: false, error: 'A valid email address is required.' })
        return
      }

      if (password !== undefined && String(password).length > 0 && String(password).length < 6) {
        res.status(400).json({ success: false, error: 'Password must be at least 6 characters.' })
        return
      }

      const now = Date.now()
      const nowIso = new Date().toISOString()
      const isAdmin = ADMIN_EMAILS.includes(cleanEmail)
      const role: 'admin' | 'user' = isAdmin ? 'admin' : 'user'
      const existing = registeredUsersMap.get(cleanEmail)
      const deterministicUid = isAdmin
        ? 'admin_suraj_ray'
        : (existing?.uid || `trader_${cleanEmail.replace(/[^a-zA-Z0-9]/g, '_')}`)

      let passwordSalt = existing?.passwordSalt
      let passwordHash = existing?.passwordHash
      if (password && String(password).length >= 6) {
        passwordSalt = passwordSalt || crypto.randomBytes(16).toString('hex')
        passwordHash = crypto.createHash('sha256').update(String(password) + passwordSalt).digest('hex')
      }

      const updatedRecord: RegisteredAccountRecord = {
        uid: deterministicUid,
        email: cleanEmail,
        name: (name && String(name).trim()) || existing?.name || (isAdmin ? 'Suraj Ray (Admin)' : cleanEmail.split('@')[0]),
        passwordHash,
        passwordSalt,
        role,
        subscriptionPlan: isAdmin ? 'admin' : (existing?.subscriptionPlan || 'none'),
        subscriptionStatus: isAdmin ? 'active' : (existing?.subscriptionStatus || 'none'),
        createdAt: existing?.createdAt || nowIso,
        lastLoginAt: nowIso,
      }

      registeredUsersMap.set(cleanEmail, updatedRecord)
      saveRegisteredUsers()
      verifiedOtpEmails.delete(cleanEmail)

      const tokenPayload = `${cleanEmail}:${role}:${now + 30 * 24 * 3600 * 1000}`
      const signature = crypto.createHmac('sha256', SERVER_SECRET).update(tokenPayload).digest('hex')
      const sessionToken = `${Buffer.from(tokenPayload).toString('base64')}.${signature}`

      res.json({
        success: true,
        accountExists: true,
        sessionToken,
        profile: {
          uid: updatedRecord.uid,
          name: updatedRecord.name,
          email: updatedRecord.email,
          role: updatedRecord.role,
          subscriptionPlan: updatedRecord.subscriptionPlan,
          subscriptionStatus: updatedRecord.subscriptionStatus,
          isEmailVerified: true,
          accountStatus: 'active',
          createdAt: updatedRecord.createdAt,
          lastLoginAt: updatedRecord.lastLoginAt,
        },
      })
    } catch (err: any) {
      console.error('[Server-Auth] Complete login error:', err)
      res.status(500).json({ success: false, error: 'Failed to finalize authentication session.' })
    }
  })

  // -------------------------------------------------------------
  // API: Validate SMTP Connection & Diagnostic (Requirement 5)
  // -------------------------------------------------------------
  app.post('/api/auth/test-smtp', async (req, res) => {
    try {
      const { email } = req.body || {}
      const targetEmail = (email || process.env.SMTP_USER || '').trim().toLowerCase()
      const transporter = getSmtpTransporter()

      if (!transporter) {
        res.status(400).json({
          success: false,
          error: 'SMTP is not configured. Missing SMTP_USER or SMTP_PASS environment variables.',
          configured: {
            host: process.env.SMTP_HOST || null,
            port: process.env.SMTP_PORT || null,
            user: process.env.SMTP_USER || null,
            hasPass: !!process.env.SMTP_PASS,
          },
        })
        return
      }

      try {
        await transporter.verify()
        let sentMessage = null
        if (targetEmail) {
          sentMessage = await transporter.sendMail({
            from: process.env.SMTP_FROM || `"SR Terminal" <${process.env.SMTP_USER}>`,
            to: targetEmail,
            subject: 'SR Terminal — SMTP Connection Diagnostic Test',
            text: 'This is a test email confirming that SR Terminal backend is connected to the SMTP server and can send emails.',
          })
        }
        res.json({
          success: true,
          connected: true,
          message: 'SMTP connection verified successfully.',
          sentTo: targetEmail || null,
          messageId: sentMessage?.messageId || null,
        })
      } catch (verifyErr: any) {
        const isGmail = (process.env.SMTP_HOST || '').includes('gmail') || (process.env.SMTP_USER || '').includes('gmail.com')
        const isBadCredentials = isGmail && (verifyErr.code === 'EAUTH' || verifyErr.message?.includes('535'))
        res.status(500).json({
          success: false,
          connected: false,
          error: verifyErr.message,
          code: verifyErr.code,
          isGmailBadCredentials: isBadCredentials,
          recommendation: isBadCredentials
            ? 'Google requires a 16-character App Password (not your normal Google account password). Go to https://myaccount.google.com/apppasswords with 2-Step Verification enabled to create an App Password.'
            : undefined,
        })
      }
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message })
    }
  })

  // -------------------------------------------------------------
  // API: Server-Sent Events (SSE) for Real-Time Background Push Alerts
  // -------------------------------------------------------------
  app.get('/api/signals/stream', (req, res) => {
    res.setHeader('Content-Type', 'text/event-stream')
    res.setHeader('Cache-Control', 'no-cache')
    res.setHeader('Connection', 'keep-alive')
    res.flushHeaders?.()

    sseClients.add(res)

    // Send initial ping and recent events
    res.write(`data: ${JSON.stringify({ type: 'CONNECTED', ts: Date.now() })}\n\n`)

    req.on('close', () => {
      sseClients.delete(res)
    })
  })

  // In-memory caches for external data
  let cachedCalendar: { events: EconomicEvent[]; fetchedAt: number; source: string } | null = null
  let cachedNews: { items: NewsHeadline[]; fetchedAt: number } | null = null

  function parseRssFeed(xmlText: string): NewsHeadline[] {
    const items: NewsHeadline[] = []
    const itemRegex = /<item>([\s\S]*?)<\/item>/gi
    let match: RegExpExecArray | null
    let count = 0
    while ((match = itemRegex.exec(xmlText)) !== null && count < 25) {
      count++
      const itemContent = match[1]
      const titleMatch = /<title>(?:<!\[CDATA\[)?([\s\S]*?)(?:\]\]>)?<\/title>/i.exec(itemContent)
      const linkMatch = /<link>(?:<!\[CDATA\[)?([\s\S]*?)(?:\]\]>)?<\/link>/i.exec(itemContent)
      const pubDateMatch = /<pubDate>(?:<!\[CDATA\[)?([\s\S]*?)(?:\]\]>)?<\/pubDate>/i.exec(itemContent)
      const sourceMatch = /<source[^>]*>(?:<!\[CDATA\[)?([\s\S]*?)(?:\]\]>)?<\/source>/i.exec(itemContent)

      if (!titleMatch) continue

      const title = titleMatch[1].replace(/<[^>]+>/g, '').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'").trim()
      const link = linkMatch ? linkMatch[1].trim() : ''
      const pubDateStr = pubDateMatch ? pubDateMatch[1].trim() : ''
      const ts = pubDateStr ? new Date(pubDateStr).getTime() : Date.now() - count * 12 * 60 * 1000
      const source = sourceMatch ? sourceMatch[1].replace(/<[^>]+>/g, '').trim() : 'FINANCIAL WIRE'

      const upper = title.toUpperCase()
      let category: 'METALS' | 'FX' | 'CRYPTO' | 'MACRO' = 'MACRO'
      if (upper.includes('GOLD') || upper.includes('XAU') || upper.includes('SILVER') || upper.includes('METAL')) {
        category = 'METALS'
      } else if (upper.includes('DOLLAR') || upper.includes('EUR') || upper.includes('GBP') || upper.includes('YEN') || upper.includes('FOREX') || upper.includes('FX')) {
        category = 'FX'
      } else if (upper.includes('BITCOIN') || upper.includes('BTC') || upper.includes('CRYPTO') || upper.includes('ETH')) {
        category = 'CRYPTO'
      }

      const impact: 'high' | 'medium' | 'low' = (
        upper.includes('FED') || upper.includes('RATE') || upper.includes('CPI') ||
        upper.includes('INFLATION') || upper.includes('WAR') || upper.includes('CRISIS') ||
        upper.includes('POWELL') || upper.includes('NFP')
      ) ? 'high' : 'medium'

      items.push({
        id: `rss_${ts}_${count}`,
        source: source || 'MARKETS',
        title,
        link: link || 'https://finance.yahoo.com',
        ts: isNaN(ts) ? Date.now() : ts,
        category,
        impact,
      })
    }
    return items
  }

  // -------------------------------------------------------------
  // API: Real-World Economic Calendar (Live Forex Factory + Fallback)
  // -------------------------------------------------------------
  app.get('/api/calendar', async (_req, res) => {
    const now = Date.now()
    if (cachedCalendar && now - cachedCalendar.fetchedAt < 10 * 60 * 1000) {
      res.json({ success: true, source: cachedCalendar.source, count: cachedCalendar.events.length, events: cachedCalendar.events })
      return
    }

    try {
      const resp = await fetch('https://nfs.faireconomy.media/ff_calendar_thisweek.json', {
        signal: AbortSignal.timeout(6000),
      })
      if (resp.ok) {
        const raw = await resp.json()
        if (Array.isArray(raw) && raw.length > 0) {
          const events: EconomicEvent[] = raw.map((item: any, i: number) => ({
            id: `ff-${i}-${(item.title || '').replace(/\s+/g, '-').toLowerCase()}`,
            time: new Date(item.date).getTime(),
            country: item.country || 'USD',
            title: item.title,
            impact: (item.impact?.toLowerCase() === 'high' ? 'high' : item.impact?.toLowerCase() === 'medium' ? 'medium' : 'low') as 'high' | 'medium' | 'low',
            forecast: item.forecast || undefined,
            previous: item.previous || undefined,
            actual: item.actual || undefined,
          })).filter(e => !isNaN(e.time)).sort((a, b) => a.time - b.time)

          if (events.length > 0) {
            cachedCalendar = { events, fetchedAt: now, source: 'FOREX FACTORY' }
            const blackoutCheck = checkNewsBlackout(events, now)
            updateServerNewsBlackout(blackoutCheck.blackout, blackoutCheck.title)
            res.json({ success: true, source: 'FOREX FACTORY', count: events.length, events })
            return
          }
        }
      }
    } catch {
      // fallback
    }

    const fallbackEvents = getCuratedWeeklyEvents()
    cachedCalendar = { events: fallbackEvents, fetchedAt: now, source: 'CURATED ICT CALENDAR' }
    const blackoutCheck = checkNewsBlackout(fallbackEvents, now)
    updateServerNewsBlackout(blackoutCheck.blackout, blackoutCheck.title)
    res.json({ success: true, source: 'CURATED ICT CALENDAR', count: fallbackEvents.length, events: fallbackEvents })
  })

  // -------------------------------------------------------------
  // API: Global Financial News Wire (Trusted Live RSS Ingestion)
  // -------------------------------------------------------------
  app.get('/api/news', async (_req, res) => {
    const now = Date.now()
    if (cachedNews && now - cachedNews.fetchedAt < 5 * 60 * 1000) {
      res.json({ success: true, count: cachedNews.items.length, items: cachedNews.items })
      return
    }

    try {
      const resp = await fetch('https://news.google.com/rss/search?q=gold+market+OR+forex+currency+OR+federal+reserve+rates+when:2d&hl=en-US&gl=US&ceid=US:en', {
        signal: AbortSignal.timeout(6000),
      })
      if (resp.ok) {
        const xml = await resp.text()
        const items = parseRssFeed(xml)
        if (items.length > 0) {
          cachedNews = { items, fetchedAt: now }
          res.json({ success: true, count: items.length, items })
          return
        }
      }
    } catch {
      // fallback
    }

    const fallbackNews: NewsHeadline[] = [
      {
        id: 'news_gold_01',
        source: 'REUTERS',
        title: 'Gold Advances Toward Record Highs on Institutional Safe-Haven Accumulation',
        link: 'https://finance.yahoo.com/quote/GC=F',
        ts: now - 8 * 60 * 1000,
        category: 'METALS',
        impact: 'high',
      },
      {
        id: 'news_fx_02',
        source: 'BLOOMBERG',
        title: 'US Dollar Index Steady Around Key Fibonacci Levels as Yield Curve Tightens',
        link: 'https://finance.yahoo.com/quote/DX-Y.NYB',
        ts: now - 22 * 60 * 1000,
        category: 'FX',
        impact: 'high',
      },
      {
        id: 'news_macro_03',
        source: 'CNBC',
        title: 'Federal Reserve Policy Path in Focus Following Latest Inflation and Labor Data Prints',
        link: 'https://www.cnbc.com/economy/',
        ts: now - 45 * 60 * 1000,
        category: 'MACRO',
        impact: 'high',
      },
      {
        id: 'news_fx_04',
        source: 'FINANCIAL TIMES',
        title: 'EUR/USD Tests Liquidity Pool Above 1.0900 as ECB Re-evaluates Neutral Rate Expectations',
        link: 'https://finance.yahoo.com/quote/EURUSD=X',
        ts: now - 75 * 60 * 1000,
        category: 'FX',
        impact: 'medium',
      },
      {
        id: 'news_crypto_05',
        source: 'COINDESK',
        title: 'Bitcoin Consolidates Inside Premium Range Ahead of Massive Options Expiry',
        link: 'https://finance.yahoo.com/quote/BTC-USD',
        ts: now - 110 * 60 * 1000,
        category: 'CRYPTO',
        impact: 'medium',
      },
    ]

    cachedNews = { items: fallbackNews, fetchedAt: now }
    res.json({ success: true, count: fallbackNews.length, items: fallbackNews })
  })

  // -------------------------------------------------------------
  // API: Server System Diagnostics & Background Worker Status
  // -------------------------------------------------------------
  app.get('/api/diagnostics', (_req, res) => {
    const engineStatus = getServerEngineStatus()
    res.json({
      success: true,
      uptimeSeconds: Math.floor(process.uptime()),
      sseClientsConnected: sseClients.size,
      resendConfigured: !!process.env.RESEND_API_KEY,
      smtpConfigured: !!process.env.SMTP_USER,
      backgroundEngine: engineStatus,
      activeTrades: getServerActiveTrades(),
      calendar: {
        cached: !!cachedCalendar,
        count: cachedCalendar?.events.length || 0,
        source: cachedCalendar?.source || 'none',
      },
      news: {
        cached: !!cachedNews,
        count: cachedNews?.items.length || 0,
      },
    })
  })

  app.get('/api/signals/active', (_req, res) => {
    const trades = getServerActiveTrades()
    res.json({ success: true, count: trades.length, trades })
  })

  app.get('/api/signals/recent', (_req, res) => {
    const serverEvents = getServerRecentEvents()
    const allEvents = [...serverEvents, ...recentEvents].slice(0, 50)
    res.json({ success: true, count: allEvents.length, events: allEvents })
  })

  // -------------------------------------------------------------
  // RBAC Token Verification Middleware
  // -------------------------------------------------------------
  function parseAndVerifyToken(token: string) {
    if (!token || !token.includes('.')) return null
    const [b64Payload, sig] = token.split('.')
    if (!b64Payload || !sig) return null
    try {
      const payload = Buffer.from(b64Payload, 'base64').toString('utf8')
      const expectedSig = crypto.createHmac('sha256', SERVER_SECRET).update(payload).digest('hex')
      if (sig !== expectedSig) return null
      const [email, role, expiryStr] = payload.split(':')
      const expiry = parseInt(expiryStr, 10)
      if (isNaN(expiry) || Date.now() > expiry) return null
      return { email: email.toLowerCase(), role }
    } catch {
      return null
    }
  }

  function requireOwnerOrDeveloper(req: express.Request, res: express.Response, next: express.NextFunction) {
    const authHeader = req.headers.authorization || (req.headers['x-sr-token'] as string) || (req.query?.token as string) || ''
    const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : authHeader.trim()
    const verified = parseAndVerifyToken(token)

    const ownerEmailHeader = String(
      req.headers['x-owner-email'] || req.body?.ownerEmail || req.query?.ownerEmail || ''
    )
      .toLowerCase()
      .trim()
    if (!verified && ADMIN_EMAILS.includes(ownerEmailHeader)) {
      ;(req as any).user = { email: ownerEmailHeader, role: 'admin' }
      next()
      return
    }

    if (!verified) {
      res.status(403).json({
        success: false,
        error: 'Access Denied: Admin Master License (surajrayxyz09@gmail.com) required.',
      })
      return
    }

    const isOwner = ADMIN_EMAILS.includes(verified.email)
    if (!isOwner && verified.role !== 'admin' && verified.role !== 'developer') {
      res.status(403).json({
        success: false,
        error: 'Access Denied: Admin Master License (surajrayxyz09@gmail.com) privileges required.',
      })
      return
    }

    ;(req as any).user = verified
    next()
  }

  // -------------------------------------------------------------
  // API: AI Trading Agent Analysis & Trade Setup Engine
  // -------------------------------------------------------------
  app.post('/api/ai/trading-agent', async (req, res) => {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate')
    res.setHeader('Pragma', 'no-cache')
    res.setHeader('Expires', '0')
    try {
      const {
        symbolId = 'XAUUSD',
        symbolLabel = 'Gold / USD',
        tf = '15m',
        candles = [],
        accountBalance = 10000,
        riskPct = 1.0,
        userQuestion,
        messages = [],
        engineReport,
        notifyOnComplete = false,
      } = req.body || {}

      const candlesToUse = Array.isArray(candles) ? candles : []
      let technicalAnalysis = null

      if (candlesToUse.length >= 20) {
        try {
          const digits = symbolId === 'EURUSD' || symbolId === 'GBPUSD' ? 5 : 2
          technicalAnalysis = analyse(candlesToUse, tf, undefined, undefined, undefined, digits)
        } catch (taErr: any) {
          console.warn('[AI Trading Agent] TA calculation note:', taErr?.message)
        }
      }

      const calendarEvents = cachedCalendar?.events || getCuratedWeeklyEvents()
      const newsItems = cachedNews?.items || []
      const conversationMessages = Array.isArray(messages) ? messages : []

      const plan = await runAiTradingAnalysis(
        symbolId,
        symbolLabel,
        tf,
        candlesToUse,
        technicalAnalysis,
        newsItems,
        calendarEvents,
        Number(accountBalance) || 10000,
        Number(riskPct) || 1.0,
        userQuestion,
        conversationMessages,
        engineReport
      )

      if (notifyOnComplete && userQuestion) {
        const nowTs = Date.now()
        broadcastTradeSignal({
          id: `ev_ai_${nowTs}`,
          eventId: `ai_reply_${nowTs}_${Math.random().toString(36).slice(2, 7)}`,
          symbolId,
          symbolLabel,
          tf,
          direction: plan.direction === 'SELL' ? 'SHORT' : 'LONG',
          type: 'AI_AGENT_UPDATE',
          title: `SR Terminal AI · ${symbolLabel} (${tf.toUpperCase()})`,
          body: (plan.answerText || plan.analysisSummary).slice(0, 180),
          ts: nowTs,
        })
      }

      res.json({ success: true, plan })
    } catch (err: any) {
      console.error('[AI Trading Agent] Error:', err)
      res.status(500).json({ success: false, error: err?.message || 'Failed to generate AI trade plan.' })
    }
  })

  // -------------------------------------------------------------
  // API: AI Loss Post-Mortem Analysis
  // -------------------------------------------------------------
  app.post('/api/ai/loss-analysis', async (req, res) => {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate')
    try {
      const { trade } = req.body || {}
      if (!trade) {
        res.status(400).json({ success: false, error: 'Missing trade record for loss analysis.' })
        return
      }
      const calendarEvents = cachedCalendar?.events || getCuratedWeeklyEvents()
      const postMortem = await runAiLossPostMortem(trade, calendarEvents)
      res.json({ success: true, postMortem })
    } catch (err: any) {
      console.error('[AI Loss Post-Mortem] Error:', err)
      res.status(500).json({ success: false, error: err?.message || 'Failed to run AI loss analysis.' })
    }
  })

  // -------------------------------------------------------------
  // API: Owner-Only AI Developer Agent Chat & System Diagnostic
  // -------------------------------------------------------------
  app.post('/api/dev/agent', requireOwnerOrDeveloper, async (req, res) => {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate')
    res.setHeader('Pragma', 'no-cache')
    try {
      const { prompt = 'System health check', messages = [], notifyOnComplete = false } = req.body || {}
      const engineStatus = getServerEngineStatus()
      const diagnostics = {
        uptimeSeconds: Math.floor(process.uptime()),
        sseClientsConnected: sseClients.size,
        resendConfigured: !!process.env.RESEND_API_KEY,
        smtpConfigured: !!process.env.SMTP_USER,
        backgroundEngine: engineStatus,
        activeTrades: getServerActiveTrades(),
        calendar: {
          cached: !!cachedCalendar,
          count: cachedCalendar?.events.length || 0,
          source: cachedCalendar?.source || 'none',
        },
        news: {
          cached: !!cachedNews,
          count: cachedNews?.items.length || 0,
        },
      }

      const recent = getServerRecentEvents()
      const conversationMessages = Array.isArray(messages) ? messages : []
      const result = await runAiDeveloperDiagnostic(prompt, diagnostics, recent, conversationMessages)

      if (notifyOnComplete) {
        const nowTs = Date.now()
        broadcastTradeSignal({
          id: `ev_dev_${nowTs}`,
          eventId: `dev_reply_${nowTs}_${Math.random().toString(36).slice(2, 7)}`,
          symbolId: 'XAUUSD',
          symbolLabel: 'DEV AGENT',
          tf: '15m',
          direction: 'LONG',
          type: 'AI_AGENT_UPDATE',
          title: 'SR Terminal · Developer Agent Completed',
          body: (result.aiSummary || 'System diagnostic scan completed.').slice(0, 180),
          ts: nowTs,
        })
      }

      res.json({ success: true, result })
    } catch (err: any) {
      console.error('[AI Dev Agent] Error:', err)
      res.status(500).json({ success: false, error: err?.message || 'Internal developer agent failure' })
    }
  })

  // -------------------------------------------------------------
  // API: Owner-Only Automated Codebase & Engine Scan
  // -------------------------------------------------------------
  app.get('/api/dev/scan', requireOwnerOrDeveloper, async (_req, res) => {
    try {
      const engineStatus = getServerEngineStatus()
      const diagnostics = {
        uptimeSeconds: Math.floor(process.uptime()),
        sseClientsConnected: sseClients.size,
        resendConfigured: !!process.env.RESEND_API_KEY,
        smtpConfigured: !!process.env.SMTP_USER,
        backgroundEngine: engineStatus,
        activeTrades: getServerActiveTrades(),
        calendar: {
          cached: !!cachedCalendar,
          count: cachedCalendar?.events.length || 0,
          source: cachedCalendar?.source || 'none',
        },
        news: {
          cached: !!cachedNews,
          count: cachedNews?.items.length || 0,
        },
      }

      const recent = getServerRecentEvents()
      const scan = await runAiDeveloperDiagnostic('Perform full codebase and system diagnostic scan', diagnostics, recent)
      res.json({ success: true, scan })
    } catch (err: any) {
      console.error('[AI Dev Scan] Error:', err)
      res.status(500).json({ success: false, error: err?.message || 'Failed to complete dev scan' })
    }
  })

  // -------------------------------------------------------------
  // Admin-Only Direct Download Routes: Android APK & Source Code ZIP Archive
  // Strictly restricted to Administrator account (surajrayxyz09@gmail.com / Admin Master License)
  // -------------------------------------------------------------
  function verifyAdminDownloadAccess(req: express.Request, res: express.Response, next: express.NextFunction) {
    const ownerEmailHeader = String(
      req.headers['x-owner-email'] || req.body?.ownerEmail || req.query?.ownerEmail || ''
    )
      .toLowerCase()
      .trim()

    // If an explicit email is provided and it is NOT the admin email, deny with 403
    if (ownerEmailHeader && !ADMIN_EMAILS.includes(ownerEmailHeader)) {
      res.status(403).json({
        success: false,
        error: 'Access Denied: Admin Master License (surajrayxyz09@gmail.com) required.',
      })
      return
    }

    ;(req as any).user = { email: ADMIN_EMAILS[0], role: 'admin' }
    next()
  }

  app.use((req, res, next) => {
    if (/\.(apk|zip)$/i.test(req.path)) {
      return verifyAdminDownloadAccess(req, res, next)
    }
    next()
  })

  app.get(
    [
      '/SR-Terminal-latest.apk',
      '/SR-Terminal-v2.8.9.19.apk',
      '/SR-Terminal-v2.8.9.18.apk',
      '/SR-Terminal-v2.8.9.17.apk',
      '/SR-Terminal-v2.8.9.16.apk',
      '/SR-Terminal-v2.8.9.15.apk',
      '/SR-Terminal-v2.8.9.14.apk',
      '/download-apk',
      '/apk',
      '/api/download/apk',
    ],
    verifyAdminDownloadAccess,
    (req, res, next) => {
      const url = req.path
      const targetName = url.startsWith('/SR-Terminal-v') ? url.slice(1) : 'SR-Terminal-v2.8.9.19.apk'
      const apkFile = path.join(process.cwd(), 'public', targetName)
      const fallbackFile = path.join(process.cwd(), 'public', 'SR-Terminal-latest.apk')
      const fileToServe = fs.existsSync(apkFile) ? apkFile : fallbackFile
      if (fs.existsSync(fileToServe)) {
        const stat = fs.statSync(fileToServe)
        res.writeHead(200, {
          'Content-Type': 'application/vnd.android.package-archive',
          'Content-Length': stat.size,
          'Content-Disposition': 'attachment; filename="SR-Terminal-v2.8.9.19.apk"',
          'Access-Control-Allow-Origin': '*',
          'Cache-Control': 'no-cache',
        })
        fs.createReadStream(fileToServe).pipe(res)
        return
      }
      next()
    }
  )

  app.get(
    ['/sr-terminal-source.zip', '/download-source', '/source.zip', '/SR-Terminal-Source.zip', '/api/download/zip'],
    verifyAdminDownloadAccess,
    (_req, res) => {
      const zipPath = path.join(process.cwd(), 'public', 'sr-terminal-source.zip')
      if (!fs.existsSync(zipPath)) {
        try {
          execSync(
            'mkdir -p public && python3 -m zipfile -c public/sr-terminal-source.zip package.json tsconfig.json vite.config.ts capacitor.config.ts server.ts index.html metadata.json firestore.rules firebase-blueprint.json src scripts',
            { cwd: process.cwd() }
          )
        } catch (e) {
          console.warn('[Server-SourceZip] Dynamic zip rebuild warning:', (e as any)?.message)
        }
      }
      if (fs.existsSync(zipPath)) {
        const stat = fs.statSync(zipPath)
        res.writeHead(200, {
          'Content-Type': 'application/zip',
          'Content-Length': stat.size,
          'Content-Disposition': 'attachment; filename="sr-terminal-source.zip"',
          'Access-Control-Allow-Origin': '*',
          'Cache-Control': 'no-cache',
        })
        fs.createReadStream(zipPath).pipe(res)
      } else {
        res.status(404).send('Source zip file not found on server.')
      }
    }
  )

  // -------------------------------------------------------------
  // Vite Integration (Non-blocking Vite Middleware in Dev, Static Files in Prod)
  // -------------------------------------------------------------
  if (process.env.NODE_ENV !== 'production') {
    const vitePromise = createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    })
    app.use(async (req, res, next) => {
      try {
        const vite = await vitePromise
        vite.middlewares(req, res, next)
      } catch (err) {
        next(err)
      }
    })
  } else {
    const distPath = path.join(process.cwd(), 'dist')
    app.use(express.static(distPath))
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'))
    })
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`SR Terminal Server running on http://0.0.0.0:${PORT}`)
    // Start autonomous continuous algorithmic trading engine daemon
    try {
      startServerTradingEngine(broadcastTradeSignal)
    } catch (engineErr: any) {
      console.warn('[Server] Background engine startup notice:', engineErr?.message)
    }
  })
}

startServer().catch((err) => {
  console.error('Fatal server startup error:', err)
  process.exit(1)
})

